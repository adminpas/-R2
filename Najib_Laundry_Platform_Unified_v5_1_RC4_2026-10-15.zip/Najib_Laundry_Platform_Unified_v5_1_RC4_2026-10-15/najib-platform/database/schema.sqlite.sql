-- شركة النجيب المتطورة لمعدات المغاسل | canonical SQLite schema for v5
-- Database: SQLite 3.37+ recommended. This schema mirrors src/server.js.
-- Back up app.sqlite before any migration. Do not use this file against an existing DB blindly.
PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('owner','assistant')),
  full_name TEXT NOT NULL DEFAULT '',
  mobile TEXT NOT NULL DEFAULT '',
  email TEXT NOT NULL DEFAULT '',
  setup_required INTEGER NOT NULL DEFAULT 1 CHECK(setup_required IN (0,1)),
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS auth_sessions (
  jti TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at TEXT NOT NULL,
  revoked_at TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS categories (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  description TEXT NOT NULL DEFAULT '',
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS products (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  condition TEXT NOT NULL DEFAULT 'new' CHECK(condition IN ('new','used-clean','refurbished','untested','used-new')),
  description TEXT NOT NULL DEFAULT '',
  price_halalas INTEGER NOT NULL CHECK(price_halalas >= 0),
  currency TEXT NOT NULL DEFAULT 'SAR' CHECK(currency='SAR'),
  image_path TEXT,
  video_path TEXT,
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  stock_quantity INTEGER NOT NULL DEFAULT 1 CHECK(stock_quantity >= 0)
);

CREATE TABLE IF NOT EXISTS reservations (
  id TEXT PRIMARY KEY,
  product_id TEXT NOT NULL REFERENCES products(id),
  customer_name TEXT NOT NULL,
  mobile TEXT NOT NULL,
  email TEXT NOT NULL,
  business_name TEXT NOT NULL,
  site_address TEXT NOT NULL,
  services_json TEXT NOT NULL DEFAULT '[]',
  status TEXT NOT NULL DEFAULT 'held' CHECK(status IN ('held','confirmed','expired','cancelled','completed')),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_at TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id TEXT PRIMARY KEY,
  actor_id TEXT,
  action TEXT NOT NULL,
  entity TEXT NOT NULL,
  entity_id TEXT,
  detail TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_auth_sessions_user_expiry ON auth_sessions(user_id, expires_at);
CREATE INDEX IF NOT EXISTS idx_products_active_created ON products(active, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_reservations_status_expiry ON reservations(status, expires_at);
CREATE INDEX IF NOT EXISTS idx_reservations_product_status ON reservations(product_id, status);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at DESC);


-- Owner-only double-entry accounting foundation. Entries are append-only; never edit or delete a posted journal.
CREATE TABLE IF NOT EXISTS ledger_accounts (
  id TEXT PRIMARY KEY, code TEXT NOT NULL UNIQUE, name TEXT NOT NULL UNIQUE,
  account_type TEXT NOT NULL CHECK(account_type IN ('asset','liability','equity','revenue','expense')),
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS ledger_journals (
  id TEXT PRIMARY KEY, reference TEXT UNIQUE, reference_type TEXT NOT NULL DEFAULT 'manual',
  memo TEXT NOT NULL, currency TEXT NOT NULL DEFAULT 'SAR' CHECK(currency='SAR'),
  total_debit_halalas INTEGER NOT NULL CHECK(total_debit_halalas > 0),
  total_credit_halalas INTEGER NOT NULL CHECK(total_credit_halalas > 0 AND total_credit_halalas=total_debit_halalas),
  posted INTEGER NOT NULL DEFAULT 0 CHECK(posted IN (0,1)),
  created_by TEXT REFERENCES users(id), created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS ledger_lines (
  id TEXT PRIMARY KEY, journal_id TEXT NOT NULL REFERENCES ledger_journals(id),
  account_id TEXT NOT NULL REFERENCES ledger_accounts(id),
  debit_halalas INTEGER NOT NULL DEFAULT 0 CHECK(debit_halalas >= 0),
  credit_halalas INTEGER NOT NULL DEFAULT 0 CHECK(credit_halalas >= 0),
  note TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CHECK((debit_halalas > 0 AND credit_halalas = 0) OR (credit_halalas > 0 AND debit_halalas = 0))
);
CREATE INDEX IF NOT EXISTS idx_ledger_journals_created ON ledger_journals(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_ledger_lines_journal ON ledger_lines(journal_id);
CREATE INDEX IF NOT EXISTS idx_ledger_lines_account ON ledger_lines(account_id);
CREATE TRIGGER IF NOT EXISTS ledger_journals_no_update BEFORE UPDATE ON ledger_journals WHEN OLD.posted=1 BEGIN SELECT RAISE(ABORT,'IMMUTABLE_LEDGER'); END;
CREATE TRIGGER IF NOT EXISTS ledger_journals_no_delete BEFORE DELETE ON ledger_journals WHEN OLD.posted=1 BEGIN SELECT RAISE(ABORT,'IMMUTABLE_LEDGER'); END;
CREATE TRIGGER IF NOT EXISTS ledger_journals_post_balance BEFORE UPDATE OF posted ON ledger_journals WHEN OLD.posted=0 AND NEW.posted=1 AND (
  (SELECT COUNT(*) FROM ledger_lines WHERE journal_id=NEW.id)<2 OR
  (SELECT COALESCE(SUM(debit_halalas),0) FROM ledger_lines WHERE journal_id=NEW.id)<>NEW.total_debit_halalas OR
  (SELECT COALESCE(SUM(credit_halalas),0) FROM ledger_lines WHERE journal_id=NEW.id)<>NEW.total_credit_halalas OR
  (SELECT COALESCE(SUM(debit_halalas),0) FROM ledger_lines WHERE journal_id=NEW.id)<1 OR
  (SELECT COALESCE(SUM(credit_halalas),0) FROM ledger_lines WHERE journal_id=NEW.id)<>(SELECT COALESCE(SUM(debit_halalas),0) FROM ledger_lines WHERE journal_id=NEW.id)
) BEGIN SELECT RAISE(ABORT,'LEDGER_UNBALANCED'); END;
CREATE TRIGGER IF NOT EXISTS ledger_lines_no_insert_after_post BEFORE INSERT ON ledger_lines WHEN (SELECT posted FROM ledger_journals WHERE id=NEW.journal_id)=1 BEGIN SELECT RAISE(ABORT,'IMMUTABLE_LEDGER'); END;
CREATE TRIGGER IF NOT EXISTS ledger_lines_no_update BEFORE UPDATE ON ledger_lines WHEN (SELECT posted FROM ledger_journals WHERE id=OLD.journal_id)=1 OR (SELECT posted FROM ledger_journals WHERE id=NEW.journal_id)=1 BEGIN SELECT RAISE(ABORT,'IMMUTABLE_LEDGER'); END;
CREATE TRIGGER IF NOT EXISTS ledger_lines_no_delete BEFORE DELETE ON ledger_lines WHEN (SELECT posted FROM ledger_journals WHERE id=OLD.journal_id)=1 BEGIN SELECT RAISE(ABORT,'IMMUTABLE_LEDGER'); END;
