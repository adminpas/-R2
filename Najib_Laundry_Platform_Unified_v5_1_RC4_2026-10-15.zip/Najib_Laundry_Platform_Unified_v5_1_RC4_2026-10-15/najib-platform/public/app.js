const el = (selector) => document.querySelector(selector);
const sar = (value) => new Intl.NumberFormat('ar-SA', { style: 'currency', currency: 'SAR', maximumFractionDigits: 2 }).format(value);
const esc = (value = '') => String(value).replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
const conditions = { new: 'جديد', 'used-clean': 'مستعمل نظيف', refurbished: 'مجدد ومصان', untested: 'غير مفحوص', 'used-new': 'مستخدم لفترة قصيرة' };
const introSessionKey = 'najib-brand-intro-seen-v5';
let products = [];
let categories = [];
let readOnlyOfflineMode = false;
let publicCatalogSavedAt = '';
let publicSettings = { companyName: 'شركة النجيب المتطورة لمعدات المغاسل', warehouseAddress: 'المنطقة الصناعية، جدة', holdHours: 24, services: [] };

function mediaUrl(filePath) {
  if (!filePath || typeof filePath !== 'string') return '';
  return '/storage/' + filePath.split('/').map((part) => encodeURIComponent(part)).join('/');
}
function renderOptionalServices() {
  const target = el('#serviceOptions');
  if (!target) return;
  const services = Array.isArray(publicSettings.services) ? publicSettings.services : [];
  if (!services.length) {
    target.innerHTML = '<p class="muted">لا توجد خدمات إضافية مفعّلة حاليًا. يمكنك إرسال طلب المعدة فقط.</p>';
    return;
  }
  target.innerHTML = services.map((service) => {
    const pricing = service.pricingMode === 'fixed' && Number.isFinite(Number(service.priceSAR))
      ? `سعر محدد: ${sar(Number(service.priceSAR))}` : 'يحتاج عرض سعر قبل الاتفاق';
    return `<label class="service-choice"><input type="checkbox" name="services" value="${esc(service.id)}"><span><strong>${esc(service.name)}</strong><small>${esc(pricing)}</small></span></label>`;
  }).join('');
}
function startBrandIntro() {
  if (window.matchMedia?.('(prefers-reduced-motion: reduce)').matches) return;
  try { if (sessionStorage.getItem(introSessionKey)) return; sessionStorage.setItem(introSessionKey, '1'); } catch { /* session storage may be disabled */ }
  const wrap = document.createElement('div');
  wrap.className = 'brand-intro';
  wrap.setAttribute('aria-hidden', 'true');
  wrap.innerHTML = '<img src="/brand/najib-logo.webp" alt="" width="700" height="700"><span>شركة النجيب المتطورة لمعدات المغاسل</span>';
  document.body.appendChild(wrap);
  window.setTimeout(() => wrap.remove(), 3200);
}
function updateFilters() {
  const categorySelect = el('#categoryFilter');
  const selected = categorySelect.value;
  categorySelect.innerHTML = '<option value="">جميع الأقسام</option>' + categories.map((c) => `<option value="${esc(c.name)}">${esc(c.name)}</option>`).join('');
  if (categories.some((c) => c.name === selected)) categorySelect.value = selected;
}
function filteredProducts() {
  const q = el('#searchProducts').value.trim().toLocaleLowerCase('ar');
  const category = el('#categoryFilter').value;
  const condition = el('#conditionFilter').value;
  return products.filter((p) => (!category || p.category === category)
    && (!condition || p.condition === condition)
    && (!q || `${p.name} ${p.category} ${p.description || ''}`.toLocaleLowerCase('ar').includes(q)));
}
function renderProducts() {
  const box = el('#products');
  const rows = filteredProducts();
  if (!rows.length) {
    box.innerHTML = `<p class="empty-state">${products.length ? 'لا توجد نتائج مطابقة. جرّب تغيير البحث أو الفلاتر.' : 'لا توجد معدات منشورة حاليًا. يمكن للمالك إضافة المنتجات من لوحة الإدارة.'}</p>`;
    return;
  }
  box.innerHTML = rows.map((product) => {
    const image = product.image_path
      ? `<img loading="lazy" src="${esc(mediaUrl(product.image_path))}" alt="${esc(product.name)}" decoding="async">`
      : '<div class="media-placeholder" role="img" aria-label="لا توجد صورة للمعدة"><span>صورة المعدة</span></div>';
    const video = product.video_path
      ? `<div class="video-wrap"><video controls preload="none" controlsList="nodownload" disablepictureinpicture aria-label="فيديو ${esc(product.name)}" src="${esc(mediaUrl(product.video_path))}"></video><span class="video-watermark" aria-hidden="true">شركة النجيب المتطورة لمعدات المغاسل</span></div>`
      : '';
    const available = Number(product.availableQuantity ?? product.stock_quantity ?? 0);
    return `<article class="product">
      ${image}<div class="body">
        <h3>${esc(product.name)}</h3>
        <div class="muted">${esc(product.category)} · ${esc(conditions[product.condition] || product.condition)}</div>
        <p class="description">${esc(product.description || 'تواصل مع المعرض لطلب المواصفات التفصيلية والمعاينة.')}</p>
        ${video}
        <div class="price">${sar(product.priceSAR)}</div>
        <p class="stock ${available > 0 ? 'available' : 'unavailable'}">${available > 0 ? `الكمية المتاحة مبدئيًا: ${available}` : 'لا توجد كمية متاحة للحجز حاليًا'}</p>
        <button class="primary" data-id="${esc(product.id)}" ${(available < 1 || readOnlyOfflineMode) ? 'disabled' : ''}>${readOnlyOfflineMode ? 'اتصل بالإنترنت للحجز' : 'طلب حجز مبدئي'}</button>
      </div></article>`;
  }).join('');
  box.querySelectorAll('[data-id]').forEach((button) => button.addEventListener('click', () => openReservation(button.dataset.id)));
}
async function jsonRequest(url, options = {}) {
  const response = await fetch(url, { ...options, headers: { Accept: 'application/json', ...(options.headers || {}) } });
  let data = {};
  try { data = await response.json(); } catch { /* server may return a non-JSON error */ }
  if (!response.ok) {
    const error = new Error(data.error || `HTTP_${response.status}`);
    error.status = response.status;
    throw error;
  }
  return data;
}
const publicCatalogCacheKey = 'najib-public-catalog-cache-v1';
function restorePublicCatalog() {
  try {
    const cached = JSON.parse(localStorage.getItem(publicCatalogCacheKey) || 'null');
    if (!cached || !Array.isArray(cached.products) || !Array.isArray(cached.categories) || !cached.settings) return false;
    products = cached.products; categories = cached.categories; publicSettings = cached.settings; publicCatalogSavedAt = cached.savedAt || '';
    return true;
  } catch { return false; }
}
function savePublicCatalog() {
  // Cache only public catalog metadata/settings; never cache reservations, login tokens, or customer PII.
  try { publicCatalogSavedAt = new Date().toISOString(); localStorage.setItem(publicCatalogCacheKey, JSON.stringify({ savedAt: publicCatalogSavedAt, products, categories, settings: publicSettings })); } catch { /* quota/privacy settings may disable storage */ }
}
function syncStorefrontChrome(settings) {
  const brand = document.querySelector('header .brand');
  if (brand) brand.textContent = settings.companyName.replace(/\s+لمعدات المغاسل$/, '');
  const warehouse = document.querySelector('.hero small');
  if (warehouse) warehouse.textContent = `المعرض التجاري · ${settings.warehouseAddress}`;
  const disclaimer = document.querySelector('.disclaimer');
  if (disclaimer) disclaimer.textContent = `الطلب حجز مبدئي لمدة ${settings.holdHours} ساعة من وقت إنشائه، ولا يمثل تحصيلًا ماليًا أو فاتورة بيع.`;
  updateFilters(); renderOptionalServices(); renderProducts();
}
async function load() {
  const box = el('#products');
  box.innerHTML = '<p class="empty-state">جارٍ تحميل المعدات…</p>';
  try {
    const [productRows, categoryRows, settings] = await Promise.all([jsonRequest('/api/products'), jsonRequest('/api/categories'), jsonRequest('/api/public-settings')]);
    products = productRows; categories = categoryRows; publicSettings = settings; readOnlyOfflineMode = false;
    savePublicCatalog(); syncStorefrontChrome(settings);
  } catch {
    if (restorePublicCatalog()) {
      readOnlyOfflineMode = true; syncStorefrontChrome(publicSettings);
      const notice = document.createElement('p');
      notice.className = 'empty-state error offline-catalog-notice';
      notice.setAttribute('role', 'status');
      notice.textContent = `أنت في وضع عدم الاتصال. آخر حفظ للكتالوج: ${publicCatalogSavedAt ? new Date(publicCatalogSavedAt).toLocaleString('ar-SA') : 'وقت غير معروف'}. الحجز وتأكيد المخزون يتطلبان اتصالًا بالخادم.`;
      box.prepend(notice);
    } else {
      box.innerHTML = '<p class="empty-state error">تعذر الاتصال بالخادم ولا توجد نسخة كتالوج محفوظة على هذا الجهاز.</p>';
    }
  }
}
function openReservation(id) {
  const product = products.find((item) => item.id === id);
  if (readOnlyOfflineMode || !product || Number(product.availableQuantity ?? product.stock_quantity ?? 0) < 1) return;
  el('[name="productId"]').value = id;
  el('#chosen').textContent = `${product.name} — ${sar(product.priceSAR)}`;
  el('#formMessage').textContent = '';
  el('#formMessage').className = '';
  el('#reserve').showModal();
}
el('#reserveForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const message = el('#formMessage');
  const submit = form.querySelector('[type="submit"]');
  const body = Object.fromEntries(new FormData(form).entries());
  body.services = [...form.querySelectorAll('input[name="services"]:checked')].map((input) => input.value);
  message.className = '';
  message.textContent = 'جارٍ إرسال الطلب…';
  submit.disabled = true;
  try {
    const result = await jsonRequest('/api/reservations', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    message.className = 'success';
    message.textContent = `تم تسجيل الطلب المرجعي ${result.id}. ينتهي الحجز المبدئي في ${new Date(result.expiresAt).toLocaleString('ar-SA')}. لم يتم تحصيل أي مبلغ.`;
    form.reset();
    await load();
  } catch (error) {
    message.className = 'error';
    if (error.message === 'OUT_OF_STOCK') message.textContent = 'لم تعد هناك كمية متاحة لهذا المنتج. حدّث القائمة واختَر منتجًا آخر.';
    else if (error.message === 'VALIDATION_FAILED') message.textContent = 'تحقق من صيغة الجوال والبريد الإلكتروني والبيانات المدخلة.';
    else message.textContent = 'تعذر إنشاء الطلب. تحقق من البيانات والاتصال ثم حاول مجددًا.';
  } finally {
    submit.disabled = false;
  }
});
el('#close').addEventListener('click', () => el('#reserve').close());
el('#reload').addEventListener('click', load);
el('#searchProducts').addEventListener('input', renderProducts);
el('#categoryFilter').addEventListener('change', renderProducts);
el('#conditionFilter').addEventListener('change', renderProducts);
el('#advisorForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget; const button = form.querySelector('button'); const message = el('#advisorMessage'); const results = el('#advisorResults');
  button.disabled = true; message.textContent = 'جارٍ مراجعة الكتالوج…'; results.innerHTML = '';
  try {
    const data = await jsonRequest('/api/assistant/recommend', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ question: form.elements.question.value }) });
    message.textContent = `${data.answer} ${data.disclaimer || ''}`;
    results.innerHTML = (data.products || []).map((p) => `<article class="product"><div class="body"><h3>${esc(p.name)}</h3><p class="muted">${esc(p.category)} · ${esc(conditions[p.condition] || p.condition)}</p><p>${esc(p.description || '')}</p><p class="price">${sar(p.priceSAR)}</p><p class="muted">الكمية المسجلة: ${Number(p.availableStock || 0)}</p></div></article>`).join('');
  } catch { message.textContent = 'تعذر الحصول على الاقتراح. حاول مرة أخرى لاحقًا.'; }
  finally { button.disabled = false; }
});
startBrandIntro();
if ('serviceWorker' in navigator) window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}));
load();
