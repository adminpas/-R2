const q = (selector) => document.querySelector(selector);
const money = (value) => new Intl.NumberFormat('ar-SA', { style: 'currency', currency: 'SAR' }).format(value || 0);
const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
const conditionNames = { new: 'جديد', 'used-clean': 'مستعمل نظيف', refurbished: 'مجدد ومصان', untested: 'غير مفحوص', 'used-new': 'مستخدم لفترة قصيرة' };
const statusNames = { held: 'حجز مبدئي', confirmed: 'مؤكد', expired: 'منتهي', cancelled: 'ملغي', completed: 'مكتمل' };
let token = '';
let role = '';
let userProducts = [];
let adminCategories = [];

async function api(url, options = {}) {
  const headers = { Accept: 'application/json', ...(options.headers || {}) };
  if (token) headers.Authorization = `Bearer ${token}`;
  if (options.body && !(options.body instanceof FormData) && !headers['Content-Type']) headers['Content-Type'] = 'application/json';
  const response = await fetch(url, { ...options, headers });
  let data = {};
  try { data = await response.json(); } catch { /* ignore non-JSON error */ }
  if (!response.ok) {
    const error = new Error(data.error || `HTTP_${response.status}`);
    error.status = response.status;
    throw error;
  }
  return data;
}
function show(viewId) {
  ['loginView', 'setupView', 'dashboardView'].forEach((id) => q(`#${id}`).classList.toggle('hidden', id !== viewId));
}
function message(selector, text, cls = '') {
  const item = q(selector);
  item.textContent = text;
  item.className = cls;
}
function translateError(error) {
  const messages = {
    VALIDATION_FAILED: 'راجع الحقول المدخلة وصيغة الجوال وقوة كلمة المرور.',
    ACTIVE_CATEGORY_REQUIRED: 'اختر قسمًا نشطًا من قائمة الأقسام.',
    CATEGORY_ALREADY_EXISTS: 'يوجد قسم بالاسم نفسه بالفعل.',
    CATEGORY_IN_USE: 'لا يمكن حذف قسم مرتبط بمنتجات. عطّله أو انقل المنتجات إلى قسم آخر.',
    ASSISTANT_LIMIT_REACHED: 'وصلت إلى الحد الأعلى وهو 3 مساعدين.',
    INVALID_STATUS_TRANSITION: 'لا يمكن نقل الحجز إلى هذه الحالة من حالته الحالية.',
    RESERVATION_EXPIRED: 'انتهت مدة الحجز المبدئي ولا يمكن تأكيده.',
    OUT_OF_STOCK: 'لا توجد كمية متاحة للحجز.',
    UPLOAD_REJECTED: 'تعذر قبول الملف. تحقق من نوعه وحجمه.',
    AUTH_REQUIRED: 'انتهت الجلسة أو يلزم تسجيل الدخول مجددًا.',
    CURRENT_PASSWORD_INCORRECT: 'كلمة المرور الحالية غير صحيحة.',
    PASSWORD_UNCHANGED: 'اختر كلمة مرور جديدة مختلفة عن الحالية.',
    FORBIDDEN: 'لا تملك صلاحية تنفيذ هذا الإجراء.'
  };
  return messages[error.message] || `تعذر إكمال العملية (${error.message}).`;
}
function setRoleUI() {
  document.querySelectorAll('.owner-only').forEach((item) => item.classList.toggle('hidden', role !== 'owner'));
  document.querySelectorAll('.owner-only-field').forEach((label) => {
    label.classList.toggle('hidden', role !== 'owner');
    label.querySelectorAll('input,select,textarea').forEach((control) => { control.disabled = role !== 'owner'; });
  });
  q('#sessionMessage').textContent = role === 'owner'
    ? 'دور المالك: إدارة كاملة للكتالوج والحجوزات والأقسام والمستخدمين وسجل التدقيق.'
    : 'دور المساعد: الاطلاع التشغيلي وتعديل وصف المنتج فقط.';
  if (role === 'assistant') q('#stats').classList.add('hidden');
}

q('#loginForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const submit = event.currentTarget.querySelector('[type="submit"]') || event.currentTarget.querySelector('button');
  submit.disabled = true;
  const body = Object.fromEntries(new FormData(event.currentTarget).entries());
  try {
    const result = await api('/api/auth/login', { method: 'POST', body: JSON.stringify(body) });
    token = result.token;
    role = result.role;
    if (result.setupRequired) show('setupView');
    else await openDashboard();
    message('#loginMsg', '');
  } catch (error) {
    message('#loginMsg', error.status === 401 ? 'بيانات الدخول غير صحيحة.' : 'تعذر الاتصال بالخادم. حاول مجددًا.', 'error');
  } finally { submit.disabled = false; }
});
q('#setupForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const submit = event.currentTarget.querySelector('button');
  submit.disabled = true;
  const body = Object.fromEntries(new FormData(event.currentTarget).entries());
  try {
    const result = await api('/api/auth/setup', { method: 'POST', body: JSON.stringify(body) });
    token = result.token;
    role = 'owner';
    await openDashboard();
    message('#setupMsg', '');
  } catch (error) { message('#setupMsg', translateError(error), 'error'); }
  finally { submit.disabled = false; }
});

async function openDashboard() {
  show('dashboardView');
  setRoleUI();
  document.querySelectorAll('[id^="tab-"]').forEach((section) => section.classList.add('hidden'));
  q('#tab-products').classList.remove('hidden');
  if (role === 'assistant') q('#productForm').classList.add('hidden');
  const jobs = [loadProducts(), loadReservations()];
  if (role === 'owner') jobs.push(loadCategories(), loadOverview());
  await Promise.all(jobs);
}
async function loadOverview() {
  try {
    const data = await api('/api/admin/overview');
    q('#stats').innerHTML = [
      ['المنتجات المنشورة', data.products], ['المنتجات المؤرشفة', data.archivedProducts],
      ['إجمالي الطلبات', data.reservations], ['الحجوزات المبدئية', data.openHolds], ['الحجوزات المؤكدة', data.confirmed]
    ].map(([label, value]) => `<div class="stat"><span>${esc(label)}</span><strong>${Number(value || 0).toLocaleString('ar-SA')}</strong></div>`).join('');
  } catch { q('#stats').textContent = 'تعذر تحميل المؤشرات. تحقق من صلاحية الدخول واتصال الخادم.'; }
}
async function loadProducts() {
  try {
    userProducts = await api('/api/admin/products');
    q('#adminProducts').innerHTML = userProducts.map((product) => {
      const ownerMeta = role === 'owner' ? `<p>${money(product.price_halalas / 100)} · الكمية: ${Number(product.stock_quantity || 0)} · ${product.active ? 'منشور' : 'مؤرشف'}</p>` : '';
      return `<article class="admin-item"><div class="admin-item-main"><strong>${esc(product.name)}</strong><p>${esc(product.category)} · ${esc(conditionNames[product.condition] || product.condition)}</p>${ownerMeta}<p>${esc(product.description || 'لا يوجد وصف.')}</p></div><div class="item-actions"><button type="button" data-edit="${esc(product.id)}">${role === 'owner' ? 'تعديل' : 'تعديل الوصف'}</button>${role === 'owner' && product.active ? `<button type="button" class="danger" data-archive="${esc(product.id)}">أرشفة</button>` : ''}</div></article>`;
    }).join('') || '<p>لا توجد منتجات بعد. أضف المنتجات من النموذج أعلاه.</p>';
    q('#adminProducts').querySelectorAll('[data-edit]').forEach((button) => button.addEventListener('click', () => editProduct(button.dataset.edit)));
    q('#adminProducts').querySelectorAll('[data-archive]').forEach((button) => button.addEventListener('click', () => archiveProduct(button.dataset.archive)));
  } catch (error) { q('#adminProducts').textContent = translateError(error); }
}
function editProduct(id) {
  const product = userProducts.find((item) => item.id === id);
  if (!product) return;
  const form = q('#productForm');
  form.reset();
  form.elements.id.value = product.id;
  form.elements.description.value = product.description || '';
  if (role === 'owner') {
    form.elements.name.value = product.name;
    form.elements.category.value = product.category;
    form.elements.condition.value = product.condition;
    form.elements.priceSAR.value = (product.price_halalas / 100).toFixed(2);
    form.elements.stockQuantity.value = product.stock_quantity ?? 1;
  }
  form.classList.remove('hidden');
  q('#saveProduct').textContent = 'حفظ التعديلات';
  message('#productMsg', role === 'owner' ? 'تعديل منتج موجود. ارفع ملفًا جديدًا فقط إذا أردت استبدال الوسيط.' : 'يمكنك تعديل الوصف فقط.', 'muted');
  form.scrollIntoView({ behavior: 'smooth', block: 'start' });
}
q('#productForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const id = form.elements.id.value;
  const button = q('#saveProduct');
  button.disabled = true;
  try {
    if (role === 'assistant') {
      if (!id) throw new Error('ASSISTANT_DESCRIPTION_ONLY');
      await api(`/api/admin/products/${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify({ description: form.elements.description.value }) });
    } else {
      const data = new FormData(form);
      data.delete('id');
      const price = data.get('priceSAR');
      if (price !== null) data.set('priceSAR', String(Number(price)));
      await api(id ? `/api/admin/products/${encodeURIComponent(id)}` : '/api/admin/products', { method: id ? 'PATCH' : 'POST', body: data });
    }
    message('#productMsg', 'تم حفظ التغييرات.', 'success');
    form.reset();
    form.elements.id.value = '';
    button.textContent = 'حفظ المنتج';
    if (role === 'assistant') form.classList.add('hidden');
    await loadProducts();
    if (role === 'owner') await loadOverview();
  } catch (error) { message('#productMsg', translateError(error), 'error'); }
  finally { button.disabled = false; }
});
q('#newProduct').addEventListener('click', () => {
  if (role !== 'owner') return;
  const form = q('#productForm');
  form.reset();
  form.elements.id.value = '';
  form.classList.remove('hidden');
  q('#saveProduct').textContent = 'حفظ المنتج الجديد';
  message('#productMsg', 'أدخل البيانات واربط المنتج بقسم نشط. لا تُنشأ منتجات تجريبية تلقائيًا.');
  form.scrollIntoView({ behavior: 'smooth', block: 'start' });
});
q('#clearProduct').addEventListener('click', () => {
  const form = q('#productForm');
  form.reset(); form.elements.id.value = '';
  q('#saveProduct').textContent = 'حفظ المنتج';
  message('#productMsg', '');
  if (role === 'assistant') form.classList.add('hidden');
});
async function archiveProduct(id) {
  if (!confirm('أرشفة المنتج؟ لن يظهر للعملاء، وستبقى سجلاته محفوظة.')) return;
  try { await api(`/api/admin/products/${encodeURIComponent(id)}`, { method: 'DELETE' }); await loadProducts(); await loadOverview(); }
  catch (error) { alert(translateError(error)); }
}

async function loadCategories() {
  try {
    adminCategories = await api('/api/admin/categories');
    const select = q('#productForm').elements.category;
    const oldValue = select.value;
    const active = adminCategories.filter((category) => category.active);
    select.innerHTML = '<option value="">اختر قسمًا</option>' + active.map((category) => `<option value="${esc(category.name)}">${esc(category.name)}</option>`).join('');
    if (active.some((category) => category.name === oldValue)) select.value = oldValue;
    q('#categoriesList').innerHTML = adminCategories.map((category) => `<article class="admin-item"><div class="admin-item-main"><strong>${esc(category.name)}</strong><p>${esc(category.description || 'بدون وصف')}</p><p>${category.active ? 'نشط' : 'معطّل'}</p></div><div class="item-actions"><button type="button" data-category-edit="${esc(category.id)}">تعديل</button><button type="button" data-category-toggle="${esc(category.id)}">${category.active ? 'تعطيل' : 'تفعيل'}</button><button type="button" class="danger" data-category-delete="${esc(category.id)}">حذف</button></div></article>`).join('') || '<p>لا توجد أقسام.</p>';
    q('#categoriesList').querySelectorAll('[data-category-edit]').forEach((button) => button.addEventListener('click', () => editCategory(button.dataset.categoryEdit)));
    q('#categoriesList').querySelectorAll('[data-category-toggle]').forEach((button) => button.addEventListener('click', () => toggleCategory(button.dataset.categoryToggle)));
    q('#categoriesList').querySelectorAll('[data-category-delete]').forEach((button) => button.addEventListener('click', () => deleteCategory(button.dataset.categoryDelete)));
  } catch (error) { q('#categoriesList').textContent = translateError(error); }
}
q('#categoryForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const button = event.currentTarget.querySelector('button');
  button.disabled = true;
  try {
    await api('/api/admin/categories', { method: 'POST', body: JSON.stringify(Object.fromEntries(new FormData(event.currentTarget).entries())) });
    event.currentTarget.reset();
    message('#categoryMsg', 'تمت إضافة القسم.', 'success');
    await loadCategories();
  } catch (error) { message('#categoryMsg', translateError(error), 'error'); }
  finally { button.disabled = false; }
});
async function editCategory(id) {
  const category = adminCategories.find((item) => item.id === id);
  if (!category) return;
  const name = prompt('اسم القسم:', category.name);
  if (name === null) return;
  const description = prompt('وصف القسم:', category.description || '');
  if (description === null) return;
  try {
    await api(`/api/admin/categories/${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify({ name: name.trim(), description }) });
    await loadCategories(); await loadProducts();
    message('#categoryMsg', 'تم تحديث القسم وربط المنتجات بالاسم الجديد.', 'success');
  } catch (error) { message('#categoryMsg', translateError(error), 'error'); }
}
async function toggleCategory(id) {
  const category = adminCategories.find((item) => item.id === id);
  if (!category) return;
  try { await api(`/api/admin/categories/${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify({ active: !category.active }) }); await loadCategories(); }
  catch (error) { message('#categoryMsg', translateError(error), 'error'); }
}
async function deleteCategory(id) {
  const category = adminCategories.find((item) => item.id === id);
  if (!category || !confirm(`حذف القسم «${category.name}» نهائيًا؟`)) return;
  try { await api(`/api/admin/categories/${encodeURIComponent(id)}`, { method: 'DELETE' }); await loadCategories(); }
  catch (error) { message('#categoryMsg', translateError(error), 'error'); }
}

async function loadReservations() {
  try {
    const rows = await api('/api/admin/reservations');
    q('#reservationsList').innerHTML = rows.map((reservation) => {
      let selectedServices = [];
      try { selectedServices = JSON.parse(reservation.services_json || '[]'); } catch { selectedServices = []; }
      const servicesText = selectedServices.length ? selectedServices.map((service) => `${esc(service.name)} (${service.pricingMode === 'fixed' && Number.isFinite(Number(service.priceSAR)) ? money(service.priceSAR) : 'عرض سعر مطلوب'})`).join('، ') : 'لم يطلب العميل خدمات إضافية';
      const fullDetails = role === 'owner' ? `<p>العميل: ${esc(reservation.customer_name)} · الجوال: ${esc(reservation.mobile)} · البريد: ${esc(reservation.email)}</p><p>المنشأة: ${esc(reservation.business_name)} · الموقع: ${esc(reservation.site_address)}</p><p>الخدمات الاختيارية: ${servicesText}</p>` : '<p>بيانات العميل محجوبة للمساعد؛ إدارة حالات الطلب للمالك فقط.</p>';
      const availableActions = role !== 'owner' ? '' : reservation.status === 'held'
        ? `<button type="button" data-res-status="confirmed" data-id="${esc(reservation.id)}">تأكيد الحجز</button><button type="button" class="danger" data-res-status="cancelled" data-id="${esc(reservation.id)}">إلغاء</button>`
        : reservation.status === 'confirmed'
          ? `<button type="button" data-res-status="completed" data-id="${esc(reservation.id)}">إكمال الطلب</button><button type="button" class="danger" data-res-status="cancelled" data-id="${esc(reservation.id)}">إلغاء</button>` : '';
      return `<article class="admin-item"><div class="admin-item-main"><strong>${esc(reservation.product_name)}</strong><p>الحالة: ${esc(statusNames[reservation.status] || reservation.status)}</p><p>أنشئ: ${esc(reservation.created_at)} · نهاية الحجز: ${esc(reservation.expires_at)}</p>${fullDetails}</div><div class="item-actions">${availableActions}</div></article>`;
    }).join('') || '<p>لا توجد حجوزات.</p>';
    q('#reservationsList').querySelectorAll('[data-res-status]').forEach((button) => button.addEventListener('click', () => updateReservation(button.dataset.id, button.dataset.resStatus)));
  } catch (error) { q('#reservationsList').textContent = translateError(error); }
}
async function updateReservation(id, status) {
  const confirmationText = { confirmed: 'تأكيد هذا الحجز؟', cancelled: 'إلغاء هذا الحجز؟', completed: 'وضع الطلب بحالة مكتمل؟' }[status];
  if (!confirm(confirmationText)) return;
  try { await api(`/api/admin/reservations/${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify({ status }) }); await loadReservations(); await loadOverviewIfOwner(); }
  catch (error) { alert(translateError(error)); await loadReservations(); }
}
async function loadOverviewIfOwner() { if (role === 'owner') await loadOverview(); }

async function loadAssistants() {
  try {
    const rows = await api('/api/admin/assistants');
    q('#assistantsList').innerHTML = rows.map((assistant) => `<article class="admin-item"><div class="admin-item-main"><strong>${esc(assistant.full_name || assistant.username)}</strong><p>اسم المستخدم: ${esc(assistant.username)} · الجوال: ${esc(assistant.mobile || 'غير مسجل')}</p><p>البريد: ${esc(assistant.email || 'غير مسجل')} · الحالة: ${assistant.active ? 'نشط' : 'موقوف'}</p></div><div class="item-actions"><button type="button" data-assistant-toggle="${esc(assistant.id)}" data-active="${assistant.active ? 'true' : 'false'}">${assistant.active ? 'إيقاف الحساب' : 'إعادة التفعيل'}</button></div></article>`).join('') || '<p>لا توجد حسابات مساعد نشطة أو سابقة.</p>';
    q('#assistantsList').querySelectorAll('[data-assistant-toggle]').forEach((button) => button.addEventListener('click', () => toggleAssistant(button.dataset.assistantToggle, button.dataset.active !== 'true')));
  } catch (error) { q('#assistantsList').textContent = translateError(error); }
}
async function toggleAssistant(id, activate) {
  const action = activate ? 'إعادة تفعيل' : 'إيقاف';
  if (!confirm(`${action} حساب المساعد؟ ${activate ? 'سيحتاج المستخدم إلى تسجيل الدخول مجددًا.' : 'ستُبطل جلساته الحالية فورًا.'}`)) return;
  try {
    await api(`/api/admin/assistants/${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify({ active: activate }) });
    await loadAssistants();
    message('#assistantMsg', activate ? 'تمت إعادة تفعيل الحساب.' : 'تم إيقاف الحساب وإبطال الجلسات النشطة.', 'success');
  } catch (error) { message('#assistantMsg', translateError(error), 'error'); }
}
q('#assistantForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const button = form.querySelector('button');
  button.disabled = true;
  try {
    await api('/api/admin/assistants', { method: 'POST', body: JSON.stringify(Object.fromEntries(new FormData(form).entries())) });
    message('#assistantMsg', 'تم إنشاء حساب المساعد.', 'success');
    form.reset();
    await loadAssistants();
  } catch (error) { message('#assistantMsg', translateError(error), 'error'); }
  finally { button.disabled = false; }
});
q('#reloadAssistants').addEventListener('click', loadAssistants);
async function loadSettings() {
  try {
    const data = await api('/api/admin/settings');
    const form = q('#settingsForm');
    form.elements.companyName.value = data.companyName;
    form.elements.warehouseAddress.value = data.warehouseAddress;
    form.elements.holdHours.value = data.holdHours;
    form.elements.aiConfigured.value = data.aiConfigured ? 'مُعد على الخادم' : 'غير مُعد — يعمل الرد الاحتياطي من الكتالوج';
    form.elements.services.value = JSON.stringify(data.services, null, 2);
    message('#settingsMsg', 'تم تحميل الإعدادات الحالية.', 'muted');
  } catch (error) { message('#settingsMsg', translateError(error), 'error'); }
}
q('#settingsForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget; const button = form.querySelector('[type=submit]'); button.disabled = true;
  try {
    let services;
    try { services = JSON.parse(form.elements.services.value); } catch { throw new Error('INVALID_SERVICES_JSON'); }
    await api('/api/admin/settings', { method: 'PATCH', body: JSON.stringify({ companyName: form.elements.companyName.value.trim(), warehouseAddress: form.elements.warehouseAddress.value.trim(), holdHours: Number(form.elements.holdHours.value), services }) });
    message('#settingsMsg', 'حُفظت الإعدادات في قاعدة البيانات. قد تتطلب إعدادات مزود الذكاء الاصطناعي إعادة تشغيل الخادم.', 'success');
    await loadSettings();
  } catch (error) { message('#settingsMsg', error.message === 'INVALID_SERVICES_JSON' ? 'صيغة JSON للخدمات غير صحيحة.' : translateError(error), 'error'); }
  finally { button.disabled = false; }
});
q('#reloadSettings').addEventListener('click', loadSettings);

q('#runSystemAudit').addEventListener('click', async () => {
  const button = q('#runSystemAudit'); const output = q('#systemAuditOutput');
  button.disabled = true; output.textContent = 'جارٍ فحص الكتالوج والحجوزات وسجل التدقيق والدفتر المالي…';
  try {
    const result = await api('/api/admin/assistant/audit', { method: 'POST', body: '{}' });
    const rows = [
      `نوع الفحص: ${result.mode === 'ai' ? 'تحليل بمزود الذكاء الاصطناعي' : 'قواعد محلية — لم يُستخدم مزود خارجي'}`,
      `وقت الفحص: ${new Date(result.generatedAt).toLocaleString('ar-SA')}`,
      `المعدات النشطة: ${result.inventory.activeProducts} | مخزون صفري: ${result.inventory.zeroStockProducts} | غير مفحوص: ${result.inventory.untestedProducts}`,
      `الحجوزات: ${JSON.stringify(result.reservations)}`,
      `القيود المرحلة: ${result.ledger.postedJournals} | قيود غير متطابقة: ${result.ledger.inconsistentPostedJournals}`,
      '', 'الملاحظات:', ...(result.findings || []).map((item, i) => `${i + 1}. ${item}`),
      '', 'التوصية:', result.summary, '', result.disclaimer
    ];
    output.textContent = rows.join('\n');
  } catch (error) { output.textContent = translateError(error); }
  finally { button.disabled = false; }
});


q('#passwordForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const button = form.querySelector('[type=submit]');
  if (form.elements.newPassword.value !== form.elements.confirmPassword.value) {
    message('#passwordMsg', 'كلمتا المرور الجديدتان غير متطابقتين.', 'error');
    return;
  }
  button.disabled = true;
  try {
    const result = await api('/api/auth/password', { method: 'POST', body: JSON.stringify({ currentPassword: form.elements.currentPassword.value, newPassword: form.elements.newPassword.value }) });
    token = result.token;
    form.reset();
    message('#passwordMsg', 'تم تغيير كلمة المرور وإبطال الجلسات السابقة.', 'success');
  } catch (error) { message('#passwordMsg', translateError(error), 'error'); }
  finally { button.disabled = false; }
});

async function loadAudit() {
  try {
    const rows = await api('/api/admin/audit');
    q('#auditList').innerHTML = rows.map((entry) => `<article class="admin-item"><div class="admin-item-main"><strong>${esc(entry.action)} · ${esc(entry.entity)}</strong><p>${esc(entry.created_at)} · ${esc(entry.actor_id || 'النظام')} · ${esc(entry.entity_id || '')}</p><p>${esc(entry.detail || '{}')}</p></div></article>`).join('') || '<p>السجل فارغ.</p>';
  } catch (error) { q('#auditList').textContent = translateError(error); }
}


let ledgerAccounts = [];
function addLedgerLineRow(initial = {}) {
  const container = q('#ledgerLines');
  const row = document.createElement('article'); row.className = 'admin-item ledger-line-row';
  const options = ledgerAccounts.filter((account) => account.active).map((account) => `<option value="${esc(account.code)}" ${account.code === initial.accountCode ? 'selected' : ''}>${esc(account.code)} — ${esc(account.name)}</option>`).join('');
  row.innerHTML = `<label>الحساب<select data-account required>${options}</select></label><label>الجانب<select data-side><option value="debit" ${initial.side === 'debit' ? 'selected' : ''}>مدين</option><option value="credit" ${initial.side === 'credit' ? 'selected' : ''}>دائن</option></select></label><label>المبلغ بالريال<input data-amount type="number" min="0.01" max="100000000" step="0.01" value="${initial.amount || ''}" required></label><label>ملاحظة<input data-note maxlength="300" value="${esc(initial.note || '')}"></label><button type="button" data-remove-line>إزالة البند</button>`;
  row.querySelector('[data-remove-line]').addEventListener('click', () => { if (container.children.length > 2) row.remove(); else message('#ledgerMsg', 'يجب أن يحتوي القيد على بندين على الأقل.', 'error'); });
  container.appendChild(row);
}
async function loadLedger() {
  try {
    [ledgerAccounts] = [await api('/api/admin/ledger/accounts')];
    const journals = await api('/api/admin/ledger?limit=100');
    if (!q('#ledgerLines').children.length) { addLedgerLineRow({ accountCode: '1000', side: 'debit' }); addLedgerLineRow({ accountCode: '4000', side: 'credit' }); }
    q('#ledgerList').innerHTML = journals.map((journal) => `<article class="admin-item"><div class="admin-item-main"><strong>${esc(journal.memo)}</strong><p>المرجع: ${esc(journal.reference || '—')} · ${esc(journal.created_at)}</p><p>المدين: ${money(journal.totalDebitSAR)} · الدائن: ${money(journal.totalCreditSAR)}</p><ul>${journal.lines.map((line) => `<li>${esc(line.account_code)} — ${esc(line.account_name)}: مدين ${money(line.debitSAR)} / دائن ${money(line.creditSAR)} ${esc(line.note)}</li>`).join('')}</ul></div><span class="muted">قيد مرحّل وغير قابل للتعديل</span></article>`).join('') || '<p>لا توجد قيود مالية مرحّلة.</p>';
    message('#ledgerMsg', 'تم تحميل الدفتر والحسابات. لا تُرحّل قيدًا إلا بناءً على مستند حقيقي.', 'muted');
  } catch (error) { message('#ledgerMsg', translateError(error), 'error'); }
}
q('#addLedgerLine').addEventListener('click', () => { if (ledgerAccounts.length) addLedgerLineRow(); });
q('#reloadLedger').addEventListener('click', loadLedger);
q('#ledgerForm').addEventListener('submit', async (event) => {
  event.preventDefault(); const form = event.currentTarget; const button = form.querySelector('[type="submit"]'); button.disabled = true;
  try {
    const lines = [...q('#ledgerLines').querySelectorAll('.ledger-line-row')].map((row) => {
      const amount = Number(row.querySelector('[data-amount]').value); const side = row.querySelector('[data-side]').value;
      return { accountCode: row.querySelector('[data-account]').value, debitSAR: side === 'debit' ? amount : 0, creditSAR: side === 'credit' ? amount : 0, note: row.querySelector('[data-note]').value };
    });
    const result = await api('/api/admin/ledger/manual', { method: 'POST', body: JSON.stringify({ memo: form.elements.memo.value, reference: form.elements.reference.value, lines }) });
    message('#ledgerMsg', `تم ترحيل القيد ${result.id}. المدين والدائن متساويان: ${money(result.totalDebitSAR)}.`, 'success');
    form.elements.memo.value = ''; form.elements.reference.value = '';
    q('#ledgerLines').innerHTML = ''; addLedgerLineRow({ accountCode: '1000', side: 'debit' }); addLedgerLineRow({ accountCode: '4000', side: 'credit' });
    await loadLedger();
  } catch (error) { const translated = error.message === 'LEDGER_UNBALANCED' ? 'القيد غير متوازن: يجب أن يساوي إجمالي المدين إجمالي الدائن حتى الهللة.' : error.message === 'LEDGER_REFERENCE_ALREADY_EXISTS' ? 'هذا المرجع مستخدم من قبل.' : translateError(error); message('#ledgerMsg', translated, 'error'); }
  finally { button.disabled = false; }
});

document.querySelectorAll('[data-tab]').forEach((button) => button.addEventListener('click', async () => {
  document.querySelectorAll('[id^="tab-"]').forEach((section) => section.classList.add('hidden'));
  const target = q(`#tab-${button.dataset.tab}`);
  if (!target || (role !== 'owner' && target.classList.contains('owner-only'))) return;
  target.classList.remove('hidden');
  if (button.dataset.tab === 'categories') await loadCategories();
  if (button.dataset.tab === 'reservations') await loadReservations();
  if (button.dataset.tab === 'audit') await loadAudit();
  if (button.dataset.tab === 'ledger') await loadLedger();
  if (button.dataset.tab === 'settings') await loadSettings();
  if (button.dataset.tab === 'assistants') await loadAssistants();
  if (button.dataset.tab === 'products') await loadProducts();
}));
q('#reloadReservations').addEventListener('click', loadReservations);
q('#reloadAudit').addEventListener('click', loadAudit);
q('#logout').addEventListener('click', async () => {
  try { if (token) await api('/api/auth/logout', { method: 'POST' }); } catch { /* clear the local session even if the network is unavailable */ }
  token = ''; role = ''; userProducts = []; adminCategories = [];
  q('#loginForm').reset(); q('#setupForm').reset(); q('#productForm').reset();
  q('#productForm').classList.add('hidden');
  show('loginView');
});

if ('serviceWorker' in navigator) window.addEventListener('load', () => navigator.serviceWorker.register('/admin/sw.js', { scope: '/admin/' }).catch(() => {}));
