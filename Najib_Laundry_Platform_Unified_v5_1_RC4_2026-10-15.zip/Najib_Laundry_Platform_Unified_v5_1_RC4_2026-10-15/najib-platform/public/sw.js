/* Customer PWA only. Never cache admin pages/assets, API payloads, or personal data. */
const CACHE = 'najib-customer-shell-v6';
const SHELL = [
  '/', '/style.css', '/app.js', '/manifest.webmanifest', '/icon.svg',
  '/icons/najib-app-192.png', '/icons/najib-app-512.png', '/icons/najib-app-180.png',
  '/brand/najib-logo.webp'
];
self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE).then((cache) => cache.addAll(SHELL)));
  self.skipWaiting();
});
self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((key) => key.startsWith('najib-customer-') && key !== CACHE).map((key) => caches.delete(key)));
    await self.clients.claim();
  })());
});
self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin || url.pathname === '/api' || url.pathname.startsWith('/api/') ||
      url.pathname === '/admin' || url.pathname.startsWith('/admin/') ||
      url.pathname.startsWith('/owner-control') || url.pathname === '/owner.js' || url.pathname === '/owner.css' ||
      url.pathname === '/admin-manifest.webmanifest') return;
  event.respondWith((async () => {
    try {
      const response = await fetch(request);
      if (response.ok && response.type === 'basic' && SHELL.includes(url.pathname)) {
        const cache = await caches.open(CACHE);
        cache.put(request, response.clone()).catch(() => {});
      }
      return response;
    } catch {
      const cached = await caches.match(request);
      if (cached) return cached;
      if (request.mode === 'navigate' && url.pathname === '/') return (await caches.match('/')) || Response.error();
      return Response.error();
    }
  })());
});
