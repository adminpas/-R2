import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const envPath = path.join(root, '.env');
const examplePath = path.join(root, '.env.example');
const nodeMajor = Number(process.versions.node.split('.')[0]);
if (nodeMajor < 20) {
  console.error(`يتطلب المشروع Node.js 20 أو أحدث. النسخة الحالية: ${process.versions.node}`);
  process.exit(1);
}
if (fs.existsSync(envPath)) {
  const existing = fs.readFileSync(envPath, 'utf8');
  if (/replace-this-development-secret|replace-with-a-unique-strong-password/.test(existing)) {
    console.error('ملف .env يحتوي أسرارًا افتراضية. عدّل JWT_SECRET وADMIN_PASSWORD يدويًا ثم أعد التشغيل. لم أغيّر ملفك.');
    process.exit(1);
  }
  console.log('تم العثور على .env موجود؛ لم يتم تغيير أي سر أو بيانات.');
  process.exit(0);
}
const pick = (chars) => chars[crypto.randomInt(chars.length)];
const pool = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@_+-';
const parts = [pick('ABCDEFGHJKLMNPQRSTUVWXYZ'), pick('abcdefghijkmnopqrstuvwxyz'), pick('23456789'), pick('!@_+-')];
while (parts.length < 24) parts.push(pick(pool));
for (let i = parts.length - 1; i > 0; i--) {
  const j = crypto.randomInt(i + 1);
  [parts[i], parts[j]] = [parts[j], parts[i]];
}
const initialPassword = parts.join('');
const jwtSecret = crypto.randomBytes(48).toString('base64url');
let env = fs.readFileSync(examplePath, 'utf8');
env = env.replace(/^JWT_SECRET=.*$/m, `JWT_SECRET=${jwtSecret}`)
  .replace(/^ADMIN_USERNAME=.*$/m, 'ADMIN_USERNAME=admin')
  .replace(/^ADMIN_PASSWORD=.*$/m, `ADMIN_PASSWORD=${initialPassword}`);
fs.writeFileSync(envPath, env, { mode: 0o600, flag: 'wx' });
console.log('\nتم إنشاء .env محليًا بأسرار عشوائية. لا ترفع هذا الملف إلى Git ولا تشارك كلمة المرور.');
console.log('اسم المستخدم الأولي: admin');
console.log(`كلمة المرور الأولية: ${initialPassword}`);
console.log('ستُطلب منك بعد الدخول أول مرة بيانات المالك وكلمة مرور جديدة. احفظ كلمة المرور مؤقتًا في مكان آمن.\n');
