@echo off
setlocal
cd /d "%~dp0"
node scripts\bootstrap-local.mjs
if errorlevel 1 exit /b %errorlevel%
npm install --no-audit --no-fund
if errorlevel 1 exit /b %errorlevel%
npm run test:all
if errorlevel 1 exit /b %errorlevel%
npm start
