#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
node scripts/bootstrap-local.mjs
npm install --no-audit --no-fund
npm run test:all
npm start
