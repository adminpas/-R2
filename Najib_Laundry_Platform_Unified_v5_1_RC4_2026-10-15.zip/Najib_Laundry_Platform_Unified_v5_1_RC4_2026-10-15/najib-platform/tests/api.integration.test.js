import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const sandbox = fs.mkdtempSync(path.join(os.tmpdir(), 'najib-integration-'));
process.env.NODE_ENV = 'test';
process.env.JWT_SECRET = 'integration-test-secret-which-is-long-enough-42';
process.env.ADMIN_USERNAME = 'initialowner';
process.env.ADMIN_PASSWORD = 'Initial-Test-Change1!';
process.env.DB_PATH = path.join(sandbox, 'app.sqlite');
process.env.MEDIA_ROOT = path.join(sandbox, 'storage');
process.env.HOLD_HOURS = '24';
process.env.ADMIN_HOST = '';
process.env.AI_API_KEY = '';
process.env.AI_MODEL = '';

const { app, db } = await import('../src/server.js');
const server = app.listen(0, '127.0.0.1');
await new Promise((resolve) => server.once('listening', resolve));
const base = `http://127.0.0.1:${server.address().port}`;
async function json(pathname, { token, ...options } = {}) {
  const headers = { Accept: 'application/json', ...(options.headers || {}) };
  if (token) headers.Authorization = `Bearer ${token}`;
  if (options.body && !(options.body instanceof FormData) && !headers['Content-Type']) headers['Content-Type'] = 'application/json';
  const response = await fetch(base + pathname, { ...options, headers });
  const body = await response.json();
  return { response, body };
}
test('API lifecycle: owner setup, product create, 24-hour hold, inventory and legal status changes', async (t) => {
  t.after(async () => {
    await new Promise((resolve) => server.close(resolve));
    db.close();
    fs.rmSync(sandbox, { recursive: true, force: true });
  });

  const health = await json('/api/health');
  assert.equal(health.response.status, 200);
  assert.equal(health.body.database, 'connected');

  const ownerRedirect = await fetch(base + '/admin', { redirect: 'manual' });
  assert.equal(ownerRedirect.status, 302);
  assert.equal(ownerRedirect.headers.get('location'), '/admin/');
  const customerPwa = await fetch(base + '/manifest.webmanifest');
  assert.equal(customerPwa.status, 200);
  assert.equal((await customerPwa.json()).start_url, '/');
  const ownerPwa = await fetch(base + '/admin-manifest.webmanifest');
  assert.equal(ownerPwa.status, 200);
  assert.equal((await ownerPwa.json()).scope, '/admin/');
  const ownerWorker = await fetch(base + '/admin/sw.js');
  assert.equal(ownerWorker.status, 200);
  assert.match(await ownerWorker.text(), /najib-owner-shell-v1/);

  let result = await json('/api/auth/login', { method: 'POST', body: JSON.stringify({ username: 'initialowner', password: 'Initial-Test-Change1!' }) });
  assert.equal(result.response.status, 200);
  assert.equal(result.body.setupRequired, true);
  let token = result.body.token;

  result = await json('/api/auth/setup', { method: 'POST', token, body: JSON.stringify({
    fullName: 'مالك اختبار', mobile: '0512345678', email: 'owner@example.test', username: 'ownerfinal', password: 'Owner-Final1!'
  }) });
  assert.equal(result.response.status, 200);
  token = result.body.token;

  const initialAudit = await json('/api/admin/assistant/audit', { method: 'POST', token, body: '{}' });
  assert.equal(initialAudit.response.status, 200);
  assert.equal(initialAudit.body.mode, 'rules_fallback');
  assert.ok(Array.isArray(initialAudit.body.findings));
  assert.equal('customer_name' in initialAudit.body, false);

  const invalidFixedPrice = await json('/api/admin/settings', { method: 'PATCH', token, body: JSON.stringify({ services: [{ id: 'transport', name: 'النقل', enabled: true, pricingMode: 'fixed', basePrice: 0 }] }) });
  assert.equal(invalidFixedPrice.response.status, 400);
  assert.equal(invalidFixedPrice.body.error, 'VALIDATION_FAILED');

  const categories = await json('/api/categories');
  assert.ok(categories.body.length > 0);
  const data = new FormData();
  data.set('name', 'غسالة اختبار آلي');
  data.set('category', categories.body[0].name);
  data.set('condition', 'new');
  data.set('description', 'منتج مخصص لقاعدة بيانات الاختبار فقط');
  data.set('priceSAR', '1000');
  data.set('stockQuantity', '1');
  result = await json('/api/admin/products', { method: 'POST', token, body: data });
  assert.equal(result.response.status, 201);
  const productId = result.body.id;

  const reservationInput = { productId, customerName: 'عميل اختبار', mobile: '0512345678', email: 'customer@example.test', businessName: 'مغسلة الاختبار', siteAddress: 'جدة - موقع الاختبار', services: ['transport', 'installation'] };
  result = await json('/api/reservations', { method: 'POST', body: JSON.stringify(reservationInput) });
  assert.equal(result.response.status, 201);
  assert.equal(result.body.status, 'held');
  assert.ok(Date.parse(result.body.expiresAt) - Date.now() > 23 * 60 * 60 * 1000);
  const reservationId = result.body.id;
  const inventoryAudit = await json('/api/admin/assistant/audit', { method: 'POST', token, body: '{}' });
  assert.equal(inventoryAudit.response.status, 200);
  assert.equal(inventoryAudit.body.inventory.activeProducts, 1);
  assert.equal(inventoryAudit.body.reservations.held, 1);
  assert.equal('mobile' in inventoryAudit.body, false);
  result = await json('/api/reservations', { method: 'POST', body: JSON.stringify({ ...reservationInput, services: ['not-a-real-service'] }) });
  assert.equal(result.response.status, 400);
  assert.equal(result.body.error, 'INVALID_SERVICE_SELECTION');
  result = await json('/api/admin/reservations', { token });
  const reservationRow = result.body.find((row) => row.id === reservationId);
  assert.ok(reservationRow);
  const selectedServices = JSON.parse(reservationRow.services_json);
  assert.deepEqual(selectedServices.map((item) => item.id), ['transport', 'installation']);
  assert.ok(selectedServices.every((item) => item.pricingMode === 'quote' && item.priceSAR === null));

  // Assistant accounts get an operational queue, not customer PII or reservation state-changing privileges.
  result = await json('/api/admin/assistants', { method: 'POST', token, body: JSON.stringify({
    fullName: 'مساعد اختبار', username: 'helper1', password: 'Assistant-Test1!', mobile: '0523456789', email: 'helper@example.test'
  }) });
  assert.equal(result.response.status, 201);
  result = await json('/api/admin/assistants', { token });
  assert.equal(result.response.status, 200);
  assert.equal(result.body.length, 1);
  assert.equal(result.body[0].username, 'helper1');
  assert.equal('password_hash' in result.body[0], false);
  result = await json('/api/auth/login', { method: 'POST', body: JSON.stringify({ username: 'helper1', password: 'Assistant-Test1!' }) });
  assert.equal(result.response.status, 200);
  const assistantToken = result.body.token;

  // Financial manual journal: balanced entries post atomically, invalid totals and assistants are rejected.
  result = await json('/api/admin/ledger/manual', { method: 'POST', token, body: JSON.stringify({
    memo: 'قيد رأس مال اختبار', reference: 'integration-ledger-01', lines: [
      { accountCode: '1000', debitSAR: 100, creditSAR: 0, note: 'إيداع نقدي اختباري' },
      { accountCode: '3000', debitSAR: 0, creditSAR: 100, note: 'رأس المال الاختباري' }
    ]
  }) });
  assert.equal(result.response.status, 201);
  assert.equal(result.body.totalDebitSAR, 100);
  assert.equal(result.body.totalCreditSAR, 100);
  assert.equal(result.body.immutable, true);
  const ledger = await json('/api/admin/ledger', { token });
  const postedJournal = ledger.body.find((journal) => journal.id === result.body.id);
  assert.ok(postedJournal);
  assert.equal(postedJournal.lines.length, 2);
  assert.equal(postedJournal.total_debit_halalas, postedJournal.total_credit_halalas);
  const unbalancedJournal = await json('/api/admin/ledger/manual', { method: 'POST', token, body: JSON.stringify({
    memo: 'قيد غير متوازن', lines: [
      { accountCode: '1000', debitSAR: 100, creditSAR: 0 },
      { accountCode: '3000', debitSAR: 0, creditSAR: 90 }
    ]
  }) });
  assert.equal(unbalancedJournal.response.status, 400);
  assert.equal(unbalancedJournal.body.error, 'LEDGER_UNBALANCED');
  const assistantLedger = await json('/api/admin/ledger', { token: assistantToken });
  assert.equal(assistantLedger.response.status, 403);
  const assistantLedgerPost = await json('/api/admin/ledger/manual', { method: 'POST', token: assistantToken, body: JSON.stringify({
    memo: 'ممنوع', lines: [ { accountCode: '1000', debitSAR: 1, creditSAR: 0 }, { accountCode: '3000', debitSAR: 0, creditSAR: 1 } ]
  }) });
  assert.equal(assistantLedgerPost.response.status, 403);
  assert.throws(() => db.prepare('UPDATE ledger_journals SET memo=? WHERE id=?').run('tampered', result.body.id), /IMMUTABLE_LEDGER/);

  result = await json('/api/admin/reservations', { token: assistantToken });
  assert.equal(result.response.status, 200);
  assert.equal(result.body[0].product_name, 'غسالة اختبار آلي');
  assert.equal('id' in result.body[0], false);
  assert.equal('customer_name' in result.body[0], false);
  assert.equal('mobile' in result.body[0], false);
  assert.equal('site_address' in result.body[0], false);
  result = await json(`/api/admin/reservations/${reservationId}`, { method: 'PATCH', token: assistantToken, body: JSON.stringify({ status: 'cancelled' }) });
  assert.equal(result.response.status, 403);
  assert.equal(result.body.error, 'FORBIDDEN');

  const duplicate = await json('/api/reservations', { method: 'POST', body: JSON.stringify(reservationInput) });
  assert.equal(duplicate.response.status, 409);
  assert.equal(duplicate.body.error, 'OUT_OF_STOCK');

  result = await json(`/api/admin/reservations/${reservationId}`, { method: 'PATCH', token, body: JSON.stringify({ status: 'confirmed' }) });
  assert.equal(result.response.status, 200);
  result = await json(`/api/admin/reservations/${reservationId}`, { method: 'PATCH', token, body: JSON.stringify({ status: 'confirmed' }) });
  assert.equal(result.response.status, 409);
  assert.equal(result.body.error, 'INVALID_STATUS_TRANSITION');
  result = await json(`/api/admin/reservations/${reservationId}`, { method: 'PATCH', token, body: JSON.stringify({ status: 'completed' }) });
  assert.equal(result.response.status, 200);

  const products = await json('/api/products');
  const item = products.body.find((product) => product.id === productId);
  assert.equal(item.stock_quantity, 0);
  assert.equal(item.availableQuantity, 0);

  // An unavailable item must not be recommended by the assistant as an available option.
  result = await json('/api/assistant/recommend', { method: 'POST', body: JSON.stringify({ question: 'أريد غسالة كمبيوتر' }) });
  assert.equal(result.response.status, 200);
  assert.equal(result.body.products.some((product) => product.name === 'غسالة اختبار آلي'), false);

  const unknownApi = await json('/api/does-not-exist');
  assert.equal(unknownApi.response.status, 404);
  assert.equal(unknownApi.body.error, 'API_ROUTE_NOT_FOUND');

  result = await json('/api/admin/assistants/' + (await json('/api/admin/assistants', { token })).body[0].id, { method: 'PATCH', token, body: JSON.stringify({ active: false }) });
  assert.equal(result.response.status, 200);
  const disabledAssistantToken = await json('/api/admin/reservations', { token: assistantToken });
  assert.equal(disabledAssistantToken.response.status, 401);
  const disabledLogin = await json('/api/auth/login', { method: 'POST', body: JSON.stringify({ username: 'helper1', password: 'Assistant-Test1!' }) });
  assert.equal(disabledLogin.response.status, 401);
  result = await json('/api/admin/assistants/' + (await json('/api/admin/assistants', { token })).body[0].id, { method: 'PATCH', token, body: JSON.stringify({ active: true }) });
  assert.equal(result.response.status, 200);

  const repeatSetup = await json('/api/auth/setup', { method: 'POST', token, body: JSON.stringify({
    fullName: 'مالك اختبار', mobile: '0512345678', email: 'owner@example.test', username: 'ownerother', password: 'Owner-Final2!'
  }) });
  assert.equal(repeatSetup.response.status, 409);

  result = await json('/api/auth/password', { method: 'POST', token, body: JSON.stringify({ currentPassword: 'Wrong-Current1!', newPassword: 'Owner-Changed1!' }) });
  assert.equal(result.response.status, 403);
  assert.equal(result.body.error, 'CURRENT_PASSWORD_INCORRECT');
  result = await json('/api/auth/password', { method: 'POST', token, body: JSON.stringify({ currentPassword: 'Owner-Final1!', newPassword: 'Owner-Changed1!' }) });
  assert.equal(result.response.status, 200);
  const rotatedToken = result.body.token;
  const oldTokenCheck = await json('/api/admin/overview', { token });
  assert.equal(oldTokenCheck.response.status, 401);
  const newTokenCheck = await json('/api/admin/overview', { token: rotatedToken });
  assert.equal(newTokenCheck.response.status, 200);
  const logout = await json('/api/auth/logout', { method: 'POST', token: rotatedToken });
  assert.equal(logout.response.status, 200);
  const loggedOutCheck = await json('/api/admin/overview', { token: rotatedToken });
  assert.equal(loggedOutCheck.response.status, 401);
});
