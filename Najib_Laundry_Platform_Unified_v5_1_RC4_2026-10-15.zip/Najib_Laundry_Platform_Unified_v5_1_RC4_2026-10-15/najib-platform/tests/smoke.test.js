import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');

test('local bootstrap and cross-platform launcher instructions ship without embedded credentials', () => {
  assert.ok(fs.existsSync(path.join(root, 'scripts/bootstrap-local.mjs')));
  assert.ok(fs.existsSync(path.join(root, 'start-local.sh')));
  assert.ok(fs.existsSync(path.join(root, 'start-local.bat')));
  const bootstrap = read('scripts/bootstrap-local.mjs');
  assert.match(bootstrap, /randomBytes\(48\)/);
  assert.match(bootstrap, /flag: 'wx'/);
  assert.doesNotMatch(bootstrap, /admin123/);
});

test('required source files and local PWA shell exist', () => {
  for (const file of ['src/server.js','public/index.html','public/app.js','public/sw.js','public/manifest.webmanifest','public/admin-manifest.webmanifest','public/icon.svg','public/owner.html','public/owner.js','public/owner.css','README.md','DEPLOYMENT_CHECKLIST_AR.md','.env.example']) {
    assert.ok(fs.existsSync(path.join(root, file)), `missing ${file}`);
  }
});

test('customer storefront remains separate and contains no admin link or authentication form', () => {
  const html = read('public/index.html');
  assert.doesNotMatch(html, /owner-control|href=["']\/admin|لوحة التحكم|تسجيل الدخول/);
  assert.match(html, /id="products"/);
  assert.match(html, /id="reserveForm"/);
});

test('both documented owner paths serve the separate dashboard source', () => {
  const server = read('src/server.js');
  assert.match(server, /app\.get\('\/admin', \(_req, res\) => res\.redirect\(302, '\/admin\/'\)\)/);
  assert.match(server, /app\.get\(\['\/admin\/', '\/owner-control', '\/owner-control\/'\]/);
  assert.match(server, /public', 'owner\.html/);
});

test('production blocks weak or implicit startup secrets', () => {
  const server = read('src/server.js');
  assert.match(server, /Production requires JWT_SECRET/);
  assert.match(server, /Production requires a unique strong ADMIN_PASSWORD/);
  assert.match(server, /Set ADMIN_PASSWORD in \.env before first startup/);
  assert.match(server, /Production blocked: an owner account still uses a known default password/);
  assert.match(server, /dotenv\/config/);
});

test('first owner setup can only be completed once', () => {
  const server = read('src/server.js');
  assert.match(server, /req\.path !== '\/api\/auth\/setup'/);
  assert.match(server, /SETUP_ALREADY_COMPLETED/);
});

test('held and confirmed reservations expire automatically at their persisted 24-hour deadline', () => {
  const server = read('src/server.js');
  assert.match(server, /WHERE status IN \('held','confirmed'\) AND expires_at<=\?/);
  assert.match(server, /\['held', 'confirmed'\]\.includes\(current\.status\) && current\.expires_at <= now/);
  assert.match(server, /AND r\.expires_at>\?/);
});

test('reservation transitions are validated and audited', () => {
  const server = read('src/server.js');
  assert.match(server, /INVALID_STATUS_TRANSITION/);
  assert.match(server, /reservation_status_updated/);
  assert.match(server, /INVENTORY_RECONCILIATION_REQUIRED/);
});

test('assistant product response is stripped of prices and sensitive product administration fields', () => {
  const server = read('src/server.js');
  assert.match(server, /if \(req\.user\.role === 'owner'\) return res\.json\(rows\.map/);
  assert.match(server, /name: p\.name, category: p\.category, condition: p\.condition, description: p\.description, active: p\.active/);
  assert.match(server, /ASSISTANT_DESCRIPTION_ONLY/);
});

test('uploads are constrained by allowed MIME type and media signature checks', () => {
  const server = read('src/server.js');
  assert.match(server, /LIMIT_FILE_SIZE/);
  assert.match(server, /verifyMagic/);
  assert.match(server, /12 \* 1024 \* 1024/);
  assert.match(server, /150 \* 1024 \* 1024/);
});

test('categories are seeded without inventing equipment, and catalog management is present', () => {
  const server = read('src/server.js');
  assert.match(server, /initialCategories/);
  assert.match(server, /app\.post\('\/api\/admin\/categories', auth, owner/);
  assert.match(server, /app\.patch\('\/api\/admin\/categories\/:id', auth, owner/);
  assert.match(read('public/owner.html'), /id="categoryForm"/);
});

test('customer and owner PWAs have separate service-worker scopes and namespaced caches', () => {
  const sw = read('public/sw.js');
  const ownerSw = read('public/admin/sw.js');
  assert.match(sw, /url\.pathname\.startsWith\('\/api\/'\)/);
  assert.match(sw, /startsWith\('\/admin\/'\)/);
  const customerShell = sw.match(/const SHELL = \[([\s\S]*?)\];/)?.[1] || '';
  assert.doesNotMatch(customerShell, /owner\.js|owner\.css|admin-manifest|\/admin/);
  assert.match(sw, /key\.startsWith\('najib-customer-'\)/);
  assert.match(sw, /SHELL\.includes\(url\.pathname\)/);
  assert.match(ownerSw, /SHELL\.includes\(url\.pathname\)/);
  assert.doesNotMatch(sw.match(/const SHELL = \[([\s\S]*?)\];/)?.[1] || '', /\/storage/);
  assert.match(ownerSw, /key\.startsWith\('najib-owner-'\)/);
  assert.match(read('public/admin-manifest.webmanifest'), /\"start_url\": \"\/admin\/\"/);
  assert.match(read('public/admin-manifest.webmanifest'), /\"scope\": \"\/admin\/\"/);
  assert.match(read('public/owner.js'), /register\('\/admin\/sw\.js', \{ scope: '\/admin\/' \}\)/);
});

test('owner can manage persistent platform settings and customer receives only safe public settings', () => {
  const server = read('src/server.js');
  assert.match(server, /app\.get\('\/api\/public-settings'/);
  assert.match(server, /app\.get\('\/api\/admin\/settings', auth, owner/);
  assert.match(server, /app\.patch\('\/api\/admin\/settings', auth, owner/);
  assert.match(server, /settingSet\.run\(key, JSON\.stringify\(value\)\)/);
  assert.match(read('public/owner.html'), /id="settingsForm"/);
  assert.match(read('public/owner.js'), /\/api\/admin\/settings/);
});

test('customer AI assistant is rate-limited, catalog-grounded and has a transparent fallback', () => {
  const server = read('src/server.js');
  assert.match(server, /app\.post\('\/api\/assistant\/recommend', assistantLimiter/);
  assert.match(server, /mode: 'catalog_fallback'/);
  assert.match(server, /لم يتم إعداد مزود ذكاء اصطناعي خارجي/);
  assert.match(read('public/index.html'), /id="advisorForm"/);
  assert.match(read('public/app.js'), /\/api\/assistant\/recommend/);
});


test('assistant cannot change reservation status and only receives a redacted reservation queue', () => {
  const server = read('src/server.js');
  assert.match(server, /app\.patch\('\/api\/admin\/reservations\/:id', auth, owner/);
  assert.match(server, /Assistants may see an operational queue only/);
  assert.match(server, /product_name: r\.product_name, status: r\.status, created_at: r\.created_at, expires_at: r\.expires_at/);
  const ownerUi = read('public/owner.js');
  assert.match(ownerUi, /role !== 'owner' \? ''/);
});

test('AI provider placeholders do not count as a configured provider and answers have bounded tokens', () => {
  const server = read('src/server.js');
  assert.match(server, /function aiProviderConfigured\(\)/);
  assert.match(server, /const aiReady = Boolean\(key && model && !key\.startsWith\('replace-'\) && !model\.startsWith\('replace-'\)\)/);
  assert.match(server, /max_tokens: 700/);
  assert.match(server, /available_quantity/);
  assert.match(server, /r\.expires_at>\?/);
  assert.match(server, /مدخلًا غير موثوق/);
});


test('assistant recommendations exclude products with no available stock and distinguish unavailable catalog', () => {
  const server = read('src/server.js');
  assert.match(server, /filter\(\(p\) => p\.available_quantity > 0\)/);
  assert.match(server, /publishedProductCount > 0/);
  assert.match(server, /لا تظهر حاليًا معدات متاحة للحجز/);
});


test('v5 carries the transparent company mark in both isolated web apps and caches the optimized local asset', () => {
  assert.ok(fs.existsSync(path.join(root, 'public/brand/najib-logo.webp')));
  assert.match(read('public/index.html'), /brand\/najib-logo\.webp/);
  assert.match(read('public/owner.html'), /brand\/najib-logo\.webp/);
  assert.match(read('public/sw.js'), /najib-customer-shell-v6/);
  assert.match(read('public/sw.js'), /brand\/najib-logo\.webp/);
  assert.match(read('public/admin/sw.js'), /najib-owner-shell-v1/);
});

test('optional service choices are persisted as a trusted snapshot and are never silently charged', () => {
  const server = read('src/server.js');
  assert.match(server, /services_json TEXT NOT NULL DEFAULT '\[\]'/);
  assert.match(server, /ALTER TABLE reservations ADD COLUMN services_json/);
  assert.match(server, /INVALID_SERVICE_SELECTION/);
  assert.match(server, /fixedPriceIsValid \? Number\(basePrice\) : null/);
  assert.match(server, /no payment was collected/);
  assert.match(read('public/index.html'), /خدمات إضافية اختيارية/);
  assert.match(read('public/app.js'), /body\.services = \[\.\.\.form\.querySelectorAll/);
  assert.match(read('public/owner.js'), /JSON\.parse\(reservation\.services_json/);
});

test('auth sessions are database-backed and can be revoked on logout or password rotation', () => {
  const server = read('src/server.js');
  assert.match(server, /CREATE TABLE IF NOT EXISTS auth_sessions/);
  assert.match(server, /payload\.jti/);
  assert.match(server, /app\.post\('\/api\/auth\/logout', auth/);
  assert.match(server, /app\.post\('\/api\/auth\/password', auth/);
  assert.match(server, /UPDATE auth_sessions SET revoked_at/);
  assert.match(read('public/owner.html'), /id="passwordForm"/);
});

test('legacy reference is quarantined as design-only and does not replace the API-connected showroom', () => {
  assert.ok(fs.existsSync(path.join(root, '..', 'reference/legacy-visual-only/market-legacy-visual-reference.html')));
  const publicHtml = read('public/index.html');
  assert.doesNotMatch(publicHtml, /0555-000-000|19,500 ر\.س/);
  assert.match(read('public/app.js'), /jsonRequest\('\/api\/products'/);
});


test('owner can list and disable assistant accounts with session revocation, and fixed services require an explicit positive price', () => {
  const server = read('src/server.js');
  assert.match(server, /app\.get\('\/api\/admin\/assistants', auth, owner/);
  assert.match(server, /app\.patch\('\/api\/admin\/assistants\/:id', auth, owner/);
  assert.match(server, /assistant_deactivated/);
  assert.match(server, /UPDATE auth_sessions SET revoked_at=.*assistant\.id/);
  assert.match(server, /service\.pricingMode !== 'fixed' \|\| service\.basePrice > 0/);
  assert.match(server, /Number\(basePrice\) > 0/);
  assert.match(read('public/owner.html'), /id="assistantsList"/);
  assert.match(read('public/owner.js'), /loadAssistants/);
});


test('PWA installs use local PNG app icons for Android and Apple touch icon for iOS', () => {
  for (const size of ['180', '192', '512']) assert.ok(fs.existsSync(path.join(root, `public/icons/najib-app-${size}.png`)));
  assert.match(read('public/index.html'), /apple-touch-icon/);
  assert.match(read('public/owner.html'), /apple-touch-icon/);
  assert.match(read('public/sw.js'), /icons\/najib-app-512\.png/);
  assert.match(read('public/manifest.webmanifest'), /najib-app-192\.png/);
  assert.match(read('public/admin-manifest.webmanifest'), /najib-app-512\.png/);
});


test('reservation policy is fixed at exactly 24 hours', () => {
  const server = read('src/server.js');
  assert.match(server, /const defaultReservationHours = 24/);
  assert.match(server, /function currentReservationHours\(\) \{ return 24; \}/);
  assert.match(server, /holdHours: z\.literal\(24\)\.optional\(\)/);
  assert.match(read('public/owner.html'), /name="holdHours" type="number" value="24" min="24" max="24" step="1" readonly/);
});

test('runtime ledger DDL has a dedicated executable SQLite verification tool', () => {
  assert.ok(fs.existsSync(path.join(root, 'tools/validate_runtime_ledger.py')));
  assert.match(read('package.json'), /validate_runtime_ledger\.py/);
});

test('manual ledger is owner-only, balanced in SAR halalas and append-only', () => {
  const server = read('src/server.js');
  assert.match(server, /app\.get\('\/api\/admin\/ledger\/accounts', auth, owner/);
  assert.match(server, /app\.get\('\/api\/admin\/ledger', auth, owner/);
  assert.match(server, /app\.post\('\/api\/admin\/ledger\/manual', auth, owner/);
  assert.match(server, /LEDGER_UNBALANCED/);
  assert.match(server, /Math\.round\(line\.debitSAR \* 100\)/);
  assert.match(server, /LEDGER_ACCOUNT_UNAVAILABLE/);
  assert.match(read('database/schema.sqlite.sql'), /ledger_journals_post_balance/);
  assert.match(read('database/schema.sqlite.sql'), /ledger_lines_no_insert_after_post/);
  assert.match(read('database/schema.sqlite.sql'), /ledger_lines_no_update[^\n]*NEW\.journal_id/);
  for (const table of ['ledger_journals','ledger_lines']) {
    assert.match(read('database/schema.sqlite.sql'), new RegExp(`${table}_no_update`));
    assert.match(read('database/schema.sqlite.sql'), new RegExp(`${table}_no_delete`));
  }
  assert.match(read('public/owner.html'), /id="tab-ledger"/);
  assert.match(read('public/owner.js'), /\/api\/admin\/ledger\/manual/);
});

test('offline mode stores only public catalog metadata and never queues a reservation offline', () => {
  const app = read('public/app.js');
  assert.match(app, /najib-public-catalog-cache-v1/);
  assert.match(app, /never cache reservations, login tokens, or customer PII/);
  assert.match(app, /الحجز وتأكيد المخزون يتطلبان اتصالًا بالخادم/);
  assert.match(app, /if \(!response\.ok\)/);
});


test('owner AI audit reviews aggregate inventory, booking, audit-log and ledger metrics without customer PII', () => {
  const server = read('src/server.js');
  assert.match(server, /app\.post\('\/api\/admin\/assistant\/audit', auth, owner, ownerAuditLimiter/);
  assert.match(server, /productsWithMissingOrInactiveCategory/);
  assert.match(server, /inconsistentPostedJournals/);
  assert.match(server, /recentActions/);
  assert.match(server, /Never send customer names, phone numbers, emails, addresses, tokens or raw log details/);
  assert.match(read('public/owner.html'), /id="runSystemAudit"/);
  assert.match(read('public/owner.js'), /\/api\/admin\/assistant\/audit/);
});


test('production requires a separate owner hostname and isolates administrative surfaces by host', () => {
  const server = read('src/server.js');
  assert.match(server, /Production requires ADMIN_HOST to isolate the owner app on a separate origin/);
  assert.match(server, /const isOwnerSurface = req\.path === '\/admin'/);
  assert.match(server, /hostname !== adminHost/);
  assert.match(server, /req\.path === '\/app\.js'.*req\.path === '\/sw\.js'.*req\.path === '\/manifest\.webmanifest'/);
});
