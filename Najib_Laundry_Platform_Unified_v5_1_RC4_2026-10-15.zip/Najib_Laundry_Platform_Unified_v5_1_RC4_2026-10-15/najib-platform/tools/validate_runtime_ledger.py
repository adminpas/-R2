#!/usr/bin/env python3
"""Execute financial DDL extracted from the actual server source in in-memory SQLite."""
from __future__ import annotations
import re
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "src" / "server.js"


def main() -> None:
    source = SOURCE.read_text(encoding="utf-8")
    match = re.search(
        r"// Financial tables are bootstrapped separately.*?db\.exec\(`(.*?)`\);",
        source,
        re.DOTALL,
    )
    assert match, "Could not find runtime financial DDL in src/server.js"
    db = sqlite3.connect(":memory:")
    db.execute("PRAGMA foreign_keys=ON")
    db.execute("CREATE TABLE users(id TEXT PRIMARY KEY)")
    db.executescript(match.group(1))
    tables = {row[0] for row in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    assert {"ledger_accounts", "ledger_journals", "ledger_lines"} <= tables
    db.execute("INSERT INTO users(id) VALUES('u1')")
    db.execute("INSERT INTO ledger_accounts(id,code,name,account_type) VALUES('a1','1000','Cash','asset')")
    db.execute("INSERT INTO ledger_accounts(id,code,name,account_type) VALUES('a2','3000','Capital','equity')")
    db.execute("INSERT INTO ledger_journals(id,reference,memo,total_debit_halalas,total_credit_halalas,created_by) VALUES('j1','r1','balanced test',100,100,'u1')")
    db.execute("INSERT INTO ledger_lines(id,journal_id,account_id,debit_halalas,credit_halalas) VALUES('l1','j1','a1',100,0)")
    db.execute("INSERT INTO ledger_lines(id,journal_id,account_id,debit_halalas,credit_halalas) VALUES('l2','j1','a2',0,100)")
    db.execute("UPDATE ledger_journals SET posted=1 WHERE id='j1'")
    for statement in [
        "UPDATE ledger_journals SET memo='tampered' WHERE id='j1'",
        "DELETE FROM ledger_lines WHERE id='l1'",
    ]:
        try:
            db.execute(statement)
            raise AssertionError("Posted journal data was mutable")
        except sqlite3.IntegrityError as exc:
            assert "IMMUTABLE_LEDGER" in str(exc), str(exc)
    db.execute("INSERT INTO ledger_journals(id,reference,memo,total_debit_halalas,total_credit_halalas,created_by) VALUES('j2','r2','open test',100,100,'u1')")
    db.execute("INSERT INTO ledger_lines(id,journal_id,account_id,debit_halalas,credit_halalas) VALUES('l3','j2','a1',100,0)")
    try:
        db.execute("UPDATE ledger_lines SET journal_id='j1' WHERE id='l3'")
        raise AssertionError("A line was moved into a posted journal")
    except sqlite3.IntegrityError as exc:
        assert "IMMUTABLE_LEDGER" in str(exc), str(exc)
    assert db.execute("PRAGMA foreign_key_check").fetchall() == []
    assert db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
    db.close()
    print("Runtime ledger DDL passed: extracted from src/server.js; balance gate and posted-journal immutability enforced.")


if __name__ == "__main__":
    main()
