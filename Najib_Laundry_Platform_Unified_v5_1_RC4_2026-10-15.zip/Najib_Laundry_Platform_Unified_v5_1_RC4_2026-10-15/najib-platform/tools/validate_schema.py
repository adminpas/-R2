#!/usr/bin/env python3
"""Standard-library smoke test for the documented SQLite schema."""
from __future__ import annotations
import json
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCHEMA = ROOT / "database" / "schema.sqlite.sql"


def main() -> None:
    sql = SCHEMA.read_text(encoding="utf-8")
    db = sqlite3.connect(":memory:")
    db.execute("PRAGMA foreign_keys=ON")
    db.executescript(sql)
    expected = {"users", "auth_sessions", "categories", "products", "reservations", "audit_logs", "settings", "ledger_accounts", "ledger_journals", "ledger_lines"}
    actual = {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    assert expected <= actual, f"Missing tables: {sorted(expected - actual)}"
    assert db.execute("PRAGMA foreign_key_check").fetchall() == [], "Foreign key check failed"
    assert db.execute("PRAGMA integrity_check").fetchone()[0] == "ok", "SQLite integrity check failed"

    db.execute("INSERT INTO users(id,username,password_hash,role) VALUES('u1','owner','hash','owner')")
    db.execute("INSERT INTO categories(id,name) VALUES('c1','غسالات كمبيوتر')")
    db.execute("INSERT INTO products(id,name,category,price_halalas,stock_quantity) VALUES('p1','غسالة اختبار','غسالات كمبيوتر',1950000,1)")
    services = [{"id": "transport", "name": "النقل", "pricingMode": "quote", "priceSAR": None}]
    db.execute(
        "INSERT INTO reservations(id,product_id,customer_name,mobile,email,business_name,site_address,services_json,expires_at) "
        "VALUES('r1','p1','عميل اختبار','0512345678','customer@example.test','مغسلة اختبار','جدة - اختبار',?,'2099-01-01T00:00:00.000Z')",
        (json.dumps(services, ensure_ascii=False),),
    )
    assert db.execute("SELECT price_halalas FROM products WHERE id='p1'").fetchone()[0] == 1950000
    restored = json.loads(db.execute("SELECT services_json FROM reservations WHERE id='r1'").fetchone()[0])
    assert restored[0]["pricingMode"] == "quote" and restored[0]["priceSAR"] is None
    # Ledger schema checks: duplicate references are blocked, unbalanced totals and invalid line shapes are rejected,
    # and posted entries are immutable even if someone attempts direct SQL mutation.
    db.execute("INSERT INTO ledger_accounts(id,code,name,account_type) VALUES('a1','1000','Cash','asset')")
    db.execute("INSERT INTO ledger_accounts(id,code,name,account_type) VALUES('a2','4000','Sales','revenue')")
    db.execute("INSERT INTO ledger_journals(id,reference,memo,total_debit_halalas,total_credit_halalas,created_by) VALUES('j1','ref-1','test balanced entry',100,100,'u1')")
    db.execute("INSERT INTO ledger_lines(id,journal_id,account_id,debit_halalas,credit_halalas) VALUES('l1','j1','a1',100,0)")
    db.execute("INSERT INTO ledger_lines(id,journal_id,account_id,debit_halalas,credit_halalas) VALUES('l2','j1','a2',0,100)")
    db.execute("UPDATE ledger_journals SET posted=1 WHERE id='j1'")
    try:
        db.execute("UPDATE ledger_journals SET memo='tampered' WHERE id='j1'")
        raise AssertionError("posted ledger journal must be immutable")
    except sqlite3.IntegrityError as exc:
        assert "IMMUTABLE_LEDGER" in str(exc)
    try:
        db.execute("INSERT INTO ledger_lines(id,journal_id,account_id,debit_halalas,credit_halalas) VALUES('bad','j1','a1',100,100)")
        raise AssertionError("ledger line cannot be both debit and credit")
    except sqlite3.IntegrityError:
        pass
    db.execute("INSERT INTO ledger_journals(id,reference,memo,total_debit_halalas,total_credit_halalas,created_by) VALUES('j2','ref-2','open journal',100,100,'u1')")
    db.execute("INSERT INTO ledger_lines(id,journal_id,account_id,debit_halalas,credit_halalas) VALUES('l3','j2','a1',100,0)")
    try:
        db.execute("UPDATE ledger_lines SET journal_id='j1' WHERE id='l3'")
        raise AssertionError("ledger line cannot be moved into a posted journal")
    except sqlite3.IntegrityError as exc:
        assert "IMMUTABLE_LEDGER" in str(exc)
    assert db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
    db.close()
    print("SQLite schema smoke test passed: 10 tables; FK/integrity checks; SAR halalas; service quote snapshot; database-enforced balanced and immutable-ledger constraints.")


if __name__ == "__main__":
    main()
