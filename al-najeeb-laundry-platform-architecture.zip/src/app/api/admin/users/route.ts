import { desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { deviceBindings, laundryEquipment, systemUsers } from "@/db/schema";
import { fail, handler, ok, readJson } from "@/lib/api";
import { audit, requireMfa } from "@/lib/auth";
import { clampCommission } from "@/lib/finance";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  return handler(async () => {
    await requireMfa(["SUPER_ADMIN", "ASSISTANT_ADMIN"]);
    const rows = await db
      .select({
        user: systemUsers,
        device: deviceBindings,
        itemCount: sql<number>`(
          select count(*)::int from ${laundryEquipment}
          where ${laundryEquipment.merchantId} = ${systemUsers.userId}
        )`,
      })
      .from(systemUsers)
      .leftJoin(deviceBindings, eq(deviceBindings.userId, systemUsers.userId))
      .orderBy(desc(systemUsers.createdAt));
    return ok(rows);
  });
}

export async function PATCH(request: Request) {
  return handler(async () => {
    const admin = await requireMfa(["SUPER_ADMIN", "ASSISTANT_ADMIN"]);
    const body = await readJson(request);
    const targetUserId = Number(body.userId);
    const action = String(body.action ?? "");

    if (!Number.isFinite(targetUserId)) {
      return fail("BAD_TARGET", "معرّف مستخدم غير صالح", "Invalid user id", 422);
    }

    switch (action) {
      case "ACTIVATE": {
        await db
          .update(systemUsers)
          .set({ isActive: true })
          .where(eq(systemUsers.userId, targetUserId));
        break;
      }
      case "DEACTIVATE": {
        await db
          .update(systemUsers)
          .set({ isActive: false })
          .where(eq(systemUsers.userId, targetUserId));
        break;
      }
      case "SET_COMMISSION": {
        const value = clampCommission(Number(body.commissionPercentage));
        await db
          .update(systemUsers)
          .set({ commissionPercentage: value.toFixed(2) })
          .where(eq(systemUsers.userId, targetUserId));
        break;
      }
      case "RELEASE_DEVICE": {
        await db
          .update(deviceBindings)
          .set({ revokedAt: new Date(), approved: false })
          .where(eq(deviceBindings.userId, targetUserId));
        await db
          .update(systemUsers)
          .set({ hardwareDeviceId: null })
          .where(eq(systemUsers.userId, targetUserId));
        break;
      }
      default:
        return fail(
          "UNKNOWN_ACTION",
          "إجراء غير معروف",
          "Unknown admin action",
          422,
        );
    }

    await audit({
      actorUserId: admin.user.userId,
      eventType: `ADMIN_${action}`,
      detail: { targetUserId },
    });
    return ok({ action, targetUserId, by: admin.user.userId });
  });
}
