import { fail, handler, num, ok, readJson } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { auctionDetail, auctionLedger, placeBid, processMaturedAuctions } from "@/lib/auctions";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_request: Request, ctx: Ctx) {
  return handler(async () => {
    const { id } = await ctx.params;
    const detail = await auctionDetail(Number(id));
    await processMaturedAuctions(0);
    return ok({ ...detail, ledger: await auctionLedger() });
  });
}

/** POST — place a bid (min raise 500 SAR) or fetch a live quote. */
export async function POST(request: Request, ctx: Ctx) {
  return handler(async () => {
    const viewer = await requireUser();
    const { id } = await ctx.params;
    const body = await readJson(request);
    const result = await placeBid({
      auctionId: Number(id),
      bidderId: viewer.user.userId,
      amount: num(body.amount),
    });
    return ok(result);
  });
}

export async function PATCH(request: Request, ctx: Ctx) {
  return handler(async () => {
    await requireUser(["SUPER_ADMIN", "ASSISTANT_ADMIN"]);
    const { id } = await ctx.params;
    await readJson(request);
    const processed = await processMaturedAuctions(0);
    return ok({ auctionId: Number(id), processed });
  });
}

export function DELETE(_request: Request, ctx: Ctx) {
  return fail("NOT_SUPPORTED", "لا يمكن حذف مزاد", "Auction deletion is not supported", 405);
}
