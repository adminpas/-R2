import { fail, handler, num, ok, readJson, str } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { LIMITS } from "@/lib/config";
import { createAuction, listAuctions, processMaturedAuctions } from "@/lib/auctions";
import { ensureSeeded } from "@/lib/seed";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  return handler(async () => {
    await ensureSeeded();
    // Lazy deadline tick: any read auto-processes matured auctions.
    const processed = await processMaturedAuctions(0);
    const url = new URL(request.url);
    const rows = await listAuctions(url.searchParams.get("open") === "1");
    return ok({ auctions: rows, autoProcessed: processed });
  });
}

/** POST — build a cost-price, zero-profit project package (30-day timer). */
export async function POST(request: Request) {
  return handler(async () => {
    const ctx = await requireUser(["SUPER_ADMIN", "ASSISTANT_ADMIN", "MERCHANT"]);
    const body = await readJson(request);
    const title = str(body.packageTitle);
    const base = num(body.baseCostPrice);
    if (!title) return fail("TITLE_REQUIRED", "عنوان الباقة مطلوب", "Package title required", 422);
    if (base <= 0) return fail("BAD_PRICE", "سعر التكلفة غير صالح", "Invalid cost price", 422);
    const auction = await createAuction({
      packageTitle: title,
      baseCostPrice: base,
      durationDays: num(body.durationDays, LIMITS.AUCTION_DURATION_DAYS),
      minimumIncrement: num(body.minimumIncrement, LIMITS.AUCTION_MIN_INCREMENT_SAR),
      items: Array.isArray(body.items) ? body.items.map(String) : [],
      createdByUserId: ctx.user.userId,
    });
    return ok(auction);
  });
}
