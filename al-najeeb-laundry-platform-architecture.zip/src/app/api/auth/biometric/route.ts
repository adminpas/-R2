import { eq, isNull, and } from "drizzle-orm";
import { db } from "@/db";
import { authSessions } from "@/db/schema";
import { fail, handler, ok, readJson, str } from "@/lib/api";
import { audit, requireUser } from "@/lib/auth";
import { signBiometricToken, verifyBiometricToken } from "@/lib/crypto";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * GET — biometric handshake challenge.
 * On the Jeddah node the terminal forwards this to the OS-level FaceID/TouchID
 * authenticator; the authenticator returns the attestation below.
 */
export async function GET() {
  return handler(async () => {
    const ctx = await requireUser();
    if (!ctx.hardwareDeviceId) {
      return fail(
        "DEVICE_REQUIRED",
        "يجب تهيئة الجهاز قبل توثيق البصمة",
        "Device initialization is required before the biometric handshake",
        409,
      );
    }
    const challenge = signBiometricToken(
      ctx.user.userId,
      ctx.hardwareDeviceId,
    );
    return ok({
      challenge,
      algorithm: "HMAC-SHA512",
      deviceBound: true,
      verified: ctx.biometricVerified,
    });
  });
}

/** POST — verify the attestation and elevate the session to MFA-cleared. */
export async function POST(request: Request) {
  return handler(async () => {
    const ctx = await requireUser();
    const body = await readJson(request);
    const attestation = str(body.attestation);
    if (!ctx.hardwareDeviceId) {
      return fail(
        "DEVICE_REQUIRED",
        "لا يوجد قفل جهاز مرتبط بهذه الجلسة",
        "No device lock bound to this session",
        409,
      );
    }
    const valid = verifyBiometricToken(
      ctx.user.userId,
      ctx.hardwareDeviceId,
      attestation,
    );
    if (!valid) {
      await audit({
        actorUserId: ctx.user.userId,
        eventType: "BIOMETRIC_REJECTED",
        severity: "WARN",
      });
      return fail(
        "BIOMETRIC_INVALID",
        "فشل توثيق البصمة — أعد المحاولة",
        "Biometric handshake failed, please retry",
        401,
      );
    }
    const token = str(body.sessionToken);
    await db
      .update(authSessions)
      .set({ biometricVerified: true })
      .where(
        token
          ? and(
              eq(authSessions.tokenHash, token),
              isNull(authSessions.revokedAt),
            )
          : eq(authSessions.userId, ctx.user.userId),
      );
    await audit({
      actorUserId: ctx.user.userId,
      eventType: "BIOMETRIC_VERIFIED",
      detail: { device: ctx.hardwareDeviceId },
    });
    return ok({ biometricVerified: true, mfa: "FaceID/TouchID" });
  });
}
