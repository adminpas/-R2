import { and, eq, isNull } from "drizzle-orm";
import { db } from "@/db";
import { authSessions, deviceBindings, systemUsers } from "@/db/schema";
import { handler, ok, readJson, str } from "@/lib/api";
import {
  bindHardwareDevice,
  getSessionContext,
  requireUser,
} from "@/lib/auth";
import { hardwareFingerprint } from "@/lib/crypto";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** GET: current 1-device lock state of the caller. */
export async function GET() {
  return handler(async () => {
    const ctx = await requireUser();
    const [binding] = await db
      .select()
      .from(deviceBindings)
      .where(eq(deviceBindings.userId, ctx.user.userId))
      .limit(1);
    return ok({
      lockedToDevice: ctx.user.hardwareDeviceId,
      sessionDevice: ctx.hardwareDeviceId,
      binding: binding ?? null,
      note: {
        ar: "لوحتك مقفلة على أول جهاز تمت تهيئته فعلياً — مشاركة الحساب محجوبة.",
        en: "Your panel is locked to the first physically initialized device — sharing is blocked.",
      },
    });
  });
}

/**
 * POST: physical initialization handshake.
 * The terminal posts its raw hardware attestation; the engine locks the account
 * to that digest forever (or rejects a foreign device).
 */
export async function POST(request: Request) {
  return handler(async () => {
    const body = await readJson(request);
    const hwProbe = str(body.hwProbe);
    if (!hwProbe) {
      return ok({
        fingerprint: null,
        locked: false,
        message: { ar: "لم تُرسل بصمة الجهاز", en: "No hardware probe supplied" },
      });
    }
    const ctx = await getSessionContext();
    if (!ctx) {
      return ok({
        fingerprint: hardwareFingerprint(hwProbe),
        locked: false,
        authenticated: false,
      });
    }
    const result = await bindHardwareDevice({
      user: ctx.user,
      rawFingerprint: hwProbe,
      deviceLabel: str(body.deviceLabel) || "Al-Najeeb Terminal",
      allowBind: true,
    });
    return ok({
      authenticated: true,
      ...result,
      fingerprint: result.hardwareDeviceId,
    });
  });
}

/** DELETE: Super-Admin releases a device lock (re-binding allowed). */
export async function DELETE(request: Request) {
  return handler(async () => {
    const admin = await requireUser(["SUPER_ADMIN"]);
    const body = await readJson(request);
    const targetUserId = Number(body.userId);
    await db
      .update(deviceBindings)
      .set({ revokedAt: new Date(), approved: false })
      .where(and(eq(deviceBindings.userId, targetUserId), isNull(deviceBindings.revokedAt)));
    await db
      .update(systemUsers)
      .set({ hardwareDeviceId: null })
      .where(eq(systemUsers.userId, targetUserId));
    await db
      .update(authSessions)
      .set({ revokedAt: new Date() })
      .where(and(eq(authSessions.userId, targetUserId), isNull(authSessions.revokedAt)));
    return ok({ released: true, by: admin.user.userId, targetUserId });
  });
}
