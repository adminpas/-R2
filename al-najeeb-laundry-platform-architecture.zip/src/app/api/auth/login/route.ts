import { fail, handler, ok, readJson, str } from "@/lib/api";
import {
  authenticate,
  audit,
  bindHardwareDevice,
  issueSession,
} from "@/lib/auth";
import { verifyBiometricToken } from "@/lib/crypto";
import { ensureSeeded } from "@/lib/seed";

export const runtime = "nodejs";

export async function POST(request: Request) {
  return handler(async () => {
    await ensureSeeded();
    const body = await readJson(request);
    const username = str(body.username).toLowerCase();
    const password = str(body.password);
    const hwProbe = str(body.hwProbe);

    if (!username || !password) {
      return fail(
        "MISSING_CREDENTIALS",
        "أدخل اسم المستخدم وكلمة المرور",
        "Username and password are required",
        422,
      );
    }

    const user = await authenticate(username, password);

    if (!user.isActive) {
      await audit({
        actorUserId: user.userId,
        eventType: "LOGIN_BLOCKED_PENDING_APPROVAL",
        severity: "WARN",
      });
      return fail(
        "PENDING_APPROVAL",
        "الحساب بانتظار موافقة الإدارة العليا",
        "Account is pending Super-Admin approval",
        403,
      );
    }

    // 1-Device hardware binding handshake.
    const lock = await bindHardwareDevice({
      user,
      rawFingerprint: hwProbe || `${username}-fallback-probe`,
      deviceLabel: str(body.deviceLabel) || "Al-Najeeb Terminal",
      userAgent: request.headers.get("user-agent") ?? undefined,
      allowBind: hwProbe.length > 0,
    });

    if (lock.violation) {
      return fail(
        "DEVICE_LOCK_VIOLATION",
        "هذا الحساب مقفل على جهاز آخر — يُمنع مشاركة الحساب",
        "This account is locked to another device — sharing is blocked",
        423,
      );
    }

    // Optional FaceID / TouchID multi-factor handshake during login.
    let biometricVerified = false;
    const blob = str(body.biometricBlob);
    if (blob && lock.hardwareDeviceId) {
      biometricVerified = verifyBiometricToken(
        user.userId,
        lock.hardwareDeviceId,
        blob,
      );
    }

    await issueSession({
      user: { ...user, hardwareDeviceId: lock.hardwareDeviceId },
      hardwareDeviceId: lock.hardwareDeviceId,
      biometricVerified,
    });
    await audit({
      actorUserId: user.userId,
      eventType: "LOGIN_SUCCESS",
      detail: { device: lock.hardwareDeviceId, biometricVerified },
    });

    return ok({
      userId: user.userId,
      username: user.username,
      roleType: user.roleType,
      displayNameAr: user.displayNameAr,
      deviceLock: lock,
      biometricVerified,
    });
  });
}
