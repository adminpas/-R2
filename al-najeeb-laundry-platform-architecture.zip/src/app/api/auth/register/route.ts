import { handler, fail, ok, readJson, str } from "@/lib/api";
import { registerAccount, issueSession, bindHardwareDevice } from "@/lib/auth";
import { ensureSeeded } from "@/lib/seed";
import type { RoleType } from "@/db/schema";

export const runtime = "nodejs";

const ALLOWED: RoleType[] = [
  "MERCHANT",
  "MAINTENANCE_TECH",
  "SHIPPING_COMPANY",
  "ASSISTANT_ADMIN",
];

export async function POST(request: Request) {
  return handler(async () => {
    await ensureSeeded();
    const body = await readJson(request);
    const username = str(body.username).toLowerCase();
    const password = str(body.password);
    const roleType = str(body.roleType) as RoleType;

    if (username.length < 4) {
      return fail(
        "WEAK_USERNAME",
        "اسم المستخدم يجب أن يكون 4 أحرف على الأقل",
        "Username must be at least 4 characters",
        422,
      );
    }
    if (password.length < 8) {
      return fail(
        "WEAK_PASSWORD",
        "كلمة المرور يجب أن تكون 8 أحرف على الأقل",
        "Password must be at least 8 characters",
        422,
      );
    }
    if (!ALLOWED.includes(roleType)) {
      return fail(
        "ROLE_NOT_ALLOWED",
        "نوع الحساب غير مسموح بالتسجيل الذاتي",
        "Self-registration is not allowed for this role",
        403,
      );
    }

    const user = await registerAccount({
      username,
      password,
      roleType,
      displayNameAr: str(body.displayNameAr) || username,
      displayNameEn: str(body.displayNameEn) || username,
      phone: str(body.phone) || undefined,
      city: str(body.city) || undefined,
    });

    // Bind the very first physical device that initializes the account.
    const probe = str(body.hwProbe);
    let lock = { hardwareDeviceId: "", locked: false, violation: false };
    if (probe) {
      lock = await bindHardwareDevice({
        user,
        rawFingerprint: probe,
        deviceLabel: str(body.deviceLabel) || "Al-Najeeb Terminal",
        allowBind: true,
      });
    }

    if (lock.hardwareDeviceId) {
      await issueSession({
        user: { ...user, hardwareDeviceId: lock.hardwareDeviceId },
        hardwareDeviceId: lock.hardwareDeviceId,
        biometricVerified: false,
      });
    }

    return ok({
      userId: user.userId,
      username: user.username,
      roleType: user.roleType,
      isActive: user.isActive,
      deviceLock: lock,
      pendingApproval: !user.isActive,
    });
  });
}
