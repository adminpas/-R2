import { handler, ok } from "@/lib/api";
import { destroySession, getSessionContext } from "@/lib/auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  return handler(async () => {
    const ctx = await getSessionContext();
    if (!ctx) return ok({ authenticated: false });
    return ok({
      authenticated: true,
      userId: ctx.user.userId,
      username: ctx.user.username,
      roleType: ctx.user.roleType,
      displayNameAr: ctx.user.displayNameAr,
      displayNameEn: ctx.user.displayNameEn,
      city: ctx.user.city,
      hardwareDeviceId: ctx.hardwareDeviceId,
      biometricVerified: ctx.biometricVerified,
      merchantSsdFolder: ctx.user.merchantSsdFolder,
    });
  });
}

export async function DELETE() {
  return handler(async () => {
    await destroySession();
    return ok({ signedOut: true });
  });
}
