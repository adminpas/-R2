import { asc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { categories, laundryEquipment } from "@/db/schema";
import { fail, handler, ok, readJson, str } from "@/lib/api";
import { requireMfa } from "@/lib/auth";
import { SSD_LOGICAL_ROOT, TENANT_ROOTS } from "@/lib/config";
import { ensureSeeded } from "@/lib/seed";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  return handler(async () => {
    await ensureSeeded();
    const rows = await db
      .select({
        category: categories,
        itemCount: sql<number>`(
          select count(*)::int from ${laundryEquipment}
          where ${laundryEquipment.categoryId} = ${categories.categoryId}
        )`,
      })
      .from(categories)
      .orderBy(asc(categories.sortOrder), asc(categories.categoryId));
    return ok(rows);
  });
}

export async function POST(request: Request) {
  return handler(async () => {
    await requireMfa(["SUPER_ADMIN", "ASSISTANT_ADMIN"]);
    const body = await readJson(request);
    const nameAr = str(body.categoryNameAr);
    if (!nameAr) {
      return fail("NAME_REQUIRED", "الاسم العربي مطلوب", "Arabic name required", 422);
    }
    const slug =
      str(body.slug) ||
      nameAr.replace(/[^\p{L}\p{N}]+/gu, "_").slice(0, 40) ||
      `CAT_${Date.now()}`;
    const parentCategoryId = Number(body.parentCategoryId) || null;
    const [row] = await db
      .insert(categories)
      .values({
        categoryNameAr: nameAr,
        categoryNameEn: str(body.categoryNameEn) || null,
        parentCategoryId,
        ssdFolderPath: `${SSD_LOGICAL_ROOT}/${TENANT_ROOTS.CATALOG}/${slug}`,
        iconGlyph: str(body.iconGlyph) || "📦",
        sortOrder: Number(body.sortOrder) || 99,
      })
      .returning();
    void eq;
    return ok(row);
  });
}
