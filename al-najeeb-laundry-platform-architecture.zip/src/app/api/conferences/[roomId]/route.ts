import { and, asc, eq, gt, isNull } from "drizzle-orm";
import { db } from "@/db";
import {
  conferenceParticipants,
  conferenceRooms,
  systemUsers,
  webrtcSignals,
} from "@/db/schema";
import { fail, handler, ok, readJson, str } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { newPeerId } from "@/lib/crypto";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ roomId: string }> };

/** Polling endpoint: room roster + signals newer than `since`. */
export async function GET(request: Request, ctx: Ctx) {
  return handler(async () => {
    const viewer = await requireUser();
    const { roomId } = await ctx.params;
    const url = new URL(request.url);
    const since = Number(url.searchParams.get("since")) || 0;

    const [room] = await db
      .select()
      .from(conferenceRooms)
      .where(eq(conferenceRooms.roomId, roomId))
      .limit(1);
    if (!room) return fail("ROOM_NOT_FOUND", "الغرفة غير موجودة", "Room not found", 404);

    const roster = await db
      .select({
        participant: conferenceParticipants,
        nameAr: systemUsers.displayNameAr,
        roleType: systemUsers.roleType,
      })
      .from(conferenceParticipants)
      .leftJoin(systemUsers, eq(systemUsers.userId, conferenceParticipants.userId))
      .where(
        and(
          eq(conferenceParticipants.roomId, roomId),
          isNull(conferenceParticipants.leftAt),
        ),
      );

    const signals = await db
      .select()
      .from(webrtcSignals)
      .where(
        and(
          eq(webrtcSignals.roomId, roomId),
          gt(webrtcSignals.signalId, since),
        ),
      )
      .orderBy(asc(webrtcSignals.signalId))
      .limit(120);

    return ok({
      room,
      roster,
      signals,
      viewerId: viewer.user.userId,
      cursor: signals.at(-1)?.signalId ?? since,
    });
  });
}

/** POST — join the room, publish presence, or relay an SDP/ICE signal. */
export async function POST(request: Request, ctx: Ctx) {
  return handler(async () => {
    const viewer = await requireUser();
    const { roomId } = await ctx.params;
    const body = await readJson(request);
    const kind = str(body.kind).toUpperCase();

    const [room] = await db
      .select()
      .from(conferenceRooms)
      .where(eq(conferenceRooms.roomId, roomId))
      .limit(1);
    if (!room) return fail("ROOM_NOT_FOUND", "الغرفة غير موجودة", "Room not found", 404);

    if (kind === "JOIN" || kind === "") {
      const peerId = str(body.peerId) || newPeerId();
      const [existing] = await db
        .select()
        .from(conferenceParticipants)
        .where(
          and(
            eq(conferenceParticipants.roomId, roomId),
            eq(conferenceParticipants.userId, viewer.user.userId),
            isNull(conferenceParticipants.leftAt),
          ),
        )
        .limit(1);
      if (existing) {
        const [updated] = await db
          .update(conferenceParticipants)
          .set({ peerId, leftAt: null })
          .where(eq(conferenceParticipants.participantId, existing.participantId))
          .returning();
        return ok({ participant: updated, peerId });
      }
      const [participant] = await db
        .insert(conferenceParticipants)
        .values({ roomId, userId: viewer.user.userId, peerId })
        .returning();
      return ok({ participant, peerId });
    }

    if (kind === "LEAVE") {
      await db
        .update(conferenceParticipants)
        .set({ leftAt: new Date() })
        .where(
          and(
            eq(conferenceParticipants.roomId, roomId),
            eq(conferenceParticipants.userId, viewer.user.userId),
          ),
        );
      return ok({ left: true });
    }

    const [signal] = await db
      .insert(webrtcSignals)
      .values({
        roomId,
        senderUserId: viewer.user.userId,
        targetUserId: Number(body.targetUserId) || null,
        signalType: kind,
        payload: (body.payload ?? {}) as Record<string, unknown>,
      })
      .returning();
    return ok({ signal });
  });
}

export async function DELETE(_request: Request, ctx: Ctx) {
  return handler(async () => {
    const viewer = await requireUser();
    const { roomId } = await ctx.params;
    await db
      .update(conferenceRooms)
      .set({ isActive: false })
      .where(and(eq(conferenceRooms.roomId, roomId), eq(conferenceRooms.hostUserId, viewer.user.userId)));
    return ok({ closed: true });
  });
}

export const revalidate = 0;
export const fetchCache = "force-no-store";
