import { desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { conferenceParticipants, conferenceRooms, systemUsers } from "@/db/schema";
import { handler, ok, readJson, str } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { newPeerId } from "@/lib/crypto";
import { openConferenceRoom } from "@/lib/support";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  return handler(async () => {
    await requireUser();
    const rooms = await db
      .select({
        room: conferenceRooms,
        hostNameAr: systemUsers.displayNameAr,
        participantCount: sql<number>`(
          select count(*)::int from ${conferenceParticipants}
          where ${conferenceParticipants.roomId} = ${conferenceRooms.roomId}
            and ${conferenceParticipants.leftAt} is null
        )`,
      })
      .from(conferenceRooms)
      .leftJoin(systemUsers, eq(systemUsers.userId, conferenceRooms.hostUserId))
      .orderBy(desc(conferenceRooms.createdAt))
      .limit(40);
    return ok(rooms);
  });
}

/** POST — open an in-app WebRTC conference room (tech / merchant / client). */
export async function POST(request: Request) {
  return handler(async () => {
    const viewer = await requireUser();
    const body = await readJson(request);
    const purpose = (str(body.purpose) || "AI_VISION_SUPPORT") as
      | "AI_VISION_SUPPORT"
      | "INTERNAL"
      | "MERCHANT"
      | "CLIENT";
    const room = await openConferenceRoom({
      hostUserId: viewer.user.userId,
      title: str(body.title) || `غرفة ${viewer.user.displayNameAr ?? viewer.user.username}`,
      purpose,
      ticketId: Number(body.ticketId) || null,
    });
    await db.insert(conferenceParticipants).values({
      roomId: room.roomId,
      userId: viewer.user.userId,
      peerId: newPeerId(),
    });
    return ok({ room, joinUrl: `/support?room=${room.roomId}` });
  });
}
