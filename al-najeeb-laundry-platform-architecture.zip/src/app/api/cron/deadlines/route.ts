import { handler, ok } from "@/lib/api";
import { processMaturedAuctions } from "@/lib/auctions";
import { expireStaleHolds } from "@/lib/reservations";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Deadline worker (GET so the Jeddah node cron can hit it without a body):
 *  - closes + auto-processes every matured 30-day auction into escrow
 *  - expires 24h showroom holds and refunds their downpayment escrow
 */
export async function GET() {
  return handler(async () => {
    const processedAuctions = await processMaturedAuctions(0);
    const expiredHolds = await expireStaleHolds();
    return ok({
      ranAt: new Date().toISOString(),
      processedAuctions,
      expiredHolds,
    });
  });
}

export async function POST() {
  return GET();
}
