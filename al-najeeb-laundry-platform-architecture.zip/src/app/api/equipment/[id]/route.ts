import { and, avg, count, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  categories,
  equipmentMedia,
  feedbackRatings,
  laundryEquipment,
  systemUsers,
} from "@/db/schema";
import { fail, handler, ok, readJson, str } from "@/lib/api";
import { requireMerchantScope } from "@/lib/auth";
import { computeSplit } from "@/lib/finance";
import { FEEDBACK_BANK } from "@/lib/i18n";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_request: Request, ctx: Ctx) {
  return handler(async () => {
    const { id } = await ctx.params;
    const equipmentId = Number(id);
    const [row] = await db
      .select({
        equipment: laundryEquipment,
        category: categories,
        merchant: {
          userId: systemUsers.userId,
          displayNameAr: systemUsers.displayNameAr,
          displayNameEn: systemUsers.displayNameEn,
          city: systemUsers.city,
          phone: systemUsers.phone,
        },
      })
      .from(laundryEquipment)
      .leftJoin(categories, eq(categories.categoryId, laundryEquipment.categoryId))
      .leftJoin(systemUsers, eq(systemUsers.userId, laundryEquipment.merchantId))
      .where(eq(laundryEquipment.equipmentId, equipmentId))
      .limit(1);

    if (!row) {
      return fail("NOT_FOUND", "العنصر غير موجود", "Item not found", 404);
    }

    const media = await db
      .select()
      .from(equipmentMedia)
      .where(eq(equipmentMedia.equipmentId, equipmentId))
      .orderBy(desc(equipmentMedia.mediaId));

    const [rating] = await db
      .select({ avgScore: avg(feedbackRatings.score), total: count() })
      .from(feedbackRatings)
      .where(
        and(
          eq(feedbackRatings.targetType, "EQUIPMENT"),
          eq(feedbackRatings.targetId, equipmentId),
        ),
      );

    const split = computeSplit(
      Number(row.equipment.price),
      Number(row.equipment.commissionPercentage),
    );

    return ok({
      ...row,
      media,
      rating: {
        average: rating?.avgScore ? Number(rating.avgScore) : 0,
        total: rating?.total ?? 0,
      },
      finance: split,
      quickFeedback: FEEDBACK_BANK,
    });
  });
}

export async function PATCH(request: Request, ctx: Ctx) {
  return handler(async () => {
    const { id } = await ctx.params;
    const equipmentId = Number(id);
    const [existing] = await db
      .select()
      .from(laundryEquipment)
      .where(eq(laundryEquipment.equipmentId, equipmentId))
      .limit(1);
    if (!existing) {
      return fail("NOT_FOUND", "العنصر غير موجود", "Item not found", 404);
    }
    await requireMerchantScope(existing.merchantId);

    const body = await readJson(request);
    const patch: Partial<typeof laundryEquipment.$inferInsert> = {};
    if (str(body.titleAr)) patch.titleAr = str(body.titleAr);
    if (str(body.titleEn)) patch.titleEn = str(body.titleEn);
    if (Number(body.price) > 0) patch.price = Number(body.price).toFixed(2);
    if (body.commissionPercentage !== undefined) {
      patch.commissionPercentage = computeSplit(
        Number(existing.price),
        Number(body.commissionPercentage),
      ).commissionPercentage.toFixed(2);
    }
    if (str(body.availabilityStatus)) {
      patch.availabilityStatus = str(body.availabilityStatus) as
        | "AVAILABLE"
        | "HOLD_24H"
        | "SOLD";
    }
    if (body.specsJson && typeof body.specsJson === "object") {
      patch.specsJson = body.specsJson as Record<string, string>;
    }
    if (body.isLiveShowroom !== undefined) {
      patch.isLiveShowroom = Boolean(body.isLiveShowroom);
    }
    if (Object.keys(patch).length === 0) {
      return fail("NOTHING_TO_UPDATE", "لا يوجد تغيير", "Nothing to update", 422);
    }
    const [updated] = await db
      .update(laundryEquipment)
      .set(patch)
      .where(
        and(
          eq(laundryEquipment.equipmentId, equipmentId),
          sql`true`,
        ),
      )
      .returning();
    return ok(updated);
  });
}
