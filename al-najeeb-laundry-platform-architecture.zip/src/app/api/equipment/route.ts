import { and, desc, eq, ilike, or, sql, type SQL } from "drizzle-orm";
import { db } from "@/db";
import { categories, laundryEquipment, systemUsers } from "@/db/schema";
import { fail, handler, money, ok, readJson, str } from "@/lib/api";
import { getSessionContext, requireUser } from "@/lib/auth";
import { clampCommission } from "@/lib/finance";
import { merchantRoot } from "@/lib/storage";
import { ensureSeeded } from "@/lib/seed";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  return handler(async () => {
    await ensureSeeded();
    const url = new URL(request.url);
    const q = str(url.searchParams.get("q"));
    const categoryId = Number(url.searchParams.get("categoryId")) || 0;
    const status = str(url.searchParams.get("status"));
    const availability = str(url.searchParams.get("availability"));
    const merchantId = Number(url.searchParams.get("merchantId")) || 0;
    const liveOnly = url.searchParams.get("live") === "1";
    const limit = Math.min(Number(url.searchParams.get("limit")) || 48, 120);

    const filters: SQL[] = [];
    if (q) {
      const like = `%${q}%`;
      const cond = or(
        ilike(laundryEquipment.titleAr, like),
        ilike(laundryEquipment.titleEn, like),
        ilike(laundryEquipment.descriptionAr, like),
      );
      if (cond) filters.push(cond);
    }
    if (categoryId) filters.push(eq(laundryEquipment.categoryId, categoryId));
    if (status) {
      filters.push(
        sql`${laundryEquipment.equipmentStatus}::text = ${status}`,
      );
    }
    if (availability) {
      filters.push(
        sql`${laundryEquipment.availabilityStatus}::text = ${availability}`,
      );
    }
    if (merchantId) filters.push(eq(laundryEquipment.merchantId, merchantId));
    if (liveOnly) filters.push(eq(laundryEquipment.isLiveShowroom, true));

    const rows = await db
      .select({
        equipment: laundryEquipment,
        categoryNameAr: categories.categoryNameAr,
        categoryNameEn: categories.categoryNameEn,
        merchantNameAr: systemUsers.displayNameAr,
      })
      .from(laundryEquipment)
      .leftJoin(categories, eq(categories.categoryId, laundryEquipment.categoryId))
      .leftJoin(systemUsers, eq(systemUsers.userId, laundryEquipment.merchantId))
      .where(filters.length > 0 ? and(...filters) : sql`true`)
      .orderBy(desc(laundryEquipment.createdAt))
      .limit(limit);

    return ok(rows);
  });
}

export async function POST(request: Request) {
  return handler(async () => {
    const ctx = await requireUser(["MERCHANT", "SUPER_ADMIN", "ASSISTANT_ADMIN"]);
    const body = await readJson(request);
    const titleAr = str(body.titleAr);
    const price = Number(body.price);
    if (!titleAr) {
      return fail("TITLE_REQUIRED", "العنوان العربي مطلوب", "Arabic title required", 422);
    }
    if (!Number.isFinite(price) || price <= 0) {
      return fail("BAD_PRICE", "السعر غير صالح", "Invalid price", 422);
    }

    const tenantId =
      ctx.user.roleType === "MERCHANT" ? ctx.user.userId : Number(body.merchantId) || ctx.user.userId;
    if (ctx.user.roleType === "MERCHANT" && tenantId !== ctx.user.userId) {
      return fail("TENANT_FORBIDDEN", "لا يمكن الإضافة لمعرض تاجر آخر", "Cannot publish into another tenant", 403);
    }

    const commission = clampCommission(
      Number(body.commissionPercentage ?? ctx.user.commissionPercentage),
    );

    const [row] = await db
      .insert(laundryEquipment)
      .values({
        categoryId: Number(body.categoryId) || null,
        merchantId: tenantId,
        titleAr,
        titleEn: str(body.titleEn) || null,
        descriptionAr: str(body.descriptionAr) || null,
        descriptionEn: str(body.descriptionEn) || null,
        price: money(price),
        commissionPercentage: commission.toFixed(2),
        equipmentStatus: (str(body.equipmentStatus) || "NEW_4K") as
          | "NEW_4K"
          | "LIKE_NEW_BLUERAY"
          | "USED_EXCELLENT_HD"
          | "REFURBISHED",
        availabilityStatus: "AVAILABLE",
        specsJson:
          body.specsJson && typeof body.specsJson === "object"
            ? (body.specsJson as Record<string, string>)
            : {},
        videoTrailerPath: str(body.videoTrailerPath) || null,
        posterImagePath: str(body.posterImagePath) || null,
        isLiveShowroom: Boolean(body.isLiveShowroom),
        stockQuantity: Number(body.stockQuantity) || 1,
      })
      .returning();

    return ok({
      equipment: row,
      tenantFolder: merchantRoot(tenantId),
      downpaymentRequired: Math.round(price * 0.25 * 100) / 100,
    });
  });
}

export async function HEAD() {
  const ctx = await getSessionContext();
  return new Response(null, {
    status: 200,
    headers: { "x-najeeb-auth": ctx ? "1" : "0" },
  });
}
