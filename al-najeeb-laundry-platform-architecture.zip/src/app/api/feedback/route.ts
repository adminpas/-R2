import { and, avg, count, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { feedbackBank, feedbackRatings, systemUsers } from "@/db/schema";
import { fail, handler, num, ok, readJson, str } from "@/lib/api";
import { getSessionContext } from "@/lib/auth";
import { FEEDBACK_BANK, type Locale } from "@/lib/i18n";
import { ensureSeeded } from "@/lib/seed";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const TARGETS = ["EQUIPMENT", "MERCHANT", "SHIPPING", "MAINTENANCE", "PLATFORM"] as const;
type Target = (typeof TARGETS)[number];

export async function GET(request: Request) {
  return handler(async () => {
    await ensureSeeded();
    const url = new URL(request.url);
    const locale = (str(url.searchParams.get("locale")) || "ar") as Locale;
    const targetType = str(url.searchParams.get("targetType")).toUpperCase() as Target;
    const targetId = num(url.searchParams.get("targetId"));

    const filters = [];
    if (TARGETS.includes(targetType) && targetId) {
      filters.push(eq(feedbackRatings.targetType, targetType));
      filters.push(eq(feedbackRatings.targetId, targetId));
    }

    const ratings = await db
      .select({
        rating: feedbackRatings,
        authorNameAr: systemUsers.displayNameAr,
      })
      .from(feedbackRatings)
      .leftJoin(systemUsers, eq(systemUsers.userId, feedbackRatings.authorUserId))
      .where(filters.length > 0 ? and(...filters) : sql`true`)
      .orderBy(desc(feedbackRatings.ratingId))
      .limit(40);

    const [aggregate] = await db
      .select({ avgScore: avg(feedbackRatings.score), total: count() })
      .from(feedbackRatings)
      .where(filters.length > 0 ? and(...filters) : sql`true`);

    const bankRows = await db
      .select()
      .from(feedbackBank)
      .where(eq(feedbackBank.locale, locale))
      .orderBy(desc(feedbackBank.entryId))
      .limit(24);

    return ok({
      ratings,
      aggregate: {
        average: aggregate?.avgScore ? Number(aggregate.avgScore) : 0,
        total: aggregate?.total ?? 0,
      },
      bank: bankRows.length > 0 ? bankRows : FEEDBACK_BANK[locale] ?? FEEDBACK_BANK.ar,
      quickBank: FEEDBACK_BANK[locale] ?? FEEDBACK_BANK.ar,
    });
  });
}

/** POST — omni-rating (equipment / merchant / shipping / maintenance / platform). */
export async function POST(request: Request) {
  return handler(async () => {
    const viewer = await getSessionContext();
    const body = await readJson(request);
    const targetType = str(body.targetType).toUpperCase() as Target;
    const score = num(body.score);
    if (!TARGETS.includes(targetType)) {
      return fail("BAD_TARGET", "نوع التقييم غير صالح", "Invalid rating target", 422);
    }
    if (score < 1 || score > 5) {
      return fail("BAD_SCORE", "التقييم من 1 إلى 5", "Score must be 1-5", 422);
    }
    const [row] = await db
      .insert(feedbackRatings)
      .values({
        targetType,
        targetId: num(body.targetId),
        authorUserId: viewer?.user.userId ?? null,
        score: Math.round(score),
        locale: str(body.locale) || "ar",
        comment: str(body.comment) || null,
      })
      .returning();
    return ok(row);
  });
}
