import { count, sql } from "drizzle-orm";
import { db } from "@/db";
import { escrowTransactions, laundryEquipment, orders, systemUsers } from "@/db/schema";
import { handler, ok } from "@/lib/api";
import { requireMfa } from "@/lib/auth";
import { escrowSummary } from "@/lib/escrow";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  return handler(async () => {
    await requireMfa(["SUPER_ADMIN", "ASSISTANT_ADMIN"]);
    const escrow = await escrowSummary();
    const [catalogue] = await db
      .select({
        items: count(),
        inventory: sql<string>`coalesce(sum(${laundryEquipment.price}), 0)::text`,
      })
      .from(laundryEquipment);
    const [tenantCount] = await db
      .select({ merchants: count() })
      .from(systemUsers)
      .where(sql`${systemUsers.roleType}::text = 'MERCHANT'`);
    const [orderStats] = await db
      .select({
        total: count(),
        gmv: sql<string>`coalesce(sum(${orders.totalAmount}), 0)::text`,
        commission: sql<string>`coalesce(sum(${orders.commissionAmount}), 0)::text`,
      })
      .from(orders);

    return ok({
      escrow,
      catalogue: {
        items: catalogue?.items ?? 0,
        inventory: Number(catalogue?.inventory ?? 0),
      },
      tenants: tenantCount?.merchants ?? 0,
      orders: {
        total: orderStats?.total ?? 0,
        gmv: Number(orderStats?.gmv ?? 0),
        commission: Number(orderStats?.commission ?? 0),
      },
    });
  });
}
