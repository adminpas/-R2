import { sql } from "drizzle-orm";
import { db } from "@/db";
import { handler, ok } from "@/lib/api";
import { COMPANY, SSD_LOGICAL_ROOT } from "@/lib/config";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  return handler(async () => {
    await db.execute(sql`select 1`);
    return ok({
      status: "ONLINE",
      platform: COMPANY.nameAr,
      adminPanel: COMPANY.adminAr,
      serverLocation: COMPANY.serverLocation,
      storageRoot: SSD_LOGICAL_ROOT,
      database: "postgres://app_db",
      timestamp: new Date().toISOString(),
    });
  });
}
