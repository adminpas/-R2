import { eq } from "drizzle-orm";
import { db } from "@/db";
import { equipmentMedia } from "@/db/schema";
import { handler } from "@/lib/api";
import { getSessionContext } from "@/lib/auth";
import { SSD_LOGICAL_ROOT, TENANT_ROOTS } from "@/lib/config";
import { mimeFromExtension, streamLogicalFile } from "@/lib/streamer";
import { merchantRoot } from "@/lib/storage";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * LOCAL SSD VIDEO STREAMER
 * GET /api/media/stream?path=/mnt/storage/Al_Najeeb_SSD/02_Trailers_4K/x.mp4
 *  - Byte-range (206) seekable streaming for 4K trailers and live feeds.
 *  - Catalog/trailer paths are public to the showroom.
 *  - Anything inside a merchant tenant sandbox requires an authenticated
 *    session (and is refused for other tenants).
 *  - ?remote=<url> transparently mirrors an off-node asset for this demo node.
 */
export async function GET(request: Request) {
  return handler(async () => {
    const url = new URL(request.url);
    const remote = url.searchParams.get("remote");
    if (remote) {
      const upstream = await fetch(remote, {
        headers: request.headers.get("range")
          ? { range: request.headers.get("range") as string }
          : undefined,
        cache: "no-store",
      });
      const headers = new Headers();
      for (const key of [
        "content-type",
        "content-length",
        "content-range",
        "accept-ranges",
        "etag",
      ]) {
        const value = upstream.headers.get(key);
        if (value) headers.set(key, value);
      }
      headers.set("X-Al-Najeeb-Storage", "REMOTE_MIRROR");
      return new Response(upstream.body, { status: upstream.status, headers });
    }

    const path = url.searchParams.get("path");
    if (!path) {
      return new Response("path query parameter required", { status: 400 });
    }
    if (!path.startsWith(SSD_LOGICAL_ROOT)) {
      return new Response("outside local SSD namespace", { status: 403 });
    }

    const tenantMarker = `/${TENANT_ROOTS.SPARE_PARTS}/Merchant_`;
    if (path.includes(tenantMarker)) {
      const ctx = await getSessionContext();
      if (!ctx) {
        return new Response("tenant media requires authentication", {
          status: 401,
        });
      }
      const privileged =
        ctx.user.roleType === "SUPER_ADMIN" ||
        ctx.user.roleType === "ASSISTANT_ADMIN";
      if (!privileged && !path.startsWith(merchantRoot(ctx.user.userId))) {
        return new Response("cross-tenant media blocked", { status: 403 });
      }
    }

    const local = await streamLogicalFile({
      logicalPath: path,
      mimeType: mimeFromExtension(path),
      rangeHeader: request.headers.get("range"),
    });

    if (local.status !== 404) return local;

    // HYBRID FAILOVER — the asset is not resident on this node's SSD, so we
    // transparently mirror it from the registered cloud replica while keeping
    // the same logical namespace and byte-range semantics.
    const [media] = await db
      .select({ remoteUrl: equipmentMedia.remoteUrl })
      .from(equipmentMedia)
      .where(eq(equipmentMedia.logicalPath, path))
      .limit(1);
    if (!media?.remoteUrl) return local;

    const range = request.headers.get("range");
    const upstream = await fetch(media.remoteUrl, {
      headers: range ? { range } : undefined,
      cache: "no-store",
    });
    const headers = new Headers({
      "X-Al-Najeeb-Storage": "LOCAL_SSD_MISS_REMOTE_MIRROR",
      "X-Al-Najeeb-Logical-Path": path,
      "Accept-Ranges": "bytes",
    });
    for (const key of ["content-type", "content-length", "content-range"]) {
      const value = upstream.headers.get(key);
      if (value) headers.set(key, value);
    }
    return new Response(upstream.body, { status: upstream.status, headers });
  });
}
