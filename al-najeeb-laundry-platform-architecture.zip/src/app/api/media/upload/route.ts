import { and, eq } from "drizzle-orm";
import { promises as fs } from "node:fs";
import { db } from "@/db";
import { equipmentMedia, laundryEquipment } from "@/db/schema";
import { fail, handler, ok } from "@/lib/api";
import { audit, requireUser } from "@/lib/auth";
import { LIMITS, TENANT_ROOTS, SSD_LOGICAL_ROOT } from "@/lib/config";
import {
  assertTenantPath,
  ensureLogicalFolder,
  merchantRoot,
  resolveScopeFolder,
  writeLogicalFile,
} from "@/lib/storage";

export const runtime = "nodejs";

/**
 * Multi-tenant SSD upload.
 * Merchants may ONLY write inside:
 *   /mnt/storage/Al_Najeeb_SSD/04_Spare_Parts/Merchant_[id]/...
 * Any other path — including ../ traversal — is intercepted and audited.
 */
export async function POST(request: Request) {
  return handler(async () => {
    const ctx = await requireUser([
      "MERCHANT",
      "SUPER_ADMIN",
      "ASSISTANT_ADMIN",
      "MAINTENANCE_TECH",
    ]);
    const form = await request.formData();
    const file = form.get("file");
    if (!(file instanceof File)) {
      return fail("FILE_REQUIRED", "الملف مطلوب", "File is required", 422);
    }
    if (file.size > LIMITS.MAX_UPLOAD_BYTES) {
      return fail(
        "FILE_TOO_LARGE",
        "حجم الملف يتجاوز الحد المسموح",
        "File exceeds the allowed size",
        413,
      );
    }
    const requestedFolder = String(form.get("folder") ?? "");
    const scope = {
      userId: ctx.user.userId,
      roleType: ctx.user.roleType,
      merchantId: ctx.user.userId,
    };

    // resolveScopeFolder throws PathTraversalError on illegal traversal.
    const tenantFolder = resolveScopeFolder(scope, requestedFolder || merchantRoot(ctx.user.userId));
    const bytes = new Uint8Array(await file.arrayBuffer());
    const written = await writeLogicalFile(tenantFolder, file.name, bytes);
    // Proves the written file resolves back inside the tenant sandbox.
    assertTenantPath(scope, written.logicalPath);

    const kind = String(form.get("kind") ?? "IMAGE") as
      | "IMAGE"
      | "TRAILER"
      | "LIVE_FEED";
    const equipmentId = Number(form.get("equipmentId")) || null;

    const [media] = await db
      .insert(equipmentMedia)
      .values({
        equipmentId,
        merchantId: ctx.user.userId,
        kind,
        logicalPath: written.logicalPath,
        mimeType: file.type || "application/octet-stream",
        sizeBytes: written.sizeBytes,
        isVertical: kind !== "IMAGE",
      })
      .returning();

    if (equipmentId && kind === "TRAILER") {
      await db
        .update(laundryEquipment)
        .set({ videoTrailerPath: written.logicalPath })
        .where(
          and(
            eq(laundryEquipment.equipmentId, equipmentId),
            eq(laundryEquipment.merchantId, ctx.user.userId),
          ),
        );
    }

    await audit({
      actorUserId: ctx.user.userId,
      eventType: "SSD_UPLOAD",
      detail: {
        logicalPath: written.logicalPath,
        bytes: written.sizeBytes,
        tenantFolder,
      },
    });

    return ok({
      media,
      logicalPath: written.logicalPath,
      streamUrl: `/api/media/stream?path=${encodeURIComponent(written.logicalPath)}`,
      tenantRoot: merchantRoot(ctx.user.userId),
      catalogRoot: `${SSD_LOGICAL_ROOT}/${TENANT_ROOTS.CATALOG}`,
    });
  });
}

/** GET: lists the caller tenant folder on the local SSD. */
export async function GET(request: Request) {
  return handler(async () => {
    const ctx = await requireUser();
    const url = new URL(request.url);
    const folder = url.searchParams.get("folder") ?? merchantRoot(ctx.user.userId);
    const privileged =
      ctx.user.roleType === "SUPER_ADMIN" || ctx.user.roleType === "ASSISTANT_ADMIN";
    const scope = {
      userId: ctx.user.userId,
      roleType: ctx.user.roleType,
      merchantId: ctx.user.userId,
    };
    const target = privileged ? folder : resolveScopeFolder(scope, folder);
    await ensureLogicalFolder(target);
    const entries = await fs.readdir(assertTenantPath(scope, target));
    const detailed = await Promise.all(
      entries.map(async (name) => {
        const full = `${target}/${name}`;
        let size = 0;
        try {
          size = (await fs.stat(assertTenantPath(scope, full))).size;
        } catch {
          size = 0;
        }
        return { name, logicalPath: full, sizeBytes: size };
      }),
    );
    return ok({ folder: target, entries: detailed });
  });
}
