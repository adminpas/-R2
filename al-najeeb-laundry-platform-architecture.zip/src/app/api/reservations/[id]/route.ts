import { fail, handler, ok, readJson, str } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { convertHoldToOrder, releaseHold } from "@/lib/reservations";
import { createShippingJob } from "@/lib/shipping";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_request: Request, ctx: Ctx) {
  return handler(async () => {
    const { id } = await ctx.params;
    return ok({
      reservationId: Number(id),
      hint: "PATCH with action=CONVERT|RELEASE",
    });
  });
}

export async function PATCH(request: Request, ctxParams: Ctx) {
  return handler(async () => {
    const viewer = await requireUser();
    const { id } = await ctxParams.params;
    const reservationId = Number(id);
    const body = await readJson(request);
    const action = str(body.action).toUpperCase();

    if (action === "CONVERT") {
      const result = await convertHoldToOrder({
        reservationId,
        actorId: viewer.user.userId,
        installationRequested: Boolean(body.installationRequested),
      });
      let job = null;
      if (body.installationRequested || body.requestShipping) {
        job = await createShippingJob({
          orderId: result.order.orderId,
          courierUserId: viewer.user.roleType === "SHIPPING_COMPANY" ? viewer.user.userId : null,
          installationRequested: Boolean(body.installationRequested),
        });
      }
      return ok({ order: result.order, escrow: result.balanceEscrow, shippingJob: job });
    }

    if (action === "RELEASE") {
      const result = await releaseHold({ reservationId, actorId: viewer.user.userId });
      return ok(result);
    }

    return fail("UNKNOWN_ACTION", "إجراء غير معروف", "Unknown action", 422);
  });
}

export async function POST(request: Request, ctxParams: Ctx) {
  return handler(async () => {
    const viewer = await requireUser();
    const { id } = await ctxParams.params;
    const body = await readJson(request);
    if (str(body.action).toUpperCase() !== "CONVERT") {
      return fail("UNKNOWN_ACTION", "إجراء غير معروف", "Unknown action", 422);
    }
    const result = await convertHoldToOrder({
      reservationId: Number(id),
      actorId: viewer.user.userId,
      installationRequested: Boolean(body.installationRequested),
    });
    const job = await createShippingJob({
      orderId: result.order.orderId,
      courierUserId: viewer.user.roleType === "SHIPPING_COMPANY" ? viewer.user.userId : null,
      installationRequested: Boolean(body.installationRequested),
    });
    return ok({ order: result.order, escrow: result.balanceEscrow, shippingJob: job });
  });
}

export function DELETE() {
  return fail("NOT_SUPPORTED", "غير مدعوم", "Not supported", 405);
}
