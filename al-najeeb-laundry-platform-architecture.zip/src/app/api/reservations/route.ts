import { handler, ok, num } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { createHold, expireStaleHolds, listReservationsFor } from "@/lib/reservations";
import { requiredDownpayment } from "@/lib/finance";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  return handler(async () => {
    const ctx = await requireUser();
    await expireStaleHolds();
    const rows = await listReservationsFor(ctx.user.userId);
    return ok(rows);
  });
}

/** POST — 24h live-showroom hold, gated by the >=25% automated downpayment. */
export async function POST(request: Request) {
  return handler(async () => {
    const ctx = await requireUser();
    const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
    const equipmentId = num(body.equipmentId);
    const amountPaid = num(body.amountPaid);
    const hold = await createHold({
      equipmentId,
      customerId: ctx.user.userId,
      amountPaid,
      paymentMethod: String(body.paymentMethod ?? "MADA_LOCAL_GATEWAY"),
    });
    return ok({ ...hold, expiresWithinHours: 24 });
  });
}

/** PATCH — quote helper: returns the mandatory one-quarter downpayment. */
export async function PUT(request: Request) {
  return handler(async () => {
    const body = (await request.json().catch(() => ({}))) as Record<string, unknown>;
    const price = num(body.price);
    return ok({ required: requiredDownpayment(price), holdHours: 24 });
  });
}
