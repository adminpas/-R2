import { handler, num, ok, readJson, str } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { createShippingJob, listShippingJobs, updateShippingStatus } from "@/lib/shipping";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const STATUSES = ["ASSIGNED", "PICKED_UP", "IN_TRANSIT", "DELIVERED", "FAILED"] as const;
type Status = (typeof STATUSES)[number];

export async function GET() {
  return handler(async () => {
    const viewer = await requireUser();
    const scoped =
      viewer.user.roleType === "SHIPPING_COMPANY" ? viewer.user.userId : undefined;
    const jobs = await listShippingJobs(scoped);
    return ok({ jobs, viewerRole: viewer.user.roleType });
  });
}

export async function POST(request: Request) {
  return handler(async () => {
    const viewer = await requireUser(["SUPER_ADMIN", "ASSISTANT_ADMIN", "SHIPPING_COMPANY", "MERCHANT"]);
    const body = await readJson(request);
    const job = await createShippingJob({
      orderId: num(body.orderId),
      courierUserId: viewer.user.roleType === "SHIPPING_COMPANY" ? viewer.user.userId : num(body.courierUserId) || null,
      installationRequested: Boolean(body.installationRequested),
      driverName: str(body.driverName) || undefined,
      driverPhone: str(body.driverPhone) || undefined,
      vehiclePlate: str(body.vehiclePlate) || undefined,
    });
    return ok(job);
  });
}

export async function PATCH(request: Request) {
  return handler(async () => {
    const viewer = await requireUser(["SHIPPING_COMPANY", "SUPER_ADMIN", "ASSISTANT_ADMIN"]);
    const body = await readJson(request);
    const status = str(body.status).toUpperCase() as Status;
    if (!STATUSES.includes(status)) {
      return ok({ error: "BAD_STATUS" });
    }
    const job = await updateShippingStatus({
      jobId: num(body.jobId),
      actorId: viewer.user.userId,
      status,
      driverName: str(body.driverName) || undefined,
      driverPhone: str(body.driverPhone) || undefined,
      notes: str(body.notes) || undefined,
    });
    return ok(job);
  });
}
