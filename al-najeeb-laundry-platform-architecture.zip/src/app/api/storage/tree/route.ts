import { promises as fs } from "node:fs";
import { handler, ok } from "@/lib/api";
import { audit, getSessionContext } from "@/lib/auth";
import { SSD_LOGICAL_ROOT, SSD_PHYSICAL_ROOT, TENANT_ROOTS } from "@/lib/config";
import {
  PathTraversalError,
  ensureLogicalFolder,
  merchantRoot,
  resolveScopeFolder,
} from "@/lib/storage";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * SSD Storage Mapping Controller — read API.
 * Demonstrates the strict tenant sandbox and logs every blocked traversal.
 */
export async function GET(request: Request) {
  return handler(async () => {
    const ctx = await getSessionContext();
    const url = new URL(request.url);
    const requested = url.searchParams.get("folder") ?? "";

    if (!ctx) {
      return ok({
        authenticated: false,
        logicalRoot: SSD_LOGICAL_ROOT,
        physicalRoot: SSD_PHYSICAL_ROOT,
        structure: Object.values(TENANT_ROOTS),
        note: "sign in to map a tenant folder",
      });
    }

    const privileged =
      ctx.user.roleType === "SUPER_ADMIN" ||
      ctx.user.roleType === "ASSISTANT_ADMIN";
    const scope = {
      userId: ctx.user.userId,
      roleType: ctx.user.roleType,
      merchantId: ctx.user.userId,
    };

    try {
      const folder = resolveScopeFolder(scope, requested || merchantRoot(ctx.user.userId));
      await ensureLogicalFolder(folder);
      const physical = folder.replace(SSD_LOGICAL_ROOT, SSD_PHYSICAL_ROOT);
      const entries = await fs.readdir(physical);
      return ok({
        authenticated: true,
        roleType: ctx.user.roleType,
        tenantRoot: merchantRoot(ctx.user.userId),
        folder,
        entries,
      });
    } catch (error) {
      if (error instanceof PathTraversalError) {
        await audit({
          actorUserId: ctx.user.userId,
          eventType: "TENANT_TRAVERSAL_BLOCKED",
          severity: "CRITICAL",
          detail: { requested, roleType: ctx.user.roleType },
        });
      }
      throw error;
    }
  });
}
