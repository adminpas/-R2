import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { maintenanceTickets, systemUsers } from "@/db/schema";
import { handler, num, ok, readJson, str } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { openTicketWithVision, analyzeFrame } from "@/lib/support";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  return handler(async () => {
    const viewer = await requireUser();
    const rows = await db
      .select({
        ticket: maintenanceTickets,
        techNameAr: systemUsers.displayNameAr,
      })
      .from(maintenanceTickets)
      .leftJoin(systemUsers, eq(systemUsers.userId, maintenanceTickets.assignedTechId))
      .orderBy(desc(maintenanceTickets.ticketId))
      .limit(60);
    return ok({ tickets: rows, viewer: viewer.user.roleType });
  });
}

/** POST — AI camera-vision diagnostic + automatic WebRTC room creation. */
export async function POST(request: Request) {
  return handler(async () => {
    const viewer = await requireUser();
    const body = await readJson(request);
    const summary = str(body.issueSummary);
    if (summary.length < 6) {
      return ok({
        report: analyzeFrame({ symptomText: summary }),
        persisted: false,
      });
    }
    const result = await openTicketWithVision({
      createdByUserId: viewer.user.userId,
      issueSummary: summary,
      equipmentId: num(body.equipmentId) || null,
      merchantId: viewer.user.roleType === "MERCHANT" ? viewer.user.userId : num(body.merchantId) || null,
      customerId: num(body.customerId) || null,
      severity: str(body.severity) || undefined,
      luminance: body.luminance === undefined ? undefined : num(body.luminance),
      motionScore: body.motionScore === undefined ? undefined : num(body.motionScore),
    });
    return ok({
      ticket: result.ticket,
      report: result.report,
      roomId: result.roomId,
      conferenceUrl: `/support?room=${result.roomId}`,
      persisted: true,
    });
  });
}
