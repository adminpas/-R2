import { AuctionRoom } from "@/components/AuctionRoom";
import { getShowroomStats } from "@/lib/catalog";
import { listAuctions, processMaturedAuctions } from "@/lib/auctions";
import { LIMITS } from "@/lib/config";

export const dynamic = "force-dynamic";

export default async function AuctionsPage() {
  await processMaturedAuctions(0);
  const [rows, stats] = await Promise.all([listAuctions(false), getShowroomStats()]);

  const payload = rows.map((row) => ({
    auction: {
      auctionId: row.auction.auctionId,
      packageTitle: row.auction.packageTitle,
      baseCostPrice: row.auction.baseCostPrice,
      currentHighestBid: row.auction.currentHighestBid,
      minimumIncrement: row.auction.minimumIncrement,
      startDate: row.auction.startDate.toISOString(),
      endDate: row.auction.endDate.toISOString(),
      isProcessed: row.auction.isProcessed,
      packageDetails: row.auction.packageDetails ?? null,
    },
    bidderName: row.bidderName,
    bidCount: row.bidCount,
  }));

  return (
    <div className="mx-auto max-w-[1500px] space-y-5">
      <section className="najeeb-card najeeb-glow space-y-3 rounded-3xl p-5">
        <h1 className="text-xl font-black text-white lg:text-2xl">
          🔨 المزادات الذكية — باقات بسعر التكلفة بدون ربح
        </h1>
        <p className="max-w-3xl text-xs leading-relaxed text-slate-300">
          منظومة دورية (كل ٣٠ يوماً) لبناء مشاريع مغاسل لأصحاب الدخل المحدود:
          يُعاد بيع باقات المعدات بسعر التكلفة الحقيقي، مع حد أدنى للزيادة{" "}
          <span className="font-black text-amber-200">
            {LIMITS.AUCTION_MIN_INCREMENT_SAR} ر.س
          </span>{" "}
          ومعالجة تلقائية لأعلى مزايد عند انتهاء المؤقت.
        </p>
        <div className="grid gap-2 sm:grid-cols-3">
          <div className="rounded-2xl border border-white/10 bg-black/25 p-3">
            <p className="text-[10px] text-slate-400">باقات مفتوحة</p>
            <p className="text-xl font-black text-amber-200">{stats.openAuctions}</p>
          </div>
          <div className="rounded-2xl border border-white/10 bg-black/25 p-3">
            <p className="text-[10px] text-slate-400">أعلى مزايدة حالياً</p>
            <p className="text-xl font-black text-emerald-300">
              {new Intl.NumberFormat("ar-SA").format(stats.topBid)} ر.س
            </p>
          </div>
          <div className="rounded-2xl border border-white/10 bg-black/25 p-3">
            <p className="text-[10px] text-slate-400">أقل زيادة مسموحة</p>
            <p className="text-xl font-black text-teal-300">
              {LIMITS.AUCTION_MIN_INCREMENT_SAR} ر.س
            </p>
          </div>
        </div>
      </section>

      <AuctionRoom auctions={payload} />
    </div>
  );
}
