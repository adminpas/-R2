import Link from "next/link";
import { getSessionContext } from "@/lib/auth";
import { DashboardGate } from "@/components/panels/DashboardGate";

export const dynamic = "force-dynamic";

const PANEL_TITLES: Record<string, string> = {
  SUPER_ADMIN: "لوحة تحكم نظام معرض شركة النجيب المتطورة لمعدات المغاسل",
  ASSISTANT_ADMIN: "لوحة تحكم نظام معرض شركة النجيب المتطورة لمعدات المغاسل",
  MERCHANT: "لوحة تحكم نظام قطع الغيار",
  SHIPPING_COMPANY: "لوحة تحكم شركة التوصيل",
  MAINTENANCE_TECH: "لوحة تحكم قسم التركيب والصيانة",
};

export default async function DashboardPage() {
  const ctx = await getSessionContext();

  if (!ctx) {
    return (
      <div className="mx-auto max-w-xl space-y-3">
        <div className="najeeb-card space-y-3 rounded-3xl p-6 text-center">
          <h1 className="text-lg font-black text-white">لوحات التحكم محمية</h1>
          <p className="text-xs leading-relaxed text-slate-400">
            سجّل الدخول بحساب معتمد للوصول إلى لوحة الإدارة العليا، لوحة قطع
            الغيار، لوحة شركة التوصيل، أو لوحة قسم التركيب والصيانة. كل لوحة
            مقفلة على جهاز واحد فقط وتتطلب توثيق البصمة للعمليات الحساسة.
          </p>
          <Link
            href="/login"
            className="inline-block rounded-2xl bg-amber-400 px-5 py-2.5 text-xs font-black text-slate-900"
          >
            تسجيل الدخول
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-[1500px] space-y-4">
      <section className="najeeb-card najeeb-glow space-y-2 rounded-3xl p-5">
        <h1 className="text-base font-black text-white lg:text-xl">
          {PANEL_TITLES[ctx.user.roleType] ?? "لوحة التحكم"}
        </h1>
        <p className="text-[11px] text-slate-400">
          👤 {ctx.user.displayNameAr ?? ctx.user.username} ·{" "}
          <span className="font-mono">{ctx.user.username}</span> · 🔒 قفل الجهاز:{" "}
          <span className="font-mono" dir="ltr">
            {ctx.hardwareDeviceId?.slice(0, 16) ?? "غير مقفل"}
          </span>{" "}
          · {ctx.biometricVerified ? "✅ MFA موثّق" : "⚠️ يتطلب توثيق البصمة"}
        </p>
        {ctx.user.merchantSsdFolder ? (
          <p className="truncate font-mono text-[10px] text-slate-500" dir="ltr">
            {ctx.user.merchantSsdFolder}
          </p>
        ) : null}
      </section>

      <DashboardGate roleType={ctx.user.roleType} userId={ctx.user.userId} />
    </div>
  );
}
