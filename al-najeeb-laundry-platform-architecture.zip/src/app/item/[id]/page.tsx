import Link from "next/link";
import { notFound } from "next/navigation";
import { ItemActions, LiveShowroomPlayer } from "@/components/ItemActions";
import { getEquipmentDetail } from "@/lib/catalog";
import { AVAILABILITY_LABELS, STATUS_LABELS } from "@/lib/catalog";
import { SSD_LOGICAL_ROOT } from "@/lib/config";

export const dynamic = "force-dynamic";

export default async function ItemPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const detail = await getEquipmentDetail(Number(id));
  if (!detail) notFound();

  const { equipment, category, merchant, media, rating, ratings } = detail;
  const status = STATUS_LABELS[equipment.equipmentStatus];
  const availability = AVAILABILITY_LABELS[equipment.availabilityStatus];
  const trailer = media.find((entry) => entry.kind === "TRAILER");
  const specs = equipment.specsJson ?? {};
  const price = Number(equipment.price);
  const downpayment = Math.round(price * 0.25 * 100) / 100;
  const commission = Number(equipment.commissionPercentage);

  return (
    <div className="mx-auto max-w-[1500px] space-y-5">
      <nav className="flex items-center gap-2 text-[11px] text-slate-400">
        <Link href="/" className="hover:text-amber-200">
          المعرض
        </Link>
        <span>/</span>
        <span className="text-slate-300">{category?.categoryNameAr ?? "عام"}</span>
        <span>/</span>
        <span className="truncate text-amber-200">{equipment.titleAr}</span>
      </nav>

      <div className="grid gap-4 lg:grid-cols-[1.25fr_1fr]">
        <div className="space-y-4">
          <LiveShowroomPlayer
            equipmentId={equipment.equipmentId}
            titleAr={equipment.titleAr}
            trailerUrl={trailer?.remoteUrl ?? null}
            trailerPath={trailer?.logicalPath ?? equipment.videoTrailerPath ?? null}
            poster={
              trailer?.posterUrl ?? equipment.posterImagePath ?? null
            }
            live={equipment.isLiveShowroom}
          />

          <div className="najeeb-card space-y-3 rounded-3xl p-4">
            <div className="flex flex-wrap items-center gap-2">
              <span className={`rounded-full border px-2.5 py-1 text-[10px] font-bold ${status.tone}`}>
                {status.ar}
              </span>
              <span className={`rounded-full border px-2.5 py-1 text-[10px] font-bold ${availability.tone}`}>
                {availability.ar}
              </span>
              <span className="rounded-full border border-white/15 px-2.5 py-1 text-[10px] text-slate-300">
                ⭐ {rating.average.toFixed(1)} ({rating.total})
              </span>
              <span className="rounded-full border border-white/15 px-2.5 py-1 text-[10px] text-slate-300">
                💠 عمولة {commission}%
              </span>
            </div>
            <h1 className="text-xl font-black text-white lg:text-2xl">
              {equipment.titleAr}
            </h1>
            {equipment.titleEn ? (
              <p className="text-xs text-slate-400">{equipment.titleEn}</p>
            ) : null}
            <p className="text-sm leading-relaxed text-slate-300">
              {equipment.descriptionAr}
            </p>

            <div className="grid gap-2 sm:grid-cols-2">
              {Object.entries(specs).map(([key, value]) => (
                <div
                  key={key}
                  className="flex items-center justify-between rounded-2xl border border-white/10 bg-black/25 px-3 py-2 text-[11px]"
                >
                  <span className="text-slate-400">{key}</span>
                  <span className="font-bold text-slate-100">{value}</span>
                </div>
              ))}
            </div>

            <p className="truncate font-mono text-[9px] text-slate-500" dir="ltr">
              {SSD_LOGICAL_ROOT}/02_Trailers_4K · stream via /api/media/stream
            </p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="najeeb-card space-y-3 rounded-3xl p-4">
            <div>
              <p className="text-[11px] text-slate-400">السعر النهائي</p>
              <p className="text-3xl font-black text-amber-300">
                {new Intl.NumberFormat("ar-SA", { maximumFractionDigits: 0 }).format(
                  price,
                )}{" "}
                ر.س
              </p>
            </div>
            <div className="space-y-1.5 rounded-2xl border border-white/10 bg-black/25 p-3 text-[11px]">
              <div className="flex justify-between">
                <span className="text-slate-400">الدفعة المقدمة (٢٥٪) — إلزامية للحجز</span>
                <span className="font-black text-teal-300">
                  {downpayment.toLocaleString("ar-SA")} ر.س
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">المتبقي بعد الحجز</span>
                <span className="font-bold text-slate-200">
                  {(price - downpayment).toLocaleString("ar-SA")} ر.س
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">عمولة المنصة (سقف ١٥٪)</span>
                <span className="font-bold text-slate-200">
                  {Math.round(((price * commission) / 100) * 100) / 100} ر.س
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">صافي التاجر عبر الضمان</span>
                <span className="font-bold text-emerald-300">
                  {Math.round((price - (price * commission) / 100) * 100) / 100} ر.س
                </span>
              </div>
            </div>
            <p className="text-[10px] leading-relaxed text-slate-400">
              🏪 البائع: {merchant?.displayNameAr ?? "النجيب"} —{" "}
              {merchant?.city ?? "جدة"} · كل المبالغ تُحفظ في محفظة الضمان
              (Escrow) ولا تُحوَّل للتاجر إلا بعد التسليم أو انتهاء مدة الحجز.
            </p>
          </div>

          <ItemActions
            equipmentId={equipment.equipmentId}
            price={price}
            downpayment={downpayment}
            availability={equipment.availabilityStatus}
          />
        </div>
      </div>

      <section className="najeeb-card space-y-3 rounded-3xl p-4">
        <h2 className="text-sm font-black text-white">⭐ تقييمات العملاء (Omni-Rating)</h2>
        {ratings.length === 0 ? (
          <p className="text-xs text-slate-400">لا توجد تقييمات بعد — كن أول المقيّمين.</p>
        ) : (
          <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
            {ratings.map((row) => (
              <div key={row.rating.ratingId} className="rounded-2xl border border-white/10 bg-black/25 p-3">
                <div className="flex items-center justify-between text-[10px] text-slate-400">
                  <span>{row.authorNameAr ?? "عميل النجيب"}</span>
                  <span className="text-amber-300">{"★".repeat(row.rating.score)}</span>
                </div>
                <p className="mt-1 text-xs text-slate-200">{row.rating.comment}</p>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
