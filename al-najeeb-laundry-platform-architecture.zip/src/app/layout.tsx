import type { Metadata } from "next";
import type { ReactNode } from "react";
import { cookies } from "next/headers";
import "./globals.css";
import { PlatformProvider } from "@/components/Providers";
import { Shell } from "@/components/Shell";

export const metadata: Metadata = {
  title: "معرض شركة النجيب المتطورة لمعدات المغاسل",
  description:
    "منصة معرض النجيب المتطورة لمعدات المغاسل — بث مباشر للمعرض، مزادات التكلفة، قطع غيار، تركيب وصيانة، وتخزين SSD محلي. جدة — الخمرة.",
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  const jar = await cookies();
  const locale = jar.get("najeeb_locale")?.value ?? "ar";
  const dir = locale === "en" || locale === "fr" ? "ltr" : "rtl";
  return (
    <html lang={locale} dir={dir}>
      <body className="antialiased">
        <PlatformProvider>
          <Shell>{children}</Shell>
        </PlatformProvider>
      </body>
    </html>
  );
}
