"use client";

import { useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { api, hardwareProbe } from "@/lib/client";
import { usePlatform } from "@/components/Providers";

type Mode = "login" | "join";

const ROLES = [
  { code: "MERCHANT", label: "تاجر قطع غيار (لوحة قطع الغيار)" },
  { code: "MAINTENANCE_TECH", label: "فني تركيب وصيانة" },
  { code: "SHIPPING_COMPANY", label: "شركة توصيل" },
  { code: "ASSISTANT_ADMIN", label: "مساعد إدارة" },
];

const DEMO = [
  { user: "najeeb_admin", pass: "Najeeb@1447", role: "الإدارة العليا" },
  { user: "merchant_jeddah", pass: "Merchant@1447", role: "تاجر قطع الغيار" },
  { user: "tech_najeeb", pass: "Tech@1447", role: "التركيب والصيانة" },
  { user: "shipping_alkhumra", pass: "Shipping@1447", role: "شركة التوصيل" },
];

export default function LoginPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { refreshSession, runBiometric, t } = usePlatform();
  const [mode, setMode] = useState<Mode>(searchParams.get("mode") === "join" ? "join" : "login");
  const [username, setUsername] = useState("najeeb_admin");
  const [password, setPassword] = useState("Najeeb@1447");
  const [roleType, setRoleType] = useState("MERCHANT");
  const [city, setCity] = useState("جدة");
  const [probe, setProbe] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [okMsg, setOkMsg] = useState<string | null>(null);

  useEffect(() => {
    void hardwareProbe().then((value) => {
      setProbe(value);
      localStorage.setItem("najeeb_hw", value.slice(0, 128));
    });
  }, []);

  async function submit() {
    setBusy(true);
    setError(null);
    setOkMsg(null);
    try {
      if (mode === "login") {
        await api("/api/auth/login", {
          method: "POST",
          json: {
            username,
            password,
            hwProbe: probe ?? "",
            deviceLabel: "Al-Najeeb Terminal",
          },
        });
        await refreshSession();
        setOkMsg("تم تسجيل الدخول وتفعيل قفل الجهاز الواحد ✅");
        router.push("/dashboard");
      } else {
        await api("/api/auth/register", {
          method: "POST",
          json: {
            username,
            password,
            roleType,
            city,
            hwProbe: probe ?? "",
            displayNameAr: username,
          },
        });
        setMode("login");
        setOkMsg(
          "تم إنشاء الحساب وربطه بجهازك. بانتظار موافقة الإدارة العليا قبل التفعيل.",
        );
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "تعذر إكمال العملية");
    } finally {
      setBusy(false);
    }
  }

  async function handshake() {
    setBusy(true);
    setError(null);
    try {
      await runBiometric();
      setOkMsg("تم توثيق البصمة (FaceID/TouchID) وترقية الجلسة إلى MFA ✅");
    } catch (err) {
      setError(err instanceof Error ? err.message : "فشل توثيق البصمة");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto max-w-[980px] space-y-4">
      <section className="najeeb-card najeeb-glow space-y-3 rounded-3xl p-5">
        <h1 className="text-lg font-black text-white lg:text-xl">
          {mode === "login" ? "بوابة دخول منصة النجيب" : "إنشاء حساب جديد في المنصة"}
        </h1>
        <p className="text-[11px] leading-relaxed text-slate-400">
          قفل الجهاز الواحد: يُربط الحساب بأول جهاز يُهيّئ فعلياً. أي محاولة دخول
          من جهاز آخر تُسجَّل وتُحجب فوراً (Hardware Binding + FaceID/TouchID MFA).
        </p>
        <div className="flex items-center gap-2 rounded-2xl border border-white/10 bg-black/30 p-2.5 font-mono text-[10px] text-slate-400">
          <span className="rounded-lg bg-amber-400/15 px-2 py-0.5 text-amber-200">
            HW-ID
          </span>
          <span className="truncate" dir="ltr">
            {probe ? probe.slice(0, 96) : "…generating hardware attestation"}
          </span>
        </div>
      </section>

      <div className="grid gap-4 lg:grid-cols-[1fr_0.9fr]">
        <section className="najeeb-card space-y-3 rounded-3xl p-5">
          <div className="flex gap-2">
            {(["login", "join"] as Mode[]).map((value) => (
              <button
                key={value}
                onClick={() => setMode(value)}
                className={`flex-1 rounded-2xl px-3 py-2 text-xs font-black ${
                  mode === value
                    ? "bg-amber-400 text-slate-900"
                    : "border border-white/10 text-slate-300"
                }`}
              >
                {value === "login" ? t("login") : t("join")}
              </button>
            ))}
          </div>

          <label className="block space-y-1">
            <span className="text-[11px] text-slate-400">{t("username")}</span>
            <input
              value={username}
              onChange={(event) => setUsername(event.target.value)}
              className="w-full rounded-2xl border border-white/10 bg-slate-950/60 px-3 py-2.5 text-sm text-slate-100 outline-none focus:border-amber-300/50"
            />
          </label>
          <label className="block space-y-1">
            <span className="text-[11px] text-slate-400">{t("password")}</span>
            <input
              type="password"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              className="w-full rounded-2xl border border-white/10 bg-slate-950/60 px-3 py-2.5 text-sm text-slate-100 outline-none focus:border-amber-300/50"
            />
          </label>

          {mode === "join" ? (
            <div className="grid gap-2 sm:grid-cols-2">
              <label className="space-y-1">
                <span className="text-[11px] text-slate-400">نوع الحساب</span>
                <select
                  value={roleType}
                  onChange={(event) => setRoleType(event.target.value)}
                  className="w-full rounded-2xl border border-white/10 bg-slate-950/60 px-3 py-2.5 text-xs text-slate-100"
                >
                  {ROLES.map((role) => (
                    <option key={role.code} value={role.code}>
                      {role.label}
                    </option>
                  ))}
                </select>
              </label>
              <label className="space-y-1">
                <span className="text-[11px] text-slate-400">المدينة</span>
                <input
                  value={city}
                  onChange={(event) => setCity(event.target.value)}
                  className="w-full rounded-2xl border border-white/10 bg-slate-950/60 px-3 py-2.5 text-xs text-slate-100"
                />
              </label>
            </div>
          ) : null}

          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => void submit()}
              disabled={busy}
              className="flex-1 rounded-2xl bg-gradient-to-r from-amber-300 to-amber-500 px-4 py-3 text-xs font-black text-slate-900 disabled:opacity-50"
            >
              {mode === "login" ? t("login") : "إنشاء الحساب وربط الجهاز"}
            </button>
            <button
              onClick={() => void handshake()}
              disabled={busy}
              className="rounded-2xl border border-teal-300/30 bg-teal-400/10 px-4 py-3 text-xs font-black text-teal-200 disabled:opacity-50"
            >
              🫆 {t("mfa")}
            </button>
          </div>

          {okMsg ? (
            <p className="rounded-2xl border border-emerald-300/30 bg-emerald-400/10 p-2.5 text-[11px] text-emerald-100">
              {okMsg}
            </p>
          ) : null}
          {error ? (
            <p className="rounded-2xl border border-rose-300/30 bg-rose-400/10 p-2.5 text-[11px] text-rose-100">
              {error}
            </p>
          ) : null}
        </section>

        <section className="najeeb-card space-y-3 rounded-3xl p-5">
          <h2 className="text-sm font-black text-white">حسابات تجريبية مُهيّأة</h2>
          <div className="space-y-2">
            {DEMO.map((entry) => (
              <button
                key={entry.user}
                onClick={() => {
                  setMode("login");
                  setUsername(entry.user);
                  setPassword(entry.pass);
                }}
                className="w-full rounded-2xl border border-white/10 bg-black/25 p-3 text-right hover:border-amber-300/40"
              >
                <p className="text-xs font-black text-amber-200">{entry.role}</p>
                <p className="font-mono text-[10px] text-slate-400" dir="ltr">
                  {entry.user} / {entry.pass}
                </p>
              </button>
            ))}
          </div>
          <p className="text-[10px] leading-relaxed text-slate-500">
            الحسابات الجديدة (باستثناء الإدارة) تبدأ بحالة
            <span className="text-amber-200"> بانتظار موافقة الإدارة العليا</span> ولا
            يمكنها الدخول قبل الاعتماد من لوحة الإدارة مع توثيق البصمة.
          </p>
        </section>
      </div>
    </div>
  );
}


