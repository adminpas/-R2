import Link from "next/link";
import { TrailerRail } from "@/components/TrailerRail";
import { HomeSearch } from "@/components/HomeSearch";
import {
  AVAILABILITY_LABELS,
  STATUS_LABELS,
  getCategories,
  getEquipment,
  getShowroomStats,
  getTrailers,
} from "@/lib/catalog";
import { COMPANY, SSD_LOGICAL_ROOT, TENANT_ROOTS } from "@/lib/config";

export const dynamic = "force-dynamic";

export default async function ShowroomHome({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; categoryId?: string; availability?: string }>;
}) {
  const params = await searchParams;
  const [trailers, categories, items, stats] = await Promise.all([
    getTrailers(),
    getCategories(),
    getEquipment({
      q: params.q,
      categoryId: Number(params.categoryId) || undefined,
      availability: params.availability,
    }),
    getShowroomStats(),
  ]);

  const strips = [
    { label: "معدات معروضة", value: stats.items, glyph: "🧺" },
    { label: "بثوث مباشرة", value: stats.liveFeeds, glyph: "📡" },
    { label: "مزادات مفتوحة", value: stats.openAuctions, glyph: "🔨" },
    { label: "طلبات مكتملة", value: stats.orders, glyph: "🧾" },
    { label: "مهام توصيل", value: stats.deliveries, glyph: "🚚" },
  ];

  return (
    <div className="mx-auto max-w-[1500px] space-y-7">
      {/* HERO */}
      <section className="najeeb-card relative overflow-hidden rounded-3xl p-5 lg:p-8">
        <div className="absolute -left-16 -top-20 h-56 w-56 rounded-full bg-amber-400/10 blur-3xl" />
        <div className="absolute -bottom-24 right-10 h-56 w-56 rounded-full bg-teal-400/10 blur-3xl" />
        <div className="relative grid gap-6 lg:grid-cols-[1.4fr_1fr]">
          <div className="space-y-4">
            <span className="inline-flex items-center gap-2 rounded-full border border-amber-300/30 bg-amber-400/10 px-3 py-1 text-[10px] font-black text-amber-200">
              <span className="live-dot h-1.5 w-1.5 rounded-full bg-amber-300" />
              {COMPANY.serverLocation} · {COMPANY.storageLabel}
            </span>
            <h1 className="text-2xl font-black leading-snug text-white lg:text-4xl">
              معرض شركة النجيب المتطورة لمعدات المغاسل
            </h1>
            <p className="max-w-2xl text-sm leading-relaxed text-slate-300">
              بث مباشر للمعرض، حجز فوري ٢٤ ساعة بدفعة مقدمة ٢٥٪، مزادات باقات
              بسعر التكلفة لأصحاب الدخل المحدود، قطع غيار أصلية من مجلدات
              المستأجرين على التخزين المحلي، وفريق تركيب وصيانة بدعم رؤية ذكية
              ومؤتمرات فيديو داخلية.
            </p>
            <div className="flex flex-wrap gap-2">
              <Link
                href="/auctions"
                className="rounded-2xl bg-amber-400 px-4 py-2 text-xs font-black text-slate-900 hover:bg-amber-300"
              >
                🔨 المزادات الذكية — سعر التكلفة
              </Link>
              <Link
                href="/support"
                className="rounded-2xl border border-teal-300/30 bg-teal-400/10 px-4 py-2 text-xs font-black text-teal-200 hover:bg-teal-400/20"
              >
                🩺 الدعم الفني المباشر + مؤتمرات
              </Link>
              <Link
                href="/dashboard"
                className="rounded-2xl border border-white/15 px-4 py-2 text-xs font-black text-slate-200 hover:bg-white/5"
              >
                🗂️ لوحات التحكم
              </Link>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-2">
            {strips.map((strip) => (
              <div
                key={strip.label}
                className="rounded-2xl border border-white/10 bg-black/25 p-3"
              >
                <p className="text-[10px] text-slate-400">
                  {strip.glyph} {strip.label}
                </p>
                <p className="text-xl font-black text-amber-200">
                  {new Intl.NumberFormat("ar-SA").format(strip.value)}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <TrailerRail trailers={trailers} />

      <HomeSearch categories={categories} />

      {/* CATALOG GRID */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-black text-white">🧾 كتالوج المعدات</h2>
          <span className="font-mono text-[9px] text-slate-500" dir="ltr">
            {SSD_LOGICAL_ROOT}/{TENANT_ROOTS.CATALOG}
          </span>
        </div>
        {items.length === 0 ? (
          <p className="najeeb-card rounded-2xl p-6 text-center text-sm text-slate-400">
            لا توجد عناصر مطابقة لبحثك.
          </p>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {items.map((row) => {
              const status = STATUS_LABELS[row.equipment.equipmentStatus];
              const availability =
                AVAILABILITY_LABELS[row.equipment.availabilityStatus];
              return (
                <Link
                  key={row.equipment.equipmentId}
                  href={`/item/${row.equipment.equipmentId}`}
                  className="najeeb-card group overflow-hidden rounded-3xl transition hover:border-amber-300/40"
                >
                  <div className="relative aspect-[4/3] overflow-hidden bg-black">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={row.equipment.posterImagePath ?? ""}
                      alt={row.equipment.titleAr}
                      className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                    <div className="absolute inset-x-2 top-2 flex justify-between">
                      <span className={`rounded-full border px-2 py-0.5 text-[9px] font-bold ${availability.tone}`}>
                        {availability.ar}
                      </span>
                      <span className={`rounded-full border px-2 py-0.5 text-[9px] font-bold ${status.tone}`}>
                        {status.ar}
                      </span>
                    </div>
                    {row.equipment.isLiveShowroom ? (
                      <span className="absolute bottom-2 left-2 flex items-center gap-1 rounded-full bg-rose-500/25 px-2 py-0.5 text-[9px] font-black text-rose-200">
                        <span className="live-dot h-1.5 w-1.5 rounded-full bg-rose-400" />
                        بث مباشر
                      </span>
                    ) : null}
                  </div>
                  <div className="space-y-1 p-3">
                    <p className="line-clamp-2 min-h-[34px] text-xs font-bold text-white">
                      {row.equipment.titleAr}
                    </p>
                    <p className="text-sm font-black text-amber-300">
                      {new Intl.NumberFormat("ar-SA", {
                        maximumFractionDigits: 0,
                      }).format(Number(row.equipment.price))}{" "}
                      ر.س
                    </p>
                    <p className="text-[10px] text-slate-400">
                      🏷️ {row.categoryNameAr ?? "عام"} · 🏪 {row.merchantNameAr ?? "النجيب"}
                    </p>
                  </div>
                </Link>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}
