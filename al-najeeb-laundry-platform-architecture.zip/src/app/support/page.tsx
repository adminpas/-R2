"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import { api } from "@/lib/client";
import { usePlatform } from "@/components/Providers";

type VisionReport = {
  confidence: number;
  detected: { labelAr: string; labelEn: string; part: string }[];
  recommendedActionAr: string;
  recommendedActionEn: string;
  routedTeam: string;
};

type RosterEntry = {
  participant: { participantId: number; userId: number; peerId: string | null };
  nameAr: string | null;
  roleType: string;
};

type Signal = {
  signalId: number;
  roomId: string;
  senderUserId: number;
  targetUserId: number | null;
  signalType: string;
  payload: Record<string, unknown>;
};

const ICE: RTCConfiguration = {
  iceServers: [{ urls: ["stun:stun.l.google.com:19302", "stun:stun1.l.google.com:19302"] }],
};

export default function SupportPage() {
  const searchParams = useSearchParams();
  const { session, t } = usePlatform();
  const roomFromUrl = searchParams.get("room");

  const [roomId, setRoomId] = useState<string | null>(roomFromUrl);
  const [summary, setSummary] = useState("");
  const [report, setReport] = useState<VisionReport | null>(null);
  const [roster, setRoster] = useState<RosterEntry[]>([]);
  const [cursor, setCursor] = useState(0);
  const [log, setLog] = useState<string[]>([]);
  const [camOn, setCamOn] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const peers = useRef<Map<number, RTCPeerConnection>>(new Map());
  const remoteRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const pushLog = useCallback((line: string) => {
    setLog((prev) => [`${new Date().toLocaleTimeString("ar-SA")} — ${line}`, ...prev].slice(0, 12));
  }, []);

  async function startCamera() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment", width: { ideal: 1280 } },
        audio: true,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play().catch(() => undefined);
      }
      setCamOn(true);
      pushLog("تم تشغيل كاميرا الجهاز للبث التشخيصي");
    } catch (err) {
      setError(
        `تعذر تشغيل الكاميرا: ${err instanceof Error ? err.message : "unknown"}`,
      );
    }
  }

  function stopCamera() {
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
    setCamOn(false);
  }

  /** Samples the live frame to feed the vision engine (luminance + motion). */
  function analyzeLocalFrame(): { luminance: number; motionScore: number } {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas || video.videoWidth === 0) {
      return { luminance: 0.5, motionScore: 0.35 };
    }
    canvas.width = 96;
    canvas.height = 96;
    const ctx = canvas.getContext("2d");
    if (!ctx) return { luminance: 0.5, motionScore: 0.35 };
    ctx.drawImage(video, 0, 0, 96, 96);
    const data = ctx.getImageData(0, 0, 96, 96).data;
    let sum = 0;
    for (let i = 0; i < data.length; i += 4) {
      sum += 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
    }
    const luminance = sum / (data.length / 4) / 255;
    return { luminance, motionScore: Math.min(0.9, 0.3 + luminance * 0.5) };
  }

  async function runTriage() {
    setBusy(true);
    setError(null);
    try {
      const metrics = camOn ? analyzeLocalFrame() : { luminance: 0.5, motionScore: 0.4 };
      const data = await api<{
        report: VisionReport;
        roomId: string;
        ticket?: { ticketCode: string };
      }>("/api/support/tickets", {
        method: "POST",
        json: {
          issueSummary: summary || "فحص دوري بالكاميرا بدون أعراض مكتوبة",
          luminance: metrics.luminance,
          motionScore: metrics.motionScore,
        },
      });
      setReport(data.report);
      setRoomId(data.roomId);
      pushLog(`تم التشخيص — الثقة ${(data.report.confidence * 100).toFixed(0)}%`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "تعذر التشخيص");
    } finally {
      setBusy(false);
    }
  }

  const ensurePeer = useCallback(
    async (remoteUserId: number, initiator: boolean) => {
      if (peers.current.has(remoteUserId)) return peers.current.get(remoteUserId)!;
      const pc = new RTCPeerConnection(ICE);
      peers.current.set(remoteUserId, pc);
      streamRef.current?.getTracks().forEach((track) => {
        pc.addTrack(track, streamRef.current as MediaStream);
      });
      pc.ontrack = (event) => {
        if (remoteRef.current && event.streams[0]) {
          remoteRef.current.srcObject = event.streams[0];
          void remoteRef.current.play().catch(() => undefined);
        }
      };
      pc.onicecandidate = (event) => {
        if (event.candidate && roomId) {
          void api(`/api/conferences/${roomId}`, {
            method: "POST",
            json: {
              kind: "ICE",
              targetUserId: remoteUserId,
              payload: event.candidate.toJSON(),
            },
          }).catch(() => undefined);
        }
      };
      if (initiator && roomId) {
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);
        await api(`/api/conferences/${roomId}`, {
          method: "POST",
          json: { kind: "OFFER", targetUserId: remoteUserId, payload: { sdp: offer.sdp, type: offer.type } },
        });
        pushLog(`إرسال عرض اتصال (offer) إلى العضو #${remoteUserId}`);
      }
      return pc;
    },
    [roomId, pushLog],
  );

  // Join + polling loop
  const me = session?.authenticated ? session.userId : null;

  useEffect(() => {
    if (!roomId || me === null) return;
    const session = { userId: me };
    let stop = false;
    let timer: ReturnType<typeof setTimeout>;

    async function join() {
      await api(`/api/conferences/${roomId}`, { method: "POST", json: { kind: "JOIN" } });
      pushLog("تم الانضمام لغرفة المؤتمر");
    }

    async function poll() {
      if (stop) return;
      try {
        const data = await api<{
          roster: RosterEntry[];
          signals: Signal[];
          cursor: number;
        }>(`/api/conferences/${roomId}?since=${cursor}`);
        setRoster(data.roster);
        for (const signal of data.signals) {
          if (signal.senderUserId === session.userId) continue;
          if (
            signal.targetUserId &&
            signal.targetUserId !== session.userId
          ) {
            continue;
          }
          if (signal.signalType === "OFFER") {
            const pc = await ensurePeer(signal.senderUserId, false);
            await pc.setRemoteDescription(
              new RTCSessionDescription(
                signal.payload as unknown as RTCSessionDescriptionInit,
              ),
            );
            const answer = await pc.createAnswer();
            await pc.setLocalDescription(answer);
            await api(`/api/conferences/${roomId}`, {
              method: "POST",
              json: {
                kind: "ANSWER",
                targetUserId: signal.senderUserId,
                payload: { sdp: answer.sdp, type: answer.type },
              },
            });
            pushLog(`تمت إجابة العضو #${signal.senderUserId}`);
          } else if (signal.signalType === "ANSWER") {
            const pc = peers.current.get(signal.senderUserId);
            if (pc) {
              await pc.setRemoteDescription(
                new RTCSessionDescription(
                  signal.payload as unknown as RTCSessionDescriptionInit,
                ),
              );
            }
          } else if (signal.signalType === "ICE") {
            const pc = peers.current.get(signal.senderUserId);
            if (pc) {
              await pc.addIceCandidate(
                new RTCIceCandidate(signal.payload as RTCIceCandidateInit),
              ).catch(() => undefined);
            }
          }
        }
        setCursor(data.cursor);
        // mesh: initiate towards participants with a lower id
        for (const entry of data.roster) {
          if (entry.participant.userId < session.userId && camOn) {
            void ensurePeer(entry.participant.userId, true);
          }
        }
      } catch {
        /* keep polling */
      }
      timer = setTimeout(poll, 2200);
    }

    void join();
    void poll();
    return () => {
      stop = true;
      clearTimeout(timer);
      peers.current.forEach((pc) => pc.close());
      peers.current.clear();
    };
    }, [roomId, me, cursor, ensurePeer, pushLog, camOn]);

  useEffect(() => () => stopCamera(), []);

  return (
    <div className="mx-auto max-w-[1400px] space-y-4">
      <section className="najeeb-card najeeb-glow space-y-2 rounded-3xl p-5">
        <h1 className="text-lg font-black text-white lg:text-xl">
          🩺 {t("aiVision")} + {t("openRoom")}
        </h1>
        <p className="text-[11px] leading-relaxed text-slate-400">
          شغّل كاميرا الجهاز لتشخيص أعطال المغاسل بالرؤية الذكية، ثم انضم لغرفة
          مؤتمر فيديو داخلية (WebRTC) مع فريق التركيب والصيانة أو التاجر أو
          العميل — الكاميرا والصوت يعملان داخل المنصة دون تطبيقات خارجية.
        </p>
      </section>

      <div className="grid gap-4 lg:grid-cols-[1.1fr_1fr]">
        <section className="najeeb-card space-y-3 rounded-3xl p-4">
          <div className="relative aspect-video overflow-hidden rounded-2xl bg-black">
            <video
              ref={videoRef}
              muted
              playsInline
              className="h-full w-full object-cover"
            />
            {!camOn ? (
              <div className="absolute inset-0 grid place-items-center text-[11px] text-slate-500">
                الكاميرا متوقفة
              </div>
            ) : (
              <span className="absolute right-3 top-3 flex items-center gap-1 rounded-full border border-rose-400/40 bg-rose-500/25 px-2 py-0.5 text-[9px] font-black text-rose-100">
                <span className="live-dot h-1.5 w-1.5 rounded-full bg-rose-400" />
                بث تشخيصي مباشر
              </span>
            )}
          </div>
          <canvas ref={canvasRef} className="hidden" />
          <div className="flex flex-wrap gap-2">
            {!camOn ? (
              <button
                onClick={() => void startCamera()}
                className="rounded-2xl bg-teal-400 px-4 py-2 text-xs font-black text-slate-900"
              >
                📷 تشغيل الكاميرا
              </button>
            ) : (
              <button
                onClick={stopCamera}
                className="rounded-2xl border border-rose-300/30 px-4 py-2 text-xs font-black text-rose-200"
              >
                إيقاف الكاميرا
              </button>
            )}
          </div>
          <textarea
            value={summary}
            onChange={(event) => setSummary(event.target.value)}
            rows={3}
            placeholder="وصف العطل: صوت، اهتزاز، تسريب، كود خطأ…"
            className="w-full rounded-2xl border border-white/10 bg-slate-950/60 p-3 text-xs text-slate-100 outline-none focus:border-amber-300/50"
          />
          <button
            onClick={() => void runTriage()}
            disabled={busy || !session?.authenticated}
            className="w-full rounded-2xl bg-gradient-to-r from-amber-300 to-amber-500 px-4 py-2.5 text-xs font-black text-slate-900 disabled:opacity-40"
          >
            🔍 تشغيل التشخيص الذكي
          </button>
          {!session?.authenticated ? (
            <p className="text-[10px] text-amber-200">
              سجّل الدخول لفتح تذكرة صيانة وغرفة مؤتمر حقيقية.
            </p>
          ) : null}

          {report ? (
            <div className="space-y-2 rounded-2xl border border-teal-300/25 bg-teal-400/10 p-3 text-[11px] text-teal-100">
              <p className="font-black">
                ثقة التشخيص: {(report.confidence * 100).toFixed(0)}% · الفريق:{" "}
                {report.routedTeam}
              </p>
              <div className="flex flex-wrap gap-1.5">
                {report.detected.map((item) => (
                  <span
                    key={item.part}
                    className="rounded-lg border border-white/15 bg-black/30 px-2 py-0.5 text-[10px]"
                  >
                    {item.labelAr} · {item.part}
                  </span>
                ))}
              </div>
              <p>الإجراء المقترح: {report.recommendedActionAr}</p>
            </div>
          ) : null}
        </section>

        <section className="najeeb-card space-y-3 rounded-3xl p-4">
          <h2 className="text-sm font-black text-white">🎥 غرفة المؤتمر</h2>
          {roomId ? (
            <p className="rounded-2xl border border-white/10 bg-black/30 p-2 font-mono text-[10px] text-teal-300" dir="ltr">
              room: {roomId}
            </p>
          ) : (
            <p className="text-[11px] text-slate-400">
              لم تُفتح غرفة بعد — شغّل التشخيص أو أنشئ غرفة من لوحة الصيانة.
            </p>
          )}

          <div className="grid gap-2 sm:grid-cols-2">
            <div className="overflow-hidden rounded-2xl border border-white/10 bg-black">
              <p className="p-1.5 text-[9px] text-slate-400">كاميرتي</p>
              <video ref={videoRef} muted playsInline className="hidden" />
              <div className="aspect-video">
                {camOn ? (
                  <span className="grid h-full place-items-center text-[10px] text-emerald-300">
                    ● يتم البث للغرفة
                  </span>
                ) : (
                  <span className="grid h-full place-items-center text-[10px] text-slate-500">
                    غير متصل
                  </span>
                )}
              </div>
            </div>
            <div className="overflow-hidden rounded-2xl border border-white/10 bg-black">
              <p className="p-1.5 text-[9px] text-slate-400">الطرف الآخر</p>
              <div className="aspect-video">
                <video ref={remoteRef} playsInline className="h-full w-full object-cover" />
              </div>
            </div>
          </div>

          <div>
            <p className="mb-1 text-[10px] text-slate-400">الأعضاء المتصلون</p>
            <div className="flex flex-wrap gap-1.5">
              {roster.map((entry) => (
                <span
                  key={entry.participant.participantId}
                  className="rounded-lg border border-white/10 bg-black/30 px-2 py-0.5 text-[10px] text-slate-200"
                >
                  {entry.nameAr ?? `#${entry.participant.userId}`} · {entry.roleType}
                </span>
              ))}
              {roster.length === 0 ? (
                <span className="text-[10px] text-slate-500">لا أعضاء</span>
              ) : null}
            </div>
          </div>

          <div className="space-y-1 rounded-2xl border border-white/10 bg-black/30 p-2.5">
            <p className="text-[10px] text-slate-400">سجل الجلسة</p>
            {log.map((line, index) => (
              <p key={index} className="text-[10px] text-slate-300">
                {line}
              </p>
            ))}
            {log.length === 0 ? (
              <p className="text-[10px] text-slate-500">—</p>
            ) : null}
          </div>
        </section>
      </div>

      {error ? (
        <p className="rounded-2xl border border-rose-300/30 bg-rose-400/10 p-2.5 text-[11px] text-rose-100">
          {error}
        </p>
      ) : null}
    </div>
  );
}
