"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { api, timeRemaining } from "@/lib/client";
import { usePlatform } from "./Providers";

export type AuctionView = {
  auction: {
    auctionId: number;
    packageTitle: string;
    baseCostPrice: string;
    currentHighestBid: string;
    minimumIncrement: string;
    startDate: string;
    endDate: string;
    isProcessed: boolean;
    packageDetails: { items?: string[]; localeNoteAr?: string } | null;
  };
  bidderName: string | null;
  bidCount: number;
};

function Countdown({ endDate }: { endDate: string }) {
  const { t } = usePlatform();
  const [left, setLeft] = useState(() => timeRemaining(endDate));
  useEffect(() => {
    const timer = setInterval(() => setLeft(timeRemaining(endDate)), 1000);
    return () => clearInterval(timer);
  }, [endDate]);

  if (left.expired) {
    return (
      <span className="rounded-lg border border-rose-300/30 bg-rose-500/15 px-2 py-1 text-[10px] font-black text-rose-200">
        انتهى المؤقت — تمت المعالجة التلقائية
      </span>
    );
  }
  return (
    <span className="font-mono text-[11px] text-amber-200">
      {t("timeLeft")}: {left.days}
      {t("days")} {String(left.hours).padStart(2, "0")}
      {t("hours")} {String(left.minutes).padStart(2, "0")}
      {t("minutes")} {String(left.seconds).padStart(2, "0")}ث
    </span>
  );
}

export function AuctionRoom({ auctions }: { auctions: AuctionView[] }) {
  const { sar, session, t } = usePlatform();
  const [rows, setRows] = useState(auctions);
  const [amounts, setAmounts] = useState<Record<number, string>>({});
  const [busy, setBusy] = useState(false);
  const [feedback, setFeedback] = useState<{ id: number; text: string; good: boolean } | null>(null);

  async function refresh() {
    try {
      const data = await api<{ auctions: AuctionView[] }>("/api/auctions");
      setRows(data.auctions);
    } catch {
      /* silent */
    }
  }

  async function bid(auctionId: number) {
    setBusy(true);
    setFeedback(null);
    try {
      const raw = amounts[auctionId] ?? "";
      const value = Number(raw.replace(/[^\d.]/g, ""));
      const result = await api<{
        accepted: boolean;
        reasonAr?: string;
        reasonEn?: string;
        required?: number;
      }>(`/api/auctions/${auctionId}`, { method: "POST", json: { amount: value } });
      if (result.accepted) {
        setFeedback({ id: auctionId, text: "تم تسجيل مزايدتك بنجاح ✅", good: true });
        await refresh();
      } else {
        setFeedback({
          id: auctionId,
          text: `${result.reasonAr ?? "مزايدة غير مقبولة"}${
            result.required ? ` — الحد الأدنى ${sar(result.required)}` : ""
          }`,
          good: false,
        });
      }
    } catch (err) {
      setFeedback({
        id: auctionId,
        text: err instanceof Error ? err.message : "تعذر إرسال المزايدة",
        good: false,
      });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="grid gap-3 lg:grid-cols-2">
      {rows.map((row) => {
        const nextMinimum =
          Number(row.auction.currentHighestBid) + Number(row.auction.minimumIncrement);
        const closed = row.auction.isProcessed;
        return (
          <article key={row.auction.auctionId} className="najeeb-card space-y-3 rounded-3xl p-4">
            <div className="flex items-start justify-between gap-2">
              <h2 className="text-sm font-black leading-snug text-white">
                {row.auction.packageTitle}
              </h2>
              <span className="shrink-0 rounded-lg border border-white/10 px-2 py-1 text-[9px] text-slate-400">
                #{row.auction.auctionId}
              </span>
            </div>

            {row.auction.packageDetails?.items?.length ? (
              <ul className="flex flex-wrap gap-1.5">
                {row.auction.packageDetails.items.map((item) => (
                  <li
                    key={item}
                    className="rounded-lg border border-white/10 bg-black/25 px-2 py-0.5 text-[10px] text-slate-300"
                  >
                    {item}
                  </li>
                ))}
              </ul>
            ) : null}

            <div className="grid grid-cols-3 gap-2 text-[11px]">
              <div className="rounded-2xl border border-white/10 bg-black/25 p-2">
                <p className="text-[9px] text-slate-400">{t("auctionBase")}</p>
                <p className="font-black text-slate-100">{sar(row.auction.baseCostPrice)}</p>
              </div>
              <div className="rounded-2xl border border-emerald-300/25 bg-emerald-400/10 p-2">
                <p className="text-[9px] text-emerald-200/80">{t("auctionHighest")}</p>
                <p className="font-black text-emerald-200">
                  {sar(row.auction.currentHighestBid)}
                </p>
              </div>
              <div className="rounded-2xl border border-white/10 bg-black/25 p-2">
                <p className="text-[9px] text-slate-400">{t("auctionIncrement")}</p>
                <p className="font-black text-amber-200">{sar(row.auction.minimumIncrement)}</p>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2">
              <Countdown endDate={row.auction.endDate} />
              <span className="text-[10px] text-slate-400">
                {t("bids")}: {row.bidCount} ·{" "}
                {row.bidderName ? `أعلى مزايد: ${row.bidderName}` : "لا مزايدات بعد"}
              </span>
            </div>

            {closed ? (
              <p className="rounded-2xl border border-white/10 bg-black/25 p-2 text-center text-[11px] text-slate-300">
                🔒 تمت معالجة الباقة تلقائياً وتحويل قيمة المزايدة إلى محفظة الضمان.
              </p>
            ) : session?.authenticated ? (
              <div className="space-y-2">
                <div className="flex gap-2">
                  <input
                    value={amounts[row.auction.auctionId] ?? ""}
                    onChange={(event) =>
                      setAmounts((prev) => ({
                        ...prev,
                        [row.auction.auctionId]: event.target.value,
                      }))
                    }
                    placeholder={`الحد الأدنى ${nextMinimum}`}
                    inputMode="numeric"
                    className="flex-1 rounded-2xl border border-white/10 bg-slate-950/60 px-3 py-2 text-xs text-slate-100 outline-none focus:border-amber-300/50"
                  />
                  <button
                    onClick={() => void bid(row.auction.auctionId)}
                    disabled={busy}
                    className="rounded-2xl bg-amber-400 px-4 py-2 text-xs font-black text-slate-900 disabled:opacity-50"
                  >
                    {t("placeBid")}
                  </button>
                </div>
                {feedback?.id === row.auction.auctionId ? (
                  <p
                    className={`rounded-xl p-2 text-[11px] ${
                      feedback.good
                        ? "border border-emerald-300/30 bg-emerald-400/10 text-emerald-100"
                        : "border border-rose-300/30 bg-rose-400/10 text-rose-100"
                    }`}
                  >
                    {feedback.text}
                  </p>
                ) : null}
              </div>
            ) : (
              <Link
                href="/login"
                className="block rounded-2xl border border-amber-300/30 bg-amber-400/10 p-2 text-center text-[11px] font-black text-amber-200"
              >
                سجّل الدخول للمزايدة على هذه الباقة
              </Link>
            )}
          </article>
        );
      })}
    </div>
  );
}
