"use client";

import Link from "next/link";
import { useState } from "react";

type CategoryRow = {
  category: {
    categoryId: number;
    categoryNameAr: string;
    iconGlyph: string | null;
    ssdFolderPath: string;
  };
  itemCount: number;
};

export function HomeSearch({ categories }: { categories: CategoryRow[] }) {
  const [query, setQuery] = useState("");
  const [active, setActive] = useState<number | null>(null);

  const href = () => {
    const params = new URLSearchParams();
    if (query.trim()) params.set("q", query.trim());
    if (active) params.set("categoryId", String(active));
    const qs = params.toString();
    return qs ? `/?${qs}` : "/";
  };

  return (
    <section className="najeeb-card space-y-3 rounded-3xl p-4">
      <form
        onSubmit={(event) => {
          event.preventDefault();
          window.location.href = href();
        }}
        className="flex flex-wrap gap-2"
      >
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="ابحث عن مغسلة، مجفف، مكبس، قطعة غيار…"
          className="min-w-[220px] flex-1 rounded-2xl border border-white/10 bg-slate-950/60 px-4 py-2.5 text-sm text-slate-100 outline-none focus:border-amber-300/50"
        />
        <button
          type="submit"
          className="rounded-2xl bg-amber-400 px-5 py-2.5 text-xs font-black text-slate-900 hover:bg-amber-300"
        >
          🔍 بحث
        </button>
        <Link
          href="/"
          className="rounded-2xl border border-white/15 px-4 py-2.5 text-xs font-bold text-slate-300 hover:bg-white/5"
        >
          تصفير
        </Link>
      </form>
      <div className="flex gap-2 overflow-x-auto pb-1">
        <button
          onClick={() => setActive(null)}
          className={`shrink-0 rounded-2xl border px-3 py-1.5 text-[11px] font-bold ${
            active === null
              ? "border-amber-300/50 bg-amber-400/15 text-amber-200"
              : "border-white/10 text-slate-300 hover:bg-white/5"
          }`}
        >
          🗂️ الكل
        </button>
        {categories.map((row) => (
          <button
            key={row.category.categoryId}
            onClick={() => setActive(row.category.categoryId)}
            className={`shrink-0 rounded-2xl border px-3 py-1.5 text-[11px] font-bold ${
              active === row.category.categoryId
                ? "border-amber-300/50 bg-amber-400/15 text-amber-200"
                : "border-white/10 text-slate-300 hover:bg-white/5"
            }`}
            title={row.category.ssdFolderPath}
          >
            {row.category.iconGlyph} {row.category.categoryNameAr} (
            {row.itemCount})
          </button>
        ))}
      </div>
    </section>
  );
}
