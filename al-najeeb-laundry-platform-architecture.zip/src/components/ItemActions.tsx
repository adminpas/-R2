"use client";

import { useState } from "react";
import Link from "next/link";
import { usePlatform } from "./Providers";
import { api } from "@/lib/client";

export function LiveShowroomPlayer(props: {
  equipmentId: number;
  titleAr: string;
  trailerUrl: string | null;
  trailerPath: string | null;
  poster: string | null;
  live: boolean;
}) {
  const streamSrc =
    props.trailerUrl ??
    (props.trailerPath
      ? `/api/media/stream?path=${encodeURIComponent(props.trailerPath)}`
      : null);
  return (
    <div className="najeeb-card najeeb-glow overflow-hidden rounded-3xl">
      <div className="relative aspect-video w-full bg-black">
        {streamSrc ? (
          <video
            controls
            playsInline
            poster={props.poster ?? undefined}
            className="h-full w-full object-cover"
            src={streamSrc}
          />
        ) : (
          <div className="grid h-full place-items-center text-xs text-slate-500">
            لا يوجد بث متاح لهذه المعدة حالياً
          </div>
        )}
        {props.live ? (
          <span className="absolute right-3 top-3 flex items-center gap-1 rounded-full border border-rose-400/40 bg-rose-500/25 px-2.5 py-1 text-[10px] font-black text-rose-100">
            <span className="live-dot h-1.5 w-1.5 rounded-full bg-rose-400" />
            بث مباشر من المعرض — جدة / الخمرة
          </span>
        ) : null}
      </div>
    </div>
  );
}

type HoldResult = {
  reservationId: number;
  escrowCode: string;
  holdExpiresAt: string;
  downpaymentAmount: number;
};

export function ItemActions(props: {
  equipmentId: number;
  price: number;
  downpayment: number;
  availability: string;
}) {
  const { t, sar, session, refreshSession } = usePlatform();
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [hold, setHold] = useState<HoldResult | null>(null);
  const [order, setOrder] = useState<{ orderCode: string } | null>(null);
  const [score, setScore] = useState(5);
  const [comment, setComment] = useState("");

  async function reserve() {
    setBusy(true);
    setError(null);
    setMessage(null);
    try {
      if (!session?.authenticated) {
        setError("يجب تسجيل الدخول لتفعيل الحجز ٢٤ ساعة.");
        return;
      }
      const result = await api<HoldResult>("/api/reservations", {
        method: "POST",
        json: {
          equipmentId: props.equipmentId,
          amountPaid: props.downpayment,
          paymentMethod: "MADA_LOCAL_GATEWAY",
        },
      });
      setHold(result);
      setMessage(
        `تم تفعيل الحجز ٢٤ ساعة وخصم الدفعة المقدمة إلى محفظة الضمان ${result.escrowCode}`,
      );
      await refreshSession();
    } catch (err) {
      setError(err instanceof Error ? err.message : "تعذر تنفيذ الحجز");
    } finally {
      setBusy(false);
    }
  }

  async function checkout(installation: boolean) {
    if (!hold) return;
    setBusy(true);
    try {
      const result = await api<{ order: { orderCode: string } }>(
        `/api/reservations/${hold.reservationId}`,
        { method: "PATCH", json: { action: "CONVERT", installationRequested: installation } },
      );
      setOrder(result.order);
      setMessage(`تم إنشاء الطلب ${result.order.orderCode} وتحويل الضمان للتاجر.`);
      await refreshSession();
    } catch (err) {
      setError(err instanceof Error ? err.message : "تعذر إتمام الشراء");
    } finally {
      setBusy(false);
    }
  }

  async function releaseHold() {
    if (!hold) return;
    setBusy(true);
    try {
      await api(`/api/reservations/${hold.reservationId}`, {
        method: "PATCH",
        json: { action: "RELEASE" },
      });
      setHold(null);
      setMessage("تم فك الحجز وإرجاع الدفعة المقدمة من الضمان.");
      await refreshSession();
    } catch (err) {
      setError(err instanceof Error ? err.message : "تعذر فك الحجز");
    } finally {
      setBusy(false);
    }
  }

  async function submitRating() {
    setBusy(true);
    try {
      await api("/api/feedback", {
        method: "POST",
        json: {
          targetType: "EQUIPMENT",
          targetId: props.equipmentId,
          score,
          comment,
          locale: "ar",
        },
      });
      setComment("");
      setMessage("شكراً لتقييمك — تمت إضافته إلى بنك الملاحظات.");
    } catch (err) {
      setError(err instanceof Error ? err.message : "تعذر إرسال التقييم");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="najeeb-card space-y-3 rounded-3xl p-4">
      <h2 className="text-sm font-black text-white">⚡ الحجز الفوري ٢٤ ساعة</h2>
      {!session?.authenticated ? (
        <p className="rounded-2xl border border-amber-300/30 bg-amber-400/10 p-3 text-[11px] text-amber-100">
          سجّل الدخول لتفعيل الحجز الفوري.{" "}
          <Link href="/login" className="font-black underline">
            تسجيل الدخول
          </Link>
        </p>
      ) : null}

      {order ? (
        <div className="rounded-2xl border border-emerald-300/30 bg-emerald-400/10 p-3 text-[11px] text-emerald-100">
          ✅ تم إتمام الطلب <span className="font-black">{order.orderCode}</span> —
          سيتم إسناده لشركة التوصيل ولمهام التركيب والصيانة.
          <Link href="/dashboard" className="ms-2 underline">
            متابعة من لوحة التحكم
          </Link>
        </div>
      ) : null}

      {hold && !order ? (
        <div className="space-y-2 rounded-2xl border border-teal-300/30 bg-teal-400/10 p-3 text-[11px] text-teal-100">
          <p>
            ⏳ الحجز ساري حتى:{" "}
            <span className="font-black">
              {new Date(hold.holdExpiresAt).toLocaleString("ar-SA")}
            </span>
          </p>
          <p>
            💠 الدفعة المحفوظة بالضمان:{" "}
            <span className="font-black">{sar(hold.downpaymentAmount)}</span>
          </p>
          <div className="flex flex-wrap gap-2 pt-1">
            <button
              onClick={() => void checkout(true)}
              disabled={busy}
              className="rounded-xl bg-amber-400 px-3 py-1.5 text-[11px] font-black text-slate-900 disabled:opacity-50"
            >
              إتمام الشراء + طلب تركيب
            </button>
            <button
              onClick={() => void checkout(false)}
              disabled={busy}
              className="rounded-xl border border-white/20 px-3 py-1.5 text-[11px] font-bold text-slate-100 disabled:opacity-50"
            >
              إتمام الشراء فقط
            </button>
            <button
              onClick={() => void releaseHold()}
              disabled={busy}
              className="rounded-xl border border-rose-300/30 px-3 py-1.5 text-[11px] font-bold text-rose-200 disabled:opacity-50"
            >
              فك الحجز واسترداد الدفعة
            </button>
          </div>
        </div>
      ) : null}

      {!hold && !order ? (
        <button
          onClick={() => void reserve()}
          disabled={busy || props.availability !== "AVAILABLE"}
          className="w-full rounded-2xl bg-gradient-to-r from-amber-300 to-amber-500 px-4 py-3 text-xs font-black text-slate-900 disabled:opacity-50"
        >
          {props.availability === "AVAILABLE"
            ? `💠 ${t("reserve")} — دفع ${sar(props.downpayment)} الآن`
            : props.availability === "HOLD_24H"
              ? "المعدة محجوزة حالياً لعميل آخر"
              : "تم بيع هذه المعدة"}
        </button>
      ) : null}

      <div className="space-y-2 rounded-2xl border border-white/10 bg-black/25 p-3">
        <p className="text-[11px] font-bold text-slate-200">⭐ {t("rate")}</p>
        <div className="flex gap-1">
          {[1, 2, 3, 4, 5].map((value) => (
            <button
              key={value}
              onClick={() => setScore(value)}
              className={`text-lg ${value <= score ? "text-amber-300" : "text-slate-600"}`}
              aria-label={`rating ${value}`}
            >
              ★
            </button>
          ))}
        </div>
        <textarea
          value={comment}
          onChange={(event) => setComment(event.target.value)}
          rows={2}
          placeholder="اكتب ملاحظتك…"
          className="w-full rounded-xl border border-white/10 bg-slate-950/60 p-2 text-[11px] text-slate-100 outline-none focus:border-amber-300/50"
        />
        <button
          onClick={() => void submitRating()}
          disabled={busy}
          className="rounded-xl border border-amber-300/40 bg-amber-400/10 px-3 py-1.5 text-[11px] font-black text-amber-200 disabled:opacity-50"
        >
          {t("send")}
        </button>
      </div>

      {message ? (
        <p className="rounded-2xl border border-emerald-300/30 bg-emerald-400/10 p-2.5 text-[11px] text-emerald-100">
          {message}
        </p>
      ) : null}
      {error ? (
        <p className="rounded-2xl border border-rose-300/30 bg-rose-400/10 p-2.5 text-[11px] text-rose-100">
          {error}
        </p>
      ) : null}
    </div>
  );
}
