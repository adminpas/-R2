"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { api, hardwareProbe } from "@/lib/client";

export type Locale = "ar" | "en" | "ur" | "fr";
export type SessionInfo =
  | { authenticated: false }
  | {
      authenticated: true;
      userId: number;
      username: string;
      roleType: string;
      displayNameAr: string | null;
      city: string | null;
      hardwareDeviceId: string | null;
      biometricVerified: boolean;
      merchantSsdFolder: string | null;
    };

const LABELS: Record<string, Record<Locale, string>> = {
  brandShort: { ar: "النجيب المتطورة", en: "Al-Najeeb Advanced", ur: "النجيب", fr: "Al-Najeeb" },
  showroom: { ar: "المعرض", en: "Showroom", ur: "پرگالری", fr: "Showroom" },
  auctions: { ar: "المزادات الذكية", en: "Smart auctions", ur: "نیلامی", fr: "Enchères" },
  support: { ar: "الدعم الفني المباشر", en: "Live tech support", ur: "ٹیک سپورٹ", fr: "Support technique" },
  panels: { ar: "لوحات التحكم", en: "Control panels", ur: "پینل", fr: "Panneaux" },
  login: { ar: "تسجيل الدخول", en: "Sign in", ur: "لاگ ان", fr: "Connexion" },
  join: { ar: "حساب جديد", en: "Create account", ur: "نیا اکاؤنٹ", fr: "Créer un compte" },
  logout: { ar: "خروج", en: "Sign out", ur: "لاگ آؤٹ", fr: "Déconnexion" },
  newArrivals: { ar: "وصل حديثاً — إعلانات ترويجية 4K", en: "New arrivals — 4K promo trailers", ur: "نئے آنے والے", fr: "Nouveautés" },
  categories: { ar: "الأقسام", en: "Categories", ur: "اقسام", fr: "Catégories" },
  all: { ar: "الكل", en: "All", ur: "سب", fr: "Tout" },
  search: { ar: "ابحث عن مغسلة، مجفف، قطعة غيار…", en: "Search washers, dryers, spare parts…", ur: "تلاش کریں…", fr: "Rechercher…" },
  live: { ar: "بث مباشر", en: "LIVE", ur: "لائیو", fr: "DIRECT" },
  reserve: { ar: "حجز 24 ساعة", en: "Reserve 24h", ur: "24 گھنٹے بکنگ", fr: "Réserver 24h" },
  downpayment: { ar: "الدفعة المقدمة ٢٥٪", en: "25% downpayment", ur: "25% ایڈوانس", fr: "Acompte 25%" },
  checkout: { ar: "إتمام الشراء", en: "Checkout", ur: "خرید مکمل", fr: "Paiement" },
  sar: { ar: "ر.س", en: "SAR", ur: "ریال", fr: "SAR" },
  storage: { ar: "تخزين SSD محلي", en: "Local SSD storage", ur: "مقامی SSD", fr: "Stockage SSD local" },
  node: { ar: "جدة — الخمرة", en: "Jeddah — Al-Khumra", ur: "جدہ — الخمرہ", fr: "Djeddah" },
  rate: { ar: "قيّم تجربتك", en: "Rate your experience", ur: "درجہ دیں", fr: "Évaluez" },
  send: { ar: "إرسال", en: "Send", ur: "بھیجیں", fr: "Envoyer" },
  mfa: { ar: "توثيق البصمة", en: "Biometric handshake", ur: "بائیو میٹرک", fr: "Biométrie" },
  deviceLocked: {
    ar: "مقفل على جهاز واحد",
    en: "Locked to one device",
    ur: "ایک ڈیوائس پر مقفل",
    fr: "Verrouillé à un appareil",
  },
  escrow: { ar: "الضمان", en: "Escrow", ur: "ضمامتی", fr: "Séquestre" },
  commission: { ar: "العمولة", en: "Commission", ur: "کمیشن", fr: "Commission" },
  bids: { ar: "المزايدات", en: "Bids", ur: "بولیاں", fr: "Enchères" },
  placeBid: { ar: "زايد الآن", en: "Place bid", ur: "بولی لگائیں", fr: "Enchérir" },
  timeLeft: { ar: "الوقت المتبقي", en: "Time left", ur: "باقی وقت", fr: "Temps restant" },
  aiVision: { ar: "تشخيص بالكاميرا", en: "Camera vision diagnostics", ur: "کیمرہ تشخیص", fr: "Diagnostic caméra" },
  openRoom: { ar: "غرفة مؤتمر مباشرة", en: "Live conference room", ur: "کانفرنس روم", fr: "Salle de conférence" },
  tickets: { ar: "طلبات الصيانة", en: "Maintenance tickets", ur: "مرمت ٹکٹ", fr: "Tickets" },
  shipping: { ar: "مهام التوصيل", en: "Delivery jobs", ur: "ڈیلیوری", fr: "Livraisons" },
  items: { ar: "المعدات", en: "Equipment", ur: "مشینیں", fr: "Équipements" },
  users: { ar: "الحسابات", en: "Accounts", ur: "اکاؤنٹس", fr: "Comptes" },
  approve: { ar: "اعتماد", en: "Approve", ur: "منظور", fr: "Approuver" },
  suspend: { ar: "إيقاف", en: "Suspend", ur: "معطل", fr: "Suspendre" },
  release: { ar: "فك قفل الجهاز", en: "Release device lock", ur: "لاک کھولیں", fr: "Déverrouiller" },
  addItem: { ar: "إضافة معدة", en: "Add equipment", ur: "مشین شامل", fr: "Ajouter" },
  upload: { ar: "رفع إلى SSD", en: "Upload to SSD", ur: "SSD پر اپلوڈ", fr: "Téléverser" },
};

type Ctx = {
  locale: Locale;
  dir: "rtl" | "ltr";
  setLocale: (locale: Locale) => void;
  t: (key: keyof typeof LABELS | string) => string;
  sar: (value: string | number) => string;
  session: SessionInfo | null;
  loadingSession: boolean;
  refreshSession: () => Promise<void>;
  deviceId: string | null;
  mfaVerified: boolean;
  runBiometric: () => Promise<boolean>;
};

const PlatformContext = createContext<Ctx | null>(null);

export function usePlatform(): Ctx {
  const ctx = useContext(PlatformContext);
  if (!ctx) throw new Error("usePlatform must be used inside PlatformProvider");
  return ctx;
}

export function PlatformProvider({ children }: { children: ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>("ar");
  const [session, setSession] = useState<SessionInfo | null>(null);
  const [loadingSession, setLoadingSession] = useState(true);
  const [deviceId, setDeviceId] = useState<string | null>(null);
  const [mfaVerified, setMfaVerified] = useState(false);

  useEffect(() => {
    const stored = (localStorage.getItem("najeeb_locale") as Locale | null) ?? "ar";
    setLocaleState(stored);
    document.documentElement.lang = stored;
    document.documentElement.dir =
      stored === "en" || stored === "fr" ? "ltr" : "rtl";
  }, []);

  const refreshSession = useCallback(async () => {
    try {
      const probe = await hardwareProbe();
      localStorage.setItem("najeeb_hw", probe.slice(0, 128));
      const info = await api<SessionInfo>("/api/auth/session");
      setSession(info);
      setMfaVerified(info.authenticated && info.biometricVerified);
    } catch {
      setSession({ authenticated: false });
    } finally {
      setLoadingSession(false);
    }
  }, []);

  useEffect(() => {
    void refreshSession();
    void api<{ fingerprint: string | null }>("/api/auth/device", {
      method: "POST",
      json: { hwProbe: localStorage.getItem("najeeb_hw") ?? "" },
    })
      .then((data) => setDeviceId(data.fingerprint))
      .catch(() => setDeviceId(null));
  }, [refreshSession]);

  const setLocale = useCallback((next: Locale) => {
    setLocaleState(next);
    localStorage.setItem("najeeb_locale", next);
    document.documentElement.lang = next;
    document.documentElement.dir = next === "en" || next === "fr" ? "ltr" : "rtl";
    document.cookie = `najeeb_locale=${next}; path=/; max-age=31536000`;
  }, []);

  const t = useCallback(
    (key: keyof typeof LABELS | string) => {
      const entry = LABELS[key];
      if (!entry) return String(key);
      return entry[locale] ?? entry.ar;
    },
    [locale],
  );

  const sar = useCallback(
    (value: string | number) => {
      const n = typeof value === "string" ? Number(value) : value;
      const formatted = new Intl.NumberFormat(
        locale === "ar" ? "ar-SA" : "en-US",
        { maximumFractionDigits: 0 },
      ).format(Number.isFinite(n) ? n : 0);
      return locale === "ar" ? `${formatted} ر.س` : `SAR ${formatted}`;
    },
    [locale],
  );

  const runBiometric = useCallback(async () => {
    const { biometricAttestation } = await import("@/lib/client");
    const challenge = await api<{ challenge: string }>("/api/auth/biometric");
    const attestation = await biometricAttestation(challenge.challenge);
    await api("/api/auth/biometric", {
      method: "POST",
      json: { attestation },
    });
    setMfaVerified(true);
    await refreshSession();
    return true;
  }, [refreshSession]);

  const value = useMemo<Ctx>(
    () => ({
      locale,
      dir: locale === "en" || locale === "fr" ? "ltr" : "rtl",
      setLocale,
      t,
      sar,
      session,
      loadingSession,
      refreshSession,
      deviceId,
      mfaVerified,
      runBiometric,
    }),
    [locale, setLocale, t, sar, session, loadingSession, refreshSession, deviceId, mfaVerified, runBiometric],
  );

  return (
    <PlatformContext.Provider value={value}>{children}</PlatformContext.Provider>
  );
}

export const LOCALE_OPTIONS: { code: Locale; label: string }[] = [
  { code: "ar", label: "العربية" },
  { code: "en", label: "English" },
  { code: "ur", label: "اردو" },
  { code: "fr", label: "Français" },
];
