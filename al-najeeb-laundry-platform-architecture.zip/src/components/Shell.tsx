"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState } from "react";
import { LOCALE_OPTIONS, usePlatform } from "./Providers";
import { api } from "@/lib/client";

const ROLE_LABELS: Record<string, string> = {
  SUPER_ADMIN: "الإدارة العليا",
  ASSISTANT_ADMIN: "مساعد الإدارة",
  MERCHANT: "قطع الغيار",
  MAINTENANCE_TECH: "التركيب والصيانة",
  SHIPPING_COMPANY: "شركة التوصيل",
};

export function Shell({ children }: { children: React.ReactNode }) {
  const { t, locale, setLocale, session, refreshSession, deviceId, mfaVerified, runBiometric } =
    usePlatform();
  const pathname = usePathname();
  const router = useRouter();
  const [busy, setBusy] = useState(false);

  const rail = [
    { href: "/", icon: "▶", label: t("showroom") },
    { href: "/auctions", icon: "hammer", label: t("auctions") },
    { href: "/support", icon: "eye", label: t("support") },
    { href: "/dashboard", icon: "grid", label: t("panels") },
  ];

  const glyph = (icon: string) => {
    if (icon === "hammer") return "🔨";
    if (icon === "eye") return "🩺";
    if (icon === "grid") return "🗂️";
    return "▶";
  };

  async function signOut() {
    setBusy(true);
    try {
      await api("/api/auth/session", { method: "DELETE" });
      await refreshSession();
      router.push("/");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex min-h-screen flex-col lg:flex-row">
      {/* Media-player style vertical rail */}
      <aside className="najeeb-card sticky top-0 z-30 flex shrink-0 items-center gap-2 px-3 py-2 lg:h-screen lg:w-[92px] lg:flex-col lg:gap-4 lg:py-6">
        <Link href="/" className="flex items-center gap-2 lg:flex-col">
          <span className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-amber-300 to-teal-500 text-lg font-black text-slate-900">
            ن
          </span>
          <span className="text-[11px] font-bold leading-tight text-amber-200 lg:text-center">
            {t("brandShort")}
          </span>
        </Link>
        <nav className="flex flex-1 items-center gap-1 lg:flex-col lg:gap-2">
          {rail.map((entry) => {
            const active =
              entry.href === "/"
                ? pathname === "/"
                : pathname.startsWith(entry.href);
            return (
              <Link
                key={entry.href}
                href={entry.href}
                className={`najeeb-rail-item flex flex-1 flex-col items-center gap-1 rounded-2xl px-3 py-2 text-[10px] font-semibold lg:w-full lg:flex-none lg:py-3 ${
                  active
                    ? "bg-amber-400/15 text-amber-200"
                    : "text-slate-300"
                }`}
              >
                <span className="text-lg">{glyph(entry.icon)}</span>
                {entry.label}
              </Link>
            );
          })}
        </nav>
        <div className="hidden flex-col items-center gap-1 text-[9px] text-slate-500 lg:flex">
          <span>🛡️ {t("deviceLocked")}</span>
          <span className="max-w-[70px] truncate font-mono text-amber-300/70">
            {deviceId ? deviceId.slice(0, 10) : "…"}
          </span>
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        {/* Top bar */}
        <header className="najeeb-card sticky top-0 z-20 flex flex-wrap items-center gap-3 px-4 py-3">
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-black text-white lg:text-base">
              معرض شركة النجيب المتطورة لمعدات المغاسل
            </p>
            <p className="truncate text-[10px] text-slate-400">
              📍 جدة — الخمرة · 🖴 تخزين SSD محلي · Al_Najeeb_SSD
            </p>
          </div>
          <select
            value={locale}
            onChange={(event) => setLocale(event.target.value as typeof locale)}
            className="rounded-xl border border-white/10 bg-slate-900/70 px-2 py-1.5 text-xs text-slate-200"
            aria-label="language"
          >
            {LOCALE_OPTIONS.map((option) => (
              <option key={option.code} value={option.code}>
                {option.label}
              </option>
            ))}
          </select>
          {session?.authenticated ? (
            <div className="flex items-center gap-2">
              <span className="rounded-xl border border-amber-300/30 bg-amber-400/10 px-2 py-1 text-[10px] font-bold text-amber-200">
                {ROLE_LABELS[session.roleType] ?? session.roleType}
              </span>
              {!mfaVerified ? (
                <button
                  onClick={() => void runBiometric()}
                  className="rounded-xl border border-teal-300/30 bg-teal-400/10 px-2 py-1 text-[10px] font-bold text-teal-200 hover:bg-teal-400/20"
                >
                  🫆 {t("mfa")}
                </button>
              ) : (
                <span className="rounded-xl border border-teal-300/30 bg-teal-400/10 px-2 py-1 text-[10px] font-bold text-teal-200">
                  ✅ {t("mfa")}
                </span>
              )}
              <button
                onClick={() => void signOut()}
                disabled={busy}
                className="rounded-xl border border-white/10 px-2 py-1 text-[10px] text-slate-300 hover:bg-white/5"
              >
                {t("logout")}
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <Link
                href="/login"
                className="rounded-xl bg-amber-400 px-3 py-1.5 text-[11px] font-black text-slate-900 hover:bg-amber-300"
              >
                {t("login")}
              </Link>
              <Link
                href="/login?mode=join"
                className="rounded-xl border border-white/15 px-3 py-1.5 text-[11px] font-bold text-slate-200 hover:bg-white/5"
              >
                {t("join")}
              </Link>
            </div>
          )}
        </header>

        <main className="min-w-0 flex-1 px-4 pb-16 pt-5">{children}</main>

        <footer className="najeeb-card px-4 py-4 text-center text-[10px] leading-relaxed text-slate-400">
          <p className="font-bold text-amber-200">
            HALA SOFT GROUP — البنية الهجينة المحلية/السحابية
          </p>
          <p>
            الخادم: جدة — الخمرة، المملكة العربية السعودية · الوسائط: مسارات بث
            محلية من <span className="font-mono">/mnt/storage/Al_Najeeb_SSD</span>
          </p>
        </footer>
      </div>
    </div>
  );
}
