"use client";

import Link from "next/link";
import { useEffect, useRef } from "react";
import { usePlatform } from "./Providers";
import type { TrailerCard } from "@/lib/catalog";

function TrailerTile({ card }: { card: TrailerCard }) {
  const { sar, t } = usePlatform();
  const videoRef = useRef<HTMLVideoElement | null>(null);

  useEffect(() => {
    const node = videoRef.current;
    if (!node) return;
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            void node.play().catch(() => undefined);
          } else {
            node.pause();
          }
        }
      },
      { threshold: 0.55 },
    );
    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  return (
    <Link
      href={`/item/${card.equipmentId}`}
      className="trailer-card group relative w-[196px] shrink-0 overflow-hidden rounded-3xl border border-white/10 bg-slate-900/60 najeeb-glow sm:w-[220px]"
    >
      <div className="relative aspect-[9/16] w-full overflow-hidden bg-black">
        {card.videoUrl ? (
          <video
            ref={videoRef}
            src={card.videoUrl}
            poster={card.poster ?? undefined}
            muted
            loop
            playsInline
            preload="metadata"
            className="h-full w-full object-cover"
          />
        ) : (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={card.poster ?? ""}
            alt={card.titleAr}
            className="h-full w-full object-cover"
          />
        )}
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/85 via-black/10 to-black/40" />
        {card.live ? (
          <span className="absolute right-3 top-3 flex items-center gap-1 rounded-full border border-rose-400/40 bg-rose-500/20 px-2 py-0.5 text-[9px] font-black text-rose-200">
            <span className="live-dot h-1.5 w-1.5 rounded-full bg-rose-400" />
            {t("live")}
          </span>
        ) : null}
        <span className="absolute left-3 top-3 rounded-full border border-white/20 bg-black/50 px-2 py-0.5 text-[9px] font-bold text-amber-200">
          {card.status}
        </span>
        <div className="absolute inset-x-0 bottom-0 space-y-1 p-3 text-right">
          <p className="line-clamp-2 text-[11px] font-bold leading-snug text-white">
            {card.titleAr}
          </p>
          <p className="text-sm font-black text-amber-300">{sar(card.price)}</p>
          <p className="truncate text-[8px] font-mono text-slate-400" dir="ltr">
            {card.logicalPath?.replace("/mnt/storage/Al_Najeeb_SSD/", "")}
          </p>
          <span className="inline-block rounded-lg bg-amber-400 px-2 py-1 text-[9px] font-black text-slate-900">
            {t("reserve")}
          </span>
        </div>
      </div>
    </Link>
  );
}

export function TrailerRail({ trailers }: { trailers: TrailerCard[] }) {
  const { t } = usePlatform();
  if (trailers.length === 0) return null;
  return (
    <section className="space-y-3">
      <div className="flex items-center justify-between">
        <h2 className="flex items-center gap-2 text-sm font-black text-white">
          <span className="grid h-7 w-7 place-items-center rounded-xl bg-amber-400/15 text-amber-300">
            🎬
          </span>
          {t("newArrivals")}
        </h2>
        <span className="text-[10px] text-slate-400">
          بث مباشر من SSD المحلي · Al_Najeeb_SSD/02_Trailers_4K
        </span>
      </div>
      <div className="-mx-1 flex snap-x gap-3 overflow-x-auto px-1 pb-2">
        {trailers.map((card) => (
          <div key={card.equipmentId} className="snap-start">
            <TrailerTile card={card} />
          </div>
        ))}
      </div>
    </section>
  );
}
