"use client";

import { useCallback, useEffect, useState } from "react";
import { api } from "@/lib/client";
import { usePlatform } from "../Providers";

type UserRow = {
  user: {
    userId: number;
    username: string;
    roleType: string;
    isActive: boolean;
    hardwareDeviceId: string | null;
    commissionPercentage: string;
    city: string | null;
    createdAt: string;
  };
  device: { deviceLabel: string | null; violationCount: number } | null;
  itemCount: number;
};

type Summary = {
  escrow: { heldSar: number; releasedSar: number; commissionSar: number; refundedSar: number };
  catalogue: { items: number; inventory: number };
  tenants: number;
  orders: { total: number; gmv: number; commission: number };
};

export function AdminPanel({ userId }: { userId: number }) {
  const { sar, mfaVerified, runBiometric, t } = usePlatform();
  const [rows, setRows] = useState<UserRow[]>([]);
  const [summary, setSummary] = useState<Summary | null>(null);
  const [folder, setFolder] = useState("/mnt/storage/Al_Najeeb_SSD");
  const [tree, setTree] = useState<{ folder: string; entries: string[] } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      const [users, finance] = await Promise.all([
        api<UserRow[]>("/api/admin/users"),
        api<Summary>("/api/finance/summary"),
      ]);
      setRows(users);
      setSummary(finance);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "تعذر تحميل البيانات");
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  async function act(target: number, action: string, extra: Record<string, unknown> = {}) {
    setBusy(true);
    try {
      await api("/api/admin/users", {
        method: "PATCH",
        json: { userId: target, action, ...extra },
      });
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "تعذر تنفيذ الإجراء");
    } finally {
      setBusy(false);
    }
  }

  async function browse() {
    setBusy(true);
    try {
      const data = await api<{ folder: string; entries: string[] }>(
        `/api/storage/tree?folder=${encodeURIComponent(folder)}`,
      );
      setTree(data);
      setError(null);
    } catch (err) {
      setTree(null);
      setError(err instanceof Error ? err.message : "تم حجب الوصول للمجلد");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-4">
      {!mfaVerified ? (
        <div className="najeeb-card flex flex-wrap items-center justify-between gap-3 rounded-3xl border-amber-300/30 p-4">
          <p className="text-[11px] text-amber-100">
            ⚠️ العمليات الحساسة (اعتماد الحسابات، فك أقفال الأجهزة) تتطلب توثيق
            البصمة أولاً.
          </p>
          <button
            onClick={() => void runBiometric()}
            className="rounded-2xl bg-teal-400 px-4 py-2 text-xs font-black text-slate-900"
          >
            🫆 {t("mfa")}
          </button>
        </div>
      ) : null}

      {summary ? (
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { label: "محفوظ في الضمان", value: sar(summary.escrow.heldSar), tone: "text-amber-200" },
            { label: "مُحوَّل للتجار", value: sar(summary.escrow.releasedSar), tone: "text-emerald-300" },
            { label: "عمولات المنصة (≤15%)", value: sar(summary.escrow.commissionSar), tone: "text-teal-300" },
            { label: "مسترد", value: sar(summary.escrow.refundedSar), tone: "text-rose-300" },
            { label: "إجمالي المبيعات", value: sar(summary.orders.gmv), tone: "text-white" },
            { label: "قيمة الكتالوج", value: sar(summary.catalogue.inventory), tone: "text-white" },
            { label: "عدد المستأجرين", value: String(summary.tenants), tone: "text-white" },
            { label: "عدد الطلبات", value: String(summary.orders.total), tone: "text-white" },
          ].map((card) => (
            <div key={card.label} className="najeeb-card rounded-3xl p-3">
              <p className="text-[10px] text-slate-400">{card.label}</p>
              <p className={`text-base font-black ${card.tone}`}>{card.value}</p>
            </div>
          ))}
        </div>
      ) : null}

      <section className="najeeb-card space-y-3 rounded-3xl p-4">
        <h2 className="text-sm font-black text-white">🗂️ وحدة تحكم تخزين SSD</h2>
        <div className="flex flex-wrap gap-2">
          <input
            value={folder}
            onChange={(event) => setFolder(event.target.value)}
            dir="ltr"
            className="min-w-[260px] flex-1 rounded-2xl border border-white/10 bg-slate-950/60 px-3 py-2 font-mono text-[11px] text-slate-200"
          />
          <button
            onClick={() => void browse()}
            disabled={busy}
            className="rounded-2xl bg-amber-400 px-4 py-2 text-xs font-black text-slate-900 disabled:opacity-50"
          >
            تصفح المجلد
          </button>
          <button
            onClick={() => {
              setFolder("/mnt/storage/Al_Najeeb_SSD/04_Spare_Parts/Merchant_2/../../../01_Showroom_Catalog");
              void browse();
            }}
            className="rounded-2xl border border-rose-300/30 px-4 py-2 text-xs font-bold text-rose-200"
          >
            اختبار محاولة اختراق مسار
          </button>
        </div>
        {tree ? (
          <div className="rounded-2xl border border-white/10 bg-black/30 p-3">
            <p className="font-mono text-[10px] text-teal-300" dir="ltr">
              {tree.folder}
            </p>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {tree.entries.map((entry) => (
                <span
                  key={entry}
                  className="rounded-lg border border-white/10 bg-black/30 px-2 py-0.5 font-mono text-[10px] text-slate-300"
                  dir="ltr"
                >
                  {entry}
                </span>
              ))}
            </div>
          </div>
        ) : null}
      </section>

      <section className="najeeb-card space-y-3 rounded-3xl p-4">
        <h2 className="text-sm font-black text-white">👥 {t("users")} والاعتماد</h2>
        {error ? (
          <p className="rounded-2xl border border-rose-300/30 bg-rose-400/10 p-2 text-[11px] text-rose-100">
            {error}
          </p>
        ) : null}
        <div className="overflow-x-auto">
          <table className="w-full min-w-[720px] text-right text-[11px]">
            <thead className="text-slate-400">
              <tr>
                <th className="p-2">الحساب</th>
                <th className="p-2">الدور</th>
                <th className="p-2">الحالة</th>
                <th className="p-2">قفل الجهاز</th>
                <th className="p-2">عناصر</th>
                <th className="p-2">عمولة</th>
                <th className="p-2">إجراءات</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.user.userId} className="border-t border-white/5">
                  <td className="p-2 font-bold text-slate-100">
                    {row.user.username}
                    <span className="block text-[9px] text-slate-500">
                      {row.user.city ?? "—"}
                    </span>
                  </td>
                  <td className="p-2 text-amber-200">{row.user.roleType}</td>
                  <td className="p-2">
                    {row.user.isActive ? (
                      <span className="text-emerald-300">معتمد</span>
                    ) : (
                      <span className="text-rose-300">بانتظار الموافقة</span>
                    )}
                  </td>
                  <td className="p-2 font-mono text-[10px] text-slate-400" dir="ltr">
                    {row.user.hardwareDeviceId?.slice(0, 12) ?? "—"}
                    {row.device && row.device.violationCount > 0 ? (
                      <span className="ms-1 text-rose-300">
                        ({row.device.violationCount} محاولة)
                      </span>
                    ) : null}
                  </td>
                  <td className="p-2">{row.itemCount}</td>
                  <td className="p-2">{Number(row.user.commissionPercentage)}%</td>
                  <td className="p-2">
                    <div className="flex flex-wrap gap-1">
                      {!row.user.isActive ? (
                        <button
                          onClick={() => void act(row.user.userId, "ACTIVATE")}
                          disabled={busy || !mfaVerified}
                          className="rounded-lg bg-emerald-400 px-2 py-1 text-[10px] font-black text-slate-900 disabled:opacity-40"
                        >
                          اعتماد
                        </button>
                      ) : (
                        <button
                          onClick={() => void act(row.user.userId, "DEACTIVATE")}
                          disabled={busy || !mfaVerified}
                          className="rounded-lg border border-rose-300/30 px-2 py-1 text-[10px] text-rose-200 disabled:opacity-40"
                        >
                          إيقاف
                        </button>
                      )}
                      <button
                        onClick={() => void act(row.user.userId, "RELEASE_DEVICE")}
                        disabled={busy || !mfaVerified}
                        className="rounded-lg border border-white/15 px-2 py-1 text-[10px] text-slate-200 disabled:opacity-40"
                      >
                        فك القفل
                      </button>
                      <button
                        onClick={() =>
                          void act(row.user.userId, "SET_COMMISSION", {
                            commissionPercentage: 10,
                          })
                        }
                        disabled={busy || !mfaVerified}
                        className="rounded-lg border border-teal-300/30 px-2 py-1 text-[10px] text-teal-200 disabled:opacity-40"
                      >
                        عمولة 10%
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
      <p className="text-[10px] text-slate-500">
        المشرف الحالي: #{userId} — كل إجراء يُسجَّل في سجل التدقيق (audit_log).
      </p>
    </div>
  );
}
