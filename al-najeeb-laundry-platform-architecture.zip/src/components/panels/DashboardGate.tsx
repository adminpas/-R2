"use client";

import { AdminPanel } from "./AdminPanel";
import { MerchantPanel } from "./MerchantPanel";
import { ShippingPanel } from "./ShippingPanel";
import { TechPanel } from "./TechPanel";

export function DashboardGate({
  roleType,
  userId,
}: {
  roleType: string;
  userId: number;
}) {
  switch (roleType) {
    case "SUPER_ADMIN":
    case "ASSISTANT_ADMIN":
      return <AdminPanel userId={userId} />;
    case "MERCHANT":
      return <MerchantPanel userId={userId} />;
    case "SHIPPING_COMPANY":
      return <ShippingPanel userId={userId} />;
    case "MAINTENANCE_TECH":
      return <TechPanel userId={userId} />;
    default:
      return (
        <p className="najeeb-card rounded-3xl p-5 text-sm text-slate-300">
          لا توجد لوحة متاحة لهذا الدور.
        </p>
      );
  }
}
