"use client";

import { useCallback, useEffect, useState } from "react";
import { api } from "@/lib/client";
import { usePlatform } from "../Providers";

type ItemRow = {
  equipment: {
    equipmentId: number;
    titleAr: string;
    price: string;
    commissionPercentage: string;
    equipmentStatus: string;
    availabilityStatus: string;
    videoTrailerPath: string | null;
    isLiveShowroom: boolean;
  };
};

type ReservationRow = {
  reservation: {
    reservationId: number;
    holdExpiresAt: string;
    downpaymentAmount: string;
    status: string;
  };
  item: { titleAr: string; price: string } | null;
  escrowStage: string | null;
};

export function MerchantPanel({ userId }: { userId: number }) {
  const { sar, t, deviceId } = usePlatform();
  const [items, setItems] = useState<ItemRow[]>([]);
  const [holds, setHolds] = useState<ReservationRow[]>([]);
  const [categories, setCategories] = useState<
    { category: { categoryId: number; categoryNameAr: string }; itemCount: number }[]
  >([]);
  const [folder, setFolder] = useState("");
  const [entries, setEntries] = useState<{ name: string; sizeBytes: number }[]>([]);
  const [form, setForm] = useState({
    titleAr: "",
    price: "",
    categoryId: "",
    commissionPercentage: "15",
    equipmentStatus: "NEW_4K",
    isLiveShowroom: true,
  });
  const [uploadInfo, setUploadInfo] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      const [catalog, mine, myHolds] = await Promise.all([
        api<{ category: { categoryId: number; categoryNameAr: string }; itemCount: number }[]>(
          "/api/categories",
        ),
        api<ItemRow[]>(`/api/equipment?merchantId=${userId}&limit=60`),
        api<ReservationRow[]>("/api/reservations"),
      ]);
      setCategories(catalog);
      setItems(mine);
      setHolds(myHolds);
    } catch (err) {
      setError(err instanceof Error ? err.message : "تعذر تحميل بيانات اللوحة");
    }
  }, [userId]);

  useEffect(() => {
    void load();
  }, [load]);

  async function browseFolder() {
    setBusy(true);
    try {
      const data = await api<{ folder: string; entries: { name: string; sizeBytes: number }[] }>(
        `/api/media/upload?folder=${encodeURIComponent(
          folder || `/mnt/storage/Al_Najeeb_SSD/04_Spare_Parts/Merchant_${userId}`,
        )}`,
      );
      setEntries(data.entries);
      setFolder(data.folder);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "تم حجب الوصول للمجلد");
    } finally {
      setBusy(false);
    }
  }

  async function createItem() {
    setBusy(true);
    setError(null);
    try {
      await api("/api/equipment", {
        method: "POST",
        json: {
          titleAr: form.titleAr,
          price: Number(form.price),
          categoryId: Number(form.categoryId) || null,
          commissionPercentage: Number(form.commissionPercentage),
          equipmentStatus: form.equipmentStatus,
          isLiveShowroom: form.isLiveShowroom,
          specsJson: { source: "merchant-panel" },
        },
      });
      setForm({ ...form, titleAr: "", price: "" });
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "تعذر إضافة المعدة");
    } finally {
      setBusy(false);
    }
  }

  async function upload(file: File) {
    setBusy(true);
    setError(null);
    try {
      const body = new FormData();
      body.append("file", file);
      body.append("kind", file.type.startsWith("video") ? "TRAILER" : "IMAGE");
      body.append("folder", folder || `/mnt/storage/Al_Najeeb_SSD/04_Spare_Parts/Merchant_${userId}`);
      const response = await fetch("/api/media/upload", { method: "POST", body });
      const payload = (await response.json()) as
        | { ok: true; data: { logicalPath: string; tenantRoot: string } }
        | { ok: false; error: { messageAr: string } };
      if (!payload.ok) throw new Error(payload.error.messageAr);
      setUploadInfo(payload.data.logicalPath);
      await browseFolder();
    } catch (err) {
      setError(err instanceof Error ? err.message : "فشل الرفع إلى SSD");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-4">
      <div className="grid gap-2 sm:grid-cols-3">
        <div className="najeeb-card rounded-3xl p-3">
          <p className="text-[10px] text-slate-400">عناصر معروضة</p>
          <p className="text-lg font-black text-amber-200">{items.length}</p>
        </div>
        <div className="najeeb-card rounded-3xl p-3">
          <p className="text-[10px] text-slate-400">حجوزات ٢٤ ساعة</p>
          <p className="text-lg font-black text-teal-300">
            {holds.filter((row) => row.reservation.status === "ACTIVE_HOLD").length}
          </p>
        </div>
        <div className="najeeb-card rounded-3xl p-3">
          <p className="text-[10px] text-slate-400">مجلد المستأجر</p>
          <p className="truncate font-mono text-[10px] text-slate-300" dir="ltr">
            04_Spare_Parts/Merchant_{userId}
          </p>
        </div>
      </div>

      <section className="najeeb-card space-y-3 rounded-3xl p-4">
        <h2 className="text-sm font-black text-white">➕ {t("addItem")}</h2>
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          <input
            value={form.titleAr}
            onChange={(event) => setForm({ ...form, titleAr: event.target.value })}
            placeholder="عنوان المعدة"
            className="rounded-2xl border border-white/10 bg-slate-950/60 px-3 py-2 text-xs text-slate-100"
          />
          <input
            value={form.price}
            onChange={(event) => setForm({ ...form, price: event.target.value })}
            placeholder="السعر ر.س"
            inputMode="numeric"
            className="rounded-2xl border border-white/10 bg-slate-950/60 px-3 py-2 text-xs text-slate-100"
          />
          <select
            value={form.categoryId}
            onChange={(event) => setForm({ ...form, categoryId: event.target.value })}
            className="rounded-2xl border border-white/10 bg-slate-950/60 px-3 py-2 text-xs text-slate-100"
          >
            <option value="">اختر القسم</option>
            {categories.map((row) => (
              <option key={row.category.categoryId} value={row.category.categoryId}>
                {row.category.categoryNameAr}
              </option>
            ))}
          </select>
          <input
            value={form.commissionPercentage}
            onChange={(event) => setForm({ ...form, commissionPercentage: event.target.value })}
            placeholder="نسبة العمولة (سقف 15%)"
            className="rounded-2xl border border-white/10 bg-slate-950/60 px-3 py-2 text-xs text-slate-100"
          />
          <select
            value={form.equipmentStatus}
            onChange={(event) => setForm({ ...form, equipmentStatus: event.target.value })}
            className="rounded-2xl border border-white/10 bg-slate-950/60 px-3 py-2 text-xs text-slate-100"
          >
            <option value="NEW_4K">جديد 4K</option>
            <option value="LIKE_NEW_BLUERAY">كالجديد BlueRay</option>
            <option value="USED_EXCELLENT_HD">مستعمل ممتاز HD</option>
            <option value="REFURBISHED">مُجدد</option>
          </select>
          <label className="flex items-center gap-2 rounded-2xl border border-white/10 bg-slate-950/60 px-3 py-2 text-xs text-slate-200">
            <input
              type="checkbox"
              checked={form.isLiveShowroom}
              onChange={(event) => setForm({ ...form, isLiveShowroom: event.target.checked })}
            />
            تشغيل البث المباشر للمعرض
          </label>
        </div>
        <button
          onClick={() => void createItem()}
          disabled={busy || !form.titleAr || !form.price}
          className="rounded-2xl bg-amber-400 px-4 py-2 text-xs font-black text-slate-900 disabled:opacity-40"
        >
          نشر في المعرض
        </button>
      </section>

      <section className="najeeb-card space-y-3 rounded-3xl p-4">
        <h2 className="text-sm font-black text-white">
          ⬆ {t("upload")} — مجلد المستأجر المعزول
        </h2>
        <p className="text-[10px] leading-relaxed text-slate-400">
          يُسمح بالكتابة داخل{" "}
          <span className="font-mono text-teal-300" dir="ltr">
            /mnt/storage/Al_Najeeb_SSD/04_Spare_Parts/Merchant_{userId}/
          </span>{" "}
          فقط. أي مسار آخر أو محاولة <span className="font-mono">../</span> تُحجب
          وتُسجَّل. 🔒 {t("deviceLocked")}:{" "}
          <span className="font-mono" dir="ltr">
            {deviceId?.slice(0, 12) ?? "—"}
          </span>
        </p>
        <div className="flex flex-wrap gap-2">
          <input
            value={folder}
            onChange={(event) => setFolder(event.target.value)}
            dir="ltr"
            placeholder={`/mnt/storage/Al_Najeeb_SSD/04_Spare_Parts/Merchant_${userId}`}
            className="min-w-[260px] flex-1 rounded-2xl border border-white/10 bg-slate-950/60 px-3 py-2 font-mono text-[11px] text-slate-200"
          />
          <button
            onClick={() => void browseFolder()}
            disabled={busy}
            className="rounded-2xl border border-white/15 px-4 py-2 text-xs font-bold text-slate-200"
          >
            عرض المجلد
          </button>
          <label className="cursor-pointer rounded-2xl bg-teal-400 px-4 py-2 text-xs font-black text-slate-900">
            اختيار ملف
            <input
              type="file"
              className="hidden"
              onChange={(event) => {
                const file = event.target.files?.[0];
                if (file) void upload(file);
              }}
            />
          </label>
        </div>
        {uploadInfo ? (
          <p className="rounded-2xl border border-emerald-300/30 bg-emerald-400/10 p-2 font-mono text-[10px] text-emerald-100" dir="ltr">
            {uploadInfo}
          </p>
        ) : null}
        {entries.length > 0 ? (
          <div className="flex flex-wrap gap-1.5">
            {entries.map((entry) => (
              <span
                key={entry.name}
                className="rounded-lg border border-white/10 bg-black/30 px-2 py-0.5 font-mono text-[10px] text-slate-300"
                dir="ltr"
              >
                {entry.name} · {(entry.sizeBytes / 1024).toFixed(1)} KB
              </span>
            ))}
          </div>
        ) : null}
      </section>

      <section className="najeeb-card space-y-3 rounded-3xl p-4">
        <h2 className="text-sm font-black text-white">🧾 عناصري في المعرض</h2>
        <div className="grid gap-2 lg:grid-cols-2">
          {items.map((row) => (
            <div
              key={row.equipment.equipmentId}
              className="rounded-2xl border border-white/10 bg-black/25 p-3 text-[11px]"
            >
              <div className="flex items-start justify-between gap-2">
                <p className="font-bold text-slate-100">{row.equipment.titleAr}</p>
                <span className="shrink-0 font-black text-amber-200">
                  {sar(row.equipment.price)}
                </span>
              </div>
              <p className="mt-1 text-[10px] text-slate-400">
                عمولة {Number(row.equipment.commissionPercentage)}% ·{" "}
                {row.equipment.availabilityStatus} ·{" "}
                {row.equipment.isLiveShowroom ? "بث مباشر 📡" : "بدون بث"}
              </p>
              {row.equipment.videoTrailerPath ? (
                <p className="truncate font-mono text-[9px] text-teal-300/70" dir="ltr">
                  {row.equipment.videoTrailerPath}
                </p>
              ) : null}
            </div>
          ))}
        </div>
      </section>

      <section className="najeeb-card space-y-2 rounded-3xl p-4">
        <h2 className="text-sm font-black text-white">💠 حجوزات العملاء</h2>
        {holds.length === 0 ? (
          <p className="text-[11px] text-slate-400">لا توجد حجوزات بعد.</p>
        ) : (
          holds.map((row) => (
            <div
              key={row.reservation.reservationId}
              className="flex flex-wrap items-center justify-between gap-2 rounded-2xl border border-white/10 bg-black/25 p-2.5 text-[11px]"
            >
              <span className="text-slate-200">
                {row.item?.titleAr ?? "معدة"} — {sar(row.reservation.downpaymentAmount)}
              </span>
              <span className="text-slate-400">
                {row.reservation.status} · الضمان: {row.escrowStage ?? "—"} ·{" "}
                {new Date(row.reservation.holdExpiresAt).toLocaleString("ar-SA")}
              </span>
            </div>
          ))
        )}
      </section>

      {error ? (
        <p className="rounded-2xl border border-rose-300/30 bg-rose-400/10 p-2.5 text-[11px] text-rose-100">
          {error}
        </p>
      ) : null}
    </div>
  );
}
