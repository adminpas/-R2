"use client";

import { useCallback, useEffect, useState } from "react";
import { api } from "@/lib/client";
import { usePlatform } from "../Providers";

type JobRow = {
  job: {
    jobId: number;
    trackingCode: string;
    status: string;
    driverName: string | null;
    driverPhone: string | null;
    vehiclePlate: string | null;
    installationRequested: boolean;
    scheduledAt: string | null;
    deliveredAt: string | null;
  };
  order: { orderCode: string; totalAmount: string; customerId: number } | null;
  itemTitleAr: string | null;
  customerNameAr: string | null;
};

const FLOW = ["ASSIGNED", "PICKED_UP", "IN_TRANSIT", "DELIVERED"] as const;

export function ShippingPanel({ userId }: { userId: number }) {
  const { sar, t, deviceId } = usePlatform();
  const [jobs, setJobs] = useState<JobRow[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [driver, setDriver] = useState("سائق الخمرة");

  const load = useCallback(async () => {
    try {
      const data = await api<{ jobs: JobRow[] }>("/api/shipping");
      setJobs(data.jobs);
    } catch (err) {
      setError(err instanceof Error ? err.message : "تعذر تحميل المهام");
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  async function advance(jobId: number, status: string) {
    setBusy(true);
    try {
      await api("/api/shipping", {
        method: "PATCH",
        json: { jobId, status, driverName: driver, notes: `updated by ${userId}` },
      });
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "تعذر تحديث حالة المهمة");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-4">
      <div className="najeeb-card rounded-3xl p-3 text-[11px] text-slate-300">
        🚚 {t("shipping")} — 🔒 جهاز مرتبط:{" "}
        <span className="font-mono" dir="ltr">
          {deviceId?.slice(0, 12) ?? "—"}
        </span>
      </div>

      <input
        value={driver}
        onChange={(event) => setDriver(event.target.value)}
        placeholder="اسم السائق"
        className="w-full rounded-2xl border border-white/10 bg-slate-950/60 px-3 py-2 text-xs text-slate-100 sm:w-72"
      />

      {error ? (
        <p className="rounded-2xl border border-rose-300/30 bg-rose-400/10 p-2.5 text-[11px] text-rose-100">
          {error}
        </p>
      ) : null}

      <div className="grid gap-2 lg:grid-cols-2">
        {jobs.map((row) => (
          <article key={row.job.jobId} className="najeeb-card space-y-2 rounded-3xl p-4 text-[11px]">
            <div className="flex items-center justify-between">
              <p className="font-black text-amber-200">{row.job.trackingCode}</p>
              <span className="rounded-lg border border-white/15 px-2 py-0.5 text-[10px] text-slate-300">
                {row.job.status}
              </span>
            </div>
            <p className="text-slate-200">{row.itemTitleAr ?? "معدة"}</p>
            <p className="text-[10px] text-slate-400">
              الطلب: {row.order?.orderCode ?? "—"} · القيمة:{" "}
              {row.order ? sar(row.order.totalAmount) : "—"} · العميل:{" "}
              {row.customerNameAr ?? "—"}
            </p>
            {row.job.installationRequested ? (
              <p className="rounded-lg border border-teal-300/25 bg-teal-400/10 px-2 py-1 text-[10px] text-teal-200">
                🛠️ مطلوب فريق تركيب مع التسليم
              </p>
            ) : null}
            <div className="flex flex-wrap gap-1.5 pt-1">
              {FLOW.map((status) => (
                <button
                  key={status}
                  onClick={() => void advance(row.job.jobId, status)}
                  disabled={busy}
                  className={`rounded-lg px-2 py-1 text-[10px] font-bold disabled:opacity-40 ${
                    row.job.status === status
                      ? "bg-emerald-400 text-slate-900"
                      : "border border-white/15 text-slate-300"
                  }`}
                >
                  {status}
                </button>
              ))}
              <button
                onClick={() => void advance(row.job.jobId, "FAILED")}
                disabled={busy}
                className="rounded-lg border border-rose-300/30 px-2 py-1 text-[10px] font-bold text-rose-200 disabled:opacity-40"
              >
                FAILED
              </button>
            </div>
          </article>
        ))}
        {jobs.length === 0 ? (
          <p className="najeeb-card rounded-3xl p-4 text-[11px] text-slate-400">
            لا توجد مهام توصيل مسندة حالياً.
          </p>
        ) : null}
      </div>
    </div>
  );
}
