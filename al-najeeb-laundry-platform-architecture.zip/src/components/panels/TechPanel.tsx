"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { api } from "@/lib/client";
import { usePlatform } from "../Providers";

type TicketRow = {
  ticket: {
    ticketId: number;
    ticketCode: string;
    issueSummary: string;
    severity: string;
    status: string;
    roomId: string | null;
    aiVisionReport: {
      confidence: number;
      detected: { labelAr: string; part: string }[];
      recommendedActionAr: string;
      routedTeam: string;
    } | null;
    createdAt: string;
  };
  techNameAr: string | null;
};

export function TechPanel({ userId }: { userId: number }) {
  const { t } = usePlatform();
  const [rows, setRows] = useState<TicketRow[]>([]);
  const [summary, setSummary] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [created, setCreated] = useState<{ roomId: string; ticketCode: string } | null>(null);

  const load = useCallback(async () => {
    try {
      const data = await api<{ tickets: TicketRow[] }>("/api/support/tickets");
      setRows(data.tickets);
    } catch (err) {
      setError(err instanceof Error ? err.message : "تعذر تحميل الطلبات");
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  async function triage() {
    setBusy(true);
    setError(null);
    try {
      const data = await api<{ roomId: string; ticket: { ticketCode: string } }>(
        "/api/support/tickets",
        {
          method: "POST",
          json: { issueSummary: summary, luminance: 0.52, motionScore: 0.44 },
        },
      );
      setCreated({ roomId: data.roomId, ticketCode: data.ticket.ticketCode });
      setSummary("");
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "تعذر إنشاء الطلب");
    } finally {
      setBusy(false);
    }
  }

  async function openRoom(ticketId: number) {
    setBusy(true);
    try {
      const data = await api<{ joinUrl: string }>("/api/conferences", {
        method: "POST",
        json: { purpose: "AI_VISION_SUPPORT", ticketId, title: `جلسة صيانة #${ticketId}` },
      });
      window.location.href = data.joinUrl;
    } catch (err) {
      setError(err instanceof Error ? err.message : "تعذر فتح الغرفة");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-4">
      <section className="najeeb-card space-y-3 rounded-3xl p-4">
        <h2 className="text-sm font-black text-white">🩺 {t("aiVision")}</h2>
        <p className="text-[10px] leading-relaxed text-slate-400">
          اكتب وصف العطل أو استخدم كاميرا الجهاز من صفحة الدعم المباشر؛ المحرك
          يحلل الأعراض ويصنّف العطل ويوجّه الجلسة لفريق التركيب والصيانة المناسب
          مع فتح غرفة مؤتمر فيديو فوراً.
        </p>
        <textarea
          value={summary}
          onChange={(event) => setSummary(event.target.value)}
          rows={3}
          placeholder="مثال: صوت مرتفع من الطبلية مع اهتزاز وتسريب مياه من الأسفل"
          className="w-full rounded-2xl border border-white/10 bg-slate-950/60 p-3 text-xs text-slate-100 outline-none focus:border-amber-300/50"
        />
        <button
          onClick={() => void triage()}
          disabled={busy || summary.trim().length < 6}
          className="rounded-2xl bg-amber-400 px-4 py-2 text-xs font-black text-slate-900 disabled:opacity-40"
        >
          تشغيل التشخيص + فتح غرفة مؤتمر
        </button>
        {created ? (
          <p className="rounded-2xl border border-emerald-300/30 bg-emerald-400/10 p-2 text-[11px] text-emerald-100">
            ✅ {created.ticketCode} — الغرفة جاهزة{" "}
            <Link href={`/support?room=${created.roomId}`} className="underline">
              دخول المؤتمر
            </Link>
          </p>
        ) : null}
      </section>

      {error ? (
        <p className="rounded-2xl border border-rose-300/30 bg-rose-400/10 p-2.5 text-[11px] text-rose-100">
          {error}
        </p>
      ) : null}

      <section className="space-y-2">
        <h2 className="text-sm font-black text-white">📋 {t("tickets")}</h2>
        {rows.map((row) => (
          <article key={row.ticket.ticketId} className="najeeb-card space-y-2 rounded-3xl p-4 text-[11px]">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <p className="font-black text-amber-200">{row.ticket.ticketCode}</p>
              <span className="rounded-lg border border-white/15 px-2 py-0.5 text-[10px] text-slate-300">
                {row.ticket.status} · {row.ticket.severity}
              </span>
            </div>
            <p className="text-slate-200">{row.ticket.issueSummary}</p>
            {row.ticket.aiVisionReport ? (
              <div className="space-y-1 rounded-2xl border border-white/10 bg-black/30 p-2.5">
                <p className="text-[10px] text-teal-300">
                  ثقة التشخيص: {(row.ticket.aiVisionReport.confidence * 100).toFixed(0)}% · الفريق:{" "}
                  {row.ticket.aiVisionReport.routedTeam}
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {row.ticket.aiVisionReport.detected.map((item) => (
                    <span
                      key={item.part}
                      className="rounded-lg border border-white/10 bg-black/40 px-2 py-0.5 text-[10px] text-slate-200"
                    >
                      {item.labelAr} ({item.part})
                    </span>
                  ))}
                </div>
                <p className="text-[10px] text-slate-300">
                  الإجراء: {row.ticket.aiVisionReport.recommendedActionAr}
                </p>
              </div>
            ) : null}
            <button
              onClick={() => void openRoom(row.ticket.ticketId)}
              disabled={busy}
              className="rounded-xl border border-teal-300/30 bg-teal-400/10 px-3 py-1.5 text-[10px] font-black text-teal-200 disabled:opacity-40"
            >
              🎥 {t("openRoom")}
            </button>
          </article>
        ))}
        {rows.length === 0 ? (
          <p className="najeeb-card rounded-3xl p-4 text-[11px] text-slate-400">
            لا توجد طلبات صيانة مسجلة.
          </p>
        ) : null}
      </section>
      <p className="text-[10px] text-slate-500">الفني الحالي: #{userId}</p>
    </div>
  );
}
