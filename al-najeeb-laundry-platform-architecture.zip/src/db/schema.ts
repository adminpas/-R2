/**
 * AL-NAJEEB LAUNDRY SHOWROOM PLATFORM
 * Architect: HALA SOFT GROUP
 * Structural Database Matrix (PostgreSQL / Drizzle ORM)
 * Server: Jeddah, Al-Khumra, KSA — Hybrid Local-Cloud topology
 */
import {
  boolean,
  integer,
  jsonb,
  numeric,
  pgEnum,
  pgTable,
  serial,
  text,
  timestamp,
  varchar,
  type AnyPgColumn,
} from "drizzle-orm/pg-core";

/* ------------------------------------------------------------------ ENUMS */

export const roleTypeEnum = pgEnum("role_type", [
  "SUPER_ADMIN",
  "ASSISTANT_ADMIN",
  "MERCHANT",
  "MAINTENANCE_TECH",
  "SHIPPING_COMPANY",
]);

export const equipmentStatusEnum = pgEnum("equipment_status", [
  "NEW_4K",
  "LIKE_NEW_BLUERAY",
  "USED_EXCELLENT_HD",
  "REFURBISHED",
]);

export const availabilityStatusEnum = pgEnum("availability_status", [
  "AVAILABLE",
  "HOLD_24H",
  "SOLD",
]);

export const mediaKindEnum = pgEnum("media_kind", [
  "IMAGE",
  "TRAILER",
  "LIVE_FEED",
]);

export const reservationStatusEnum = pgEnum("reservation_status", [
  "PENDING_PAYMENT",
  "ACTIVE_HOLD",
  "CONVERTED",
  "EXPIRED",
  "RELEASED",
]);

export const escrowStageEnum = pgEnum("escrow_stage", [
  "INITIATED",
  "FUNDS_HELD",
  "RELEASED",
  "REFUNDED",
  "DISPUTED",
]);

export const shippingStatusEnum = pgEnum("shipping_status", [
  "ASSIGNED",
  "PICKED_UP",
  "IN_TRANSIT",
  "DELIVERED",
  "FAILED",
]);

export const ticketStatusEnum = pgEnum("ticket_status", [
  "OPEN",
  "DIAGNOSED",
  "SCHEDULED",
  "IN_PROGRESS",
  "RESOLVED",
]);

export const roomPurposeEnum = pgEnum("room_purpose", [
  "AI_VISION_SUPPORT",
  "INTERNAL",
  "MERCHANT",
  "CLIENT",
]);

export const ratingTargetEnum = pgEnum("rating_target", [
  "EQUIPMENT",
  "MERCHANT",
  "SHIPPING",
  "MAINTENANCE",
  "PLATFORM",
]);

/* ------------------------------------------------------- 1. SYSTEM USERS */

export const systemUsers = pgTable("system_users", {
  userId: serial("user_id").primaryKey(),
  username: varchar("username", { length: 100 }).notNull().unique(),
  passwordHash: varchar("password_hash", { length: 255 }).notNull(),
  roleType: roleTypeEnum("role_type").notNull(),
  /** 1-Device Lock: first physical initialization hardware identity */
  hardwareDeviceId: varchar("hardware_device_id", { length: 255 }).unique(),
  /** Pending Super-Admin approval gate */
  isActive: boolean("is_active").default(false).notNull(),
  /** FaceID / TouchID multi-factor handshake token */
  biometricToken: text("biometric_token"),
  displayNameAr: varchar("display_name_ar", { length: 200 }),
  displayNameEn: varchar("display_name_en", { length: 200 }),
  phone: varchar("phone", { length: 50 }),
  city: varchar("city", { length: 100 }),
  merchantSsdFolder: varchar("merchant_ssd_folder", { length: 500 }),
  commissionPercentage: numeric("commission_percentage", {
    precision: 5,
    scale: 2,
  })
    .default("15.00")
    .notNull(),
  lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

/* --------------------------------------------- 2. DEVICE BINDINGS / LOCKS */

export const deviceBindings = pgTable("device_bindings", {
  bindingId: serial("binding_id").primaryKey(),
  hardwareDeviceId: varchar("hardware_device_id", { length: 255 })
    .notNull()
    .unique(),
  userId: integer("user_id")
    .notNull()
    .references(() => systemUsers.userId, { onDelete: "cascade" }),
  deviceLabel: varchar("device_label", { length: 200 }),
  deviceSignature: text("device_signature"),
  approved: boolean("approved").default(true).notNull(),
  violationCount: integer("violation_count").default(0).notNull(),
  firstBoundAt: timestamp("first_bound_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
  lastSeenAt: timestamp("last_seen_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
  revokedAt: timestamp("revoked_at", { withTimezone: true }),
});

/* ------------------------------------------------------- 3. AUTH SESSIONS */

export const authSessions = pgTable("auth_sessions", {
  sessionId: serial("session_id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => systemUsers.userId, { onDelete: "cascade" }),
  tokenHash: text("token_hash").notNull().unique(),
  hardwareDeviceId: varchar("hardware_device_id", { length: 255 }),
  biometricVerified: boolean("biometric_verified").default(false).notNull(),
  locale: varchar("locale", { length: 10 }).default("ar").notNull(),
  ipAddress: varchar("ip_address", { length: 64 }),
  userAgent: text("user_agent"),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  revokedAt: timestamp("revoked_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

/* ---------------------------------------------------------- 4. CATEGORIES */

export const categories = pgTable("categories", {
  categoryId: serial("category_id").primaryKey(),
  parentCategoryId: integer("parent_category_id").references(
    (): AnyPgColumn => categories.categoryId,
  ),
  categoryNameAr: varchar("category_name_ar", { length: 150 }).notNull(),
  categoryNameEn: varchar("category_name_en", { length: 150 }),
  /** Physical mapped path on the local SSD array */
  ssdFolderPath: varchar("ssd_folder_path", { length: 500 }).notNull(),
  iconGlyph: varchar("icon_glyph", { length: 16 }),
  sortOrder: integer("sort_order").default(0).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

/* --------------------------------------------------- 5. LAUNDRY EQUIPMENT */

export const laundryEquipment = pgTable("laundry_equipment", {
  equipmentId: serial("equipment_id").primaryKey(),
  categoryId: integer("category_id").references(() => categories.categoryId),
  /** Strict merchant tenant isolation */
  merchantId: integer("merchant_id")
    .notNull()
    .references(() => systemUsers.userId, { onDelete: "cascade" }),
  titleAr: varchar("title_ar", { length: 255 }).notNull(),
  titleEn: varchar("title_en", { length: 255 }),
  descriptionAr: text("description_ar"),
  descriptionEn: text("description_en"),
  price: numeric("price", { precision: 10, scale: 2 }).notNull(),
  /** Dynamic auto-commission (hard ceiling 15%) */
  commissionPercentage: numeric("commission_percentage", {
    precision: 5,
    scale: 2,
  })
    .default("15.00")
    .notNull(),
  equipmentStatus: equipmentStatusEnum("equipment_status")
    .default("NEW_4K")
    .notNull(),
  availabilityStatus: availabilityStatusEnum("availability_status")
    .default("AVAILABLE")
    .notNull(),
  specsJson: jsonb("specs_json").$type<Record<string, string>>(),
  /** Local streaming link (logical SSD path) or remote demo feed */
  videoTrailerPath: varchar("video_trailer_path", { length: 500 }),
  posterImagePath: varchar("poster_image_path", { length: 500 }),
  isLiveShowroom: boolean("is_live_showroom").default(false).notNull(),
  stockQuantity: integer("stock_quantity").default(1).notNull(),
  holdExpiresAt: timestamp("hold_expires_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

/* ------------------------------------------------------- 6. EQUIPMENT MEDIA */

export const equipmentMedia = pgTable("equipment_media", {
  mediaId: serial("media_id").primaryKey(),
  equipmentId: integer("equipment_id").references(
    () => laundryEquipment.equipmentId,
    { onDelete: "cascade" },
  ),
  merchantId: integer("merchant_id")
    .notNull()
    .references(() => systemUsers.userId, { onDelete: "cascade" }),
  kind: mediaKindEnum("kind").default("IMAGE").notNull(),
  logicalPath: varchar("logical_path", { length: 500 }).notNull(),
  remoteUrl: text("remote_url"),
  posterUrl: text("poster_url"),
  mimeType: varchar("mime_type", { length: 120 }),
  sizeBytes: integer("size_bytes").default(0).notNull(),
  isVertical: boolean("is_vertical").default(true).notNull(),
  isPromotional: boolean("is_promotional").default(false).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

/* ------------------------------------------------ 7. AFFORDABLE AUCTIONS */

export const affordableAuctions = pgTable("affordable_auctions", {
  auctionId: serial("auction_id").primaryKey(),
  packageTitle: text("package_title").notNull(),
  packageDetails: jsonb("package_details").$type<{
    items?: string[];
    localeNoteAr?: string;
    localeNoteEn?: string;
  }>(),
  baseCostPrice: numeric("base_cost_price", { precision: 10, scale: 2 })
    .notNull(),
  currentHighestBid: numeric("current_highest_bid", {
    precision: 10,
    scale: 2,
  }).notNull(),
  highestBidderId: integer("highest_bidder_id").references(
    () => systemUsers.userId,
  ),
  /** Minimum raise 500 SAR */
  minimumIncrement: numeric("minimum_increment", { precision: 10, scale: 2 })
    .default("500.00")
    .notNull(),
  startDate: timestamp("start_date", { withTimezone: true }).notNull(),
  /** 30-day automated timer */
  endDate: timestamp("end_date", { withTimezone: true }).notNull(),
  isProcessed: boolean("is_processed").default(false).notNull(),
  processedAt: timestamp("processed_at", { withTimezone: true }),
  escrowId: integer("escrow_id"),
  createdByUserId: integer("created_by_user_id").references(
    () => systemUsers.userId,
  ),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const auctionBids = pgTable("auction_bids", {
  bidId: serial("bid_id").primaryKey(),
  auctionId: integer("auction_id")
    .notNull()
    .references(() => affordableAuctions.auctionId, { onDelete: "cascade" }),
  bidderId: integer("bidder_id")
    .notNull()
    .references(() => systemUsers.userId, { onDelete: "cascade" }),
  amount: numeric("amount", { precision: 10, scale: 2 }).notNull(),
  status: varchar("status", { length: 30 }).default("ACTIVE").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

/* ------------------------------------------------------- 8. RESERVATIONS */

export const reservations = pgTable("reservations", {
  reservationId: serial("reservation_id").primaryKey(),
  equipmentId: integer("equipment_id")
    .notNull()
    .references(() => laundryEquipment.equipmentId, { onDelete: "cascade" }),
  customerId: integer("customer_id")
    .notNull()
    .references(() => systemUsers.userId, { onDelete: "cascade" }),
  merchantId: integer("merchant_id")
    .notNull()
    .references(() => systemUsers.userId, { onDelete: "cascade" }),
  /** 24 hours */
  holdExpiresAt: timestamp("hold_expires_at", { withTimezone: true }).notNull(),
  downpaymentAmount: numeric("downpayment_amount", {
    precision: 10,
    scale: 2,
  }).notNull(),
  downpaymentPaidAt: timestamp("downpayment_paid_at", { withTimezone: true }),
  status: reservationStatusEnum("status").default("PENDING_PAYMENT").notNull(),
  escrowId: integer("escrow_id"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

/* --------------------------------------------------------------- 9. ORDERS */

export const orders = pgTable("orders", {
  orderId: serial("order_id").primaryKey(),
  orderCode: varchar("order_code", { length: 40 }).notNull().unique(),
  reservationId: integer("reservation_id").references(
    () => reservations.reservationId,
  ),
  equipmentId: integer("equipment_id")
    .notNull()
    .references(() => laundryEquipment.equipmentId),
  customerId: integer("customer_id")
    .notNull()
    .references(() => systemUsers.userId),
  merchantId: integer("merchant_id")
    .notNull()
    .references(() => systemUsers.userId),
  totalAmount: numeric("total_amount", { precision: 10, scale: 2 }).notNull(),
  downpaymentAmount: numeric("downpayment_amount", {
    precision: 10,
    scale: 2,
  }).notNull(),
  remainingAmount: numeric("remaining_amount", {
    precision: 10,
    scale: 2,
  }).notNull(),
  commissionPercentage: numeric("commission_percentage", {
    precision: 5,
    scale: 2,
  }).notNull(),
  commissionAmount: numeric("commission_amount", {
    precision: 10,
    scale: 2,
  }).notNull(),
  netToMerchant: numeric("net_to_merchant", { precision: 10, scale: 2 })
    .notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

/* ---------------------------------------------------- 10. SMART ESCROW LEDGER */

export const escrowTransactions = pgTable("escrow_transactions", {
  escrowId: serial("escrow_id").primaryKey(),
  escrowCode: varchar("escrow_code", { length: 40 }).notNull().unique(),
  orderId: integer("order_id").references(() => orders.orderId),
  reservationId: integer("reservation_id").references(
    () => reservations.reservationId,
  ),
  auctionId: integer("auction_id").references(
    () => affordableAuctions.auctionId,
  ),
  payerId: integer("payer_id")
    .notNull()
    .references(() => systemUsers.userId),
  payeeMerchantId: integer("payee_merchant_id").references(
    () => systemUsers.userId,
  ),
  grossAmount: numeric("gross_amount", { precision: 10, scale: 2 }).notNull(),
  commissionPercentage: numeric("commission_percentage", {
    precision: 5,
    scale: 2,
  })
    .default("15.00")
    .notNull(),
  commissionAmount: numeric("commission_amount", {
    precision: 10,
    scale: 2,
  })
    .default("0.00")
    .notNull(),
  netAmount: numeric("net_amount", { precision: 10, scale: 2 }).notNull(),
  stage: escrowStageEnum("stage").default("INITIATED").notNull(),
  paymentMethod: varchar("payment_method", { length: 60 })
    .default("MADA_LOCAL_GATEWAY")
    .notNull(),
  paymentReference: varchar("payment_reference", { length: 120 }),
  releasedAt: timestamp("released_at", { withTimezone: true }),
  refundedAt: timestamp("refunded_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

/* ------------------------------------------------------- 11. LOGISTICS */

export const shippingJobs = pgTable("shipping_jobs", {
  jobId: serial("job_id").primaryKey(),
  orderId: integer("order_id")
    .notNull()
    .references(() => orders.orderId, { onDelete: "cascade" }),
  courierUserId: integer("courier_user_id").references(
    () => systemUsers.userId,
  ),
  trackingCode: varchar("tracking_code", { length: 60 }).notNull().unique(),
  driverName: varchar("driver_name", { length: 150 }),
  driverPhone: varchar("driver_phone", { length: 50 }),
  vehiclePlate: varchar("vehicle_plate", { length: 50 }),
  status: shippingStatusEnum("status").default("ASSIGNED").notNull(),
  installationRequested: boolean("installation_requested")
    .default(false)
    .notNull(),
  notes: text("notes"),
  scheduledAt: timestamp("scheduled_at", { withTimezone: true }),
  deliveredAt: timestamp("delivered_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

/* --------------------------------------- 12. TECH: INSTALLATION & MAINTENANCE */

export const maintenanceTickets = pgTable("maintenance_tickets", {
  ticketId: serial("ticket_id").primaryKey(),
  ticketCode: varchar("ticket_code", { length: 40 }).notNull().unique(),
  equipmentId: integer("equipment_id").references(
    () => laundryEquipment.equipmentId,
  ),
  customerId: integer("customer_id").references(() => systemUsers.userId),
  merchantId: integer("merchant_id").references(() => systemUsers.userId),
  createdByUserId: integer("created_by_user_id")
    .notNull()
    .references(() => systemUsers.userId),
  issueSummary: text("issue_summary").notNull(),
  /** AI Tech Live Support: camera vision diagnostic output */
  aiVisionReport: jsonb("ai_vision_report").$type<{
    confidence: number;
    detected: { labelAr: string; labelEn: string; part: string }[];
    recommendedActionAr: string;
    recommendedActionEn: string;
    routedTeam: string;
  }>(),
  severity: varchar("severity", { length: 30 }).default("NORMAL").notNull(),
  status: ticketStatusEnum("status").default("OPEN").notNull(),
  assignedTechId: integer("assigned_tech_id").references(
    () => systemUsers.userId,
  ),
  roomId: varchar("room_id", { length: 64 }),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

/* ------------------------------------------- 13. IN-APP CONFERENCE (WebRTC) */

export const conferenceRooms = pgTable("conference_rooms", {
  roomId: varchar("room_id", { length: 64 }).primaryKey(),
  title: varchar("title", { length: 200 }).notNull(),
  purpose: roomPurposeEnum("purpose").default("AI_VISION_SUPPORT").notNull(),
  hostUserId: integer("host_user_id")
    .notNull()
    .references(() => systemUsers.userId, { onDelete: "cascade" }),
  ticketId: integer("ticket_id").references(
    () => maintenanceTickets.ticketId,
    { onDelete: "set null" },
  ),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const conferenceParticipants = pgTable("conference_participants", {
  participantId: serial("participant_id").primaryKey(),
  roomId: varchar("room_id", { length: 64 })
    .notNull()
    .references(() => conferenceRooms.roomId, { onDelete: "cascade" }),
  userId: integer("user_id")
    .notNull()
    .references(() => systemUsers.userId, { onDelete: "cascade" }),
  peerId: varchar("peer_id", { length: 80 }),
  joinedAt: timestamp("joined_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
  leftAt: timestamp("left_at", { withTimezone: true }),
});

/** Lightweight polling signaling relay for WebRTC offer/answer/ICE */
export const webrtcSignals = pgTable("webrtc_signals", {
  signalId: serial("signal_id").primaryKey(),
  roomId: varchar("room_id", { length: 64 })
    .notNull()
    .references(() => conferenceRooms.roomId, { onDelete: "cascade" }),
  senderUserId: integer("sender_user_id")
    .notNull()
    .references(() => systemUsers.userId, { onDelete: "cascade" }),
  targetUserId: integer("target_user_id").references(() => systemUsers.userId),
  signalType: varchar("signal_type", { length: 30 }).notNull(),
  payload: jsonb("payload").$type<Record<string, unknown>>().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

/* ------------------------------------------- 14. OMNI-RATING & FEEDBACK BANK */

export const feedbackRatings = pgTable("feedback_ratings", {
  ratingId: serial("rating_id").primaryKey(),
  targetType: ratingTargetEnum("target_type").notNull(),
  targetId: integer("target_id").notNull(),
  authorUserId: integer("author_user_id").references(() => systemUsers.userId, {
    onDelete: "set null",
  }),
  score: integer("score").notNull(),
  locale: varchar("locale", { length: 10 }).default("ar").notNull(),
  comment: text("comment"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

export const feedbackBank = pgTable("feedback_bank", {
  entryId: serial("entry_id").primaryKey(),
  locale: varchar("locale", { length: 10 }).notNull(),
  category: varchar("category", { length: 60 }).notNull(),
  body: text("body").notNull(),
  sentiment: varchar("sentiment", { length: 20 }).default("NEUTRAL").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

/* ------------------------------------------------------- 15. SECURITY AUDIT */

export const auditLog = pgTable("audit_log", {
  logId: serial("log_id").primaryKey(),
  actorUserId: integer("actor_user_id").references(() => systemUsers.userId, {
    onDelete: "set null",
  }),
  eventType: varchar("event_type", { length: 80 }).notNull(),
  severity: varchar("severity", { length: 20 }).default("INFO").notNull(),
  detail: jsonb("detail").$type<Record<string, unknown>>(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .defaultNow()
    .notNull(),
});

/* ------------------------------------------------------------ DERIVED TYPES */

export type SystemUser = typeof systemUsers.$inferSelect;
export type Category = typeof categories.$inferSelect;
export type LaundryEquipment = typeof laundryEquipment.$inferSelect;
export type EquipmentMedia = typeof equipmentMedia.$inferSelect;
export type AffordableAuction = typeof affordableAuctions.$inferSelect;
export type AuctionBid = typeof auctionBids.$inferSelect;
export type Reservation = typeof reservations.$inferSelect;
export type Order = typeof orders.$inferSelect;
export type EscrowTransaction = typeof escrowTransactions.$inferSelect;
export type ShippingJob = typeof shippingJobs.$inferSelect;
export type MaintenanceTicket = typeof maintenanceTickets.$inferSelect;
export type ConferenceRoom = typeof conferenceRooms.$inferSelect;
export type FeedbackRating = typeof feedbackRatings.$inferSelect;
export type RoleType = (typeof roleTypeEnum.enumValues)[number];
export type LocaleCode = "ar" | "en";
