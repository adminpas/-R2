import { NextResponse } from "next/server";

export type ApiEnvelope<T> =
  | { ok: true; data: T }
  | { ok: false; error: { code: string; messageAr: string; messageEn: string } };

export function ok<T>(data: T, init?: ResponseInit) {
  return NextResponse.json<ApiEnvelope<T>>({ ok: true, data }, init);
}

export function fail(
  code: string,
  messageAr: string,
  messageEn: string,
  status = 400,
) {
  return NextResponse.json<ApiEnvelope<never>>(
    { ok: false, error: { code, messageAr, messageEn } },
    { status },
  );
}

export class HttpError extends Error {
  code: string;
  messageAr: string;
  messageEn: string;
  status: number;
  constructor(
    code: string,
    messageAr: string,
    messageEn: string,
    status = 400,
  ) {
    super(messageEn);
    this.code = code;
    this.messageAr = messageAr;
    this.messageEn = messageEn;
    this.status = status;
  }
}

/** Wraps a route handler, translating thrown domain errors into the envelope. */
export function handler<T>(
  fn: () => Promise<NextResponse<ApiEnvelope<T>> | Response>,
) {
  return fn().catch((error: unknown) => {
    if (error instanceof HttpError) {
      return fail(error.code, error.messageAr, error.messageEn, error.status);
    }
    console.error("[najeeb-api]", error);
    const message = error instanceof Error ? error.message : "unknown";
    return fail(
      "INTERNAL_ERROR",
      "خطأ غير متوقع في الخادم",
      `Unexpected server error: ${message}`,
      500,
    );
  });
}

export function num(value: unknown, fallback = 0): number {
  const parsed = typeof value === "number" ? value : Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

export function str(value: unknown): string {
  return typeof value === "string" ? value.trim() : "";
}

export function money(value: number): string {
  return value.toFixed(2);
}

export async function readJson(request: Request): Promise<Record<string, unknown>> {
  try {
    const body = await request.json();
    return body && typeof body === "object"
      ? (body as Record<string, unknown>)
      : {};
  } catch {
    return {};
  }
}
