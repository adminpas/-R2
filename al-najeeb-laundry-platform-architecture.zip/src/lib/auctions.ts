/**
 * FILE 4 (part C) — SMART QUARTERLY AUCTION SYSTEM.
 * Cost-price, zero-profit project packages for lower-income entrepreneurs.
 * Enforces a 30-day automated timer, a 500 SAR minimum raise and auto-processes
 * the highest bidder at the deadline into the escrow ledger.
 */
import { and, asc, desc, eq, gt, lte, sql } from "drizzle-orm";
import { db } from "@/db";
import { affordableAuctions, auctionBids, escrowTransactions, systemUsers } from "@/db/schema";
import { HttpError } from "./api";
import { LIMITS } from "./config";
import { openEscrow, releaseEscrow } from "./escrow";
import { audit } from "./auth";

export type AuctionWithMeta = {
  auction: typeof affordableAuctions.$inferSelect;
  bidderName: string | null;
  bidCount: number;
};

export async function createAuction(input: {
  packageTitle: string;
  baseCostPrice: number;
  durationDays?: number;
  minimumIncrement?: number;
  items?: string[];
  createdByUserId: number;
  startAt?: Date;
}) {
  const days = Math.min(
    Math.max(input.durationDays ?? LIMITS.AUCTION_DURATION_DAYS, 1),
    LIMITS.AUCTION_DURATION_DAYS,
  );
  const startDate = input.startAt ?? new Date();
  const endDate = new Date(
    startDate.getTime() + days * 24 * 60 * 60 * 1000,
  );
  const increment = Math.max(
    input.minimumIncrement ?? LIMITS.AUCTION_MIN_INCREMENT_SAR,
    LIMITS.AUCTION_MIN_INCREMENT_SAR,
  );
  const [auction] = await db
    .insert(affordableAuctions)
    .values({
      packageTitle: input.packageTitle,
      baseCostPrice: input.baseCostPrice.toFixed(2),
      currentHighestBid: input.baseCostPrice.toFixed(2),
      minimumIncrement: increment.toFixed(2),
      startDate,
      endDate,
      packageDetails: { items: input.items ?? [] },
      createdByUserId: input.createdByUserId,
    })
    .returning();
  await audit({
    actorUserId: input.createdByUserId,
    eventType: "AUCTION_CREATED",
    detail: { auctionId: auction.auctionId, endDate: endDate.toISOString() },
  });
  return auction;
}

export async function listAuctions(onlyOpen = false) {
  const rows = await db
    .select({
      auction: affordableAuctions,
      bidderName: systemUsers.displayNameAr,
      bidCount: sql<number>`(
        select count(*)::int from ${auctionBids}
        where ${auctionBids.auctionId} = ${affordableAuctions.auctionId}
      )`,
    })
    .from(affordableAuctions)
    .leftJoin(systemUsers, eq(systemUsers.userId, affordableAuctions.highestBidderId))
    .where(onlyOpen ? gt(affordableAuctions.endDate, new Date()) : sql`true`)
    .orderBy(asc(affordableAuctions.endDate));
  return rows;
}

export async function auctionDetail(auctionId: number) {
  const [auction] = await db
    .select()
    .from(affordableAuctions)
    .where(eq(affordableAuctions.auctionId, auctionId))
    .limit(1);
  if (!auction) {
    throw new HttpError("AUCTION_NOT_FOUND", "المزاد غير موجود", "Auction not found", 404);
  }
  const bids = await db
    .select({
      bid: auctionBids,
      bidderName: systemUsers.displayNameAr,
      bidderCity: systemUsers.city,
    })
    .from(auctionBids)
    .leftJoin(systemUsers, eq(systemUsers.userId, auctionBids.bidderId))
    .where(eq(auctionBids.auctionId, auctionId))
    .orderBy(desc(auctionBids.amount))
    .limit(50);
  return { auction, bids };
}

export type BidResult =
  | { accepted: true; auction: typeof affordableAuctions.$inferSelect; bidId: number }
  | { accepted: false; reasonAr: string; reasonEn: string; required: number };

export async function placeBid(input: {
  auctionId: number;
  bidderId: number;
  amount: number;
}): Promise<BidResult> {
  const [auction] = await db
    .select()
    .from(affordableAuctions)
    .where(eq(affordableAuctions.auctionId, input.auctionId))
    .limit(1);
  if (!auction) {
    throw new HttpError("AUCTION_NOT_FOUND", "المزاد غير موجود", "Auction not found", 404);
  }
  const now = new Date();
  if (now < auction.startDate) {
    return {
      accepted: false,
      reasonAr: "لم يبدأ المزاد بعد",
      reasonEn: "Auction has not opened yet",
      required: Number(auction.currentHighestBid) + Number(auction.minimumIncrement),
    };
  }
  if (now >= auction.endDate || auction.isProcessed) {
    return {
      accepted: false,
      reasonAr: "انتهى وقت المزاد وتمت المعالجة التلقائية",
      reasonEn: "Auction closed and auto-processed",
      required: 0,
    };
  }
  if (auction.highestBidderId === input.bidderId) {
    return {
      accepted: false,
      reasonAr: "أنت بالفعل صاحب أعلى مزايدة",
      reasonEn: "You already hold the highest bid",
      required: Number(auction.currentHighestBid) + Number(auction.minimumIncrement),
    };
  }

  const minimumNext =
    Number(auction.currentHighestBid) + Number(auction.minimumIncrement);
  if (input.amount + 0.001 < minimumNext) {
    return {
      accepted: false,
      reasonAr: `أقل مزايدة مقبولة هي ${minimumNext.toFixed(2)} ر.س (زيادة ٥٠٠ ر.س على الأقل)`,
      reasonEn: `Minimum accepted bid is ${minimumNext.toFixed(2)} SAR (at least 500 SAR raise)`,
      required: minimumNext,
    };
  }

  const result = await db.transaction(async (tx) => {
    const [locked] = await tx
      .select()
      .from(affordableAuctions)
      .where(eq(affordableAuctions.auctionId, input.auctionId))
      .for("update")
      .limit(1);
    const stillValid =
      locked &&
      !locked.isProcessed &&
      locked.endDate.getTime() > Date.now() &&
      Number(locked.currentHighestBid) + Number(locked.minimumIncrement) <=
        input.amount + 0.001;
    if (!stillValid) return null;

    await tx
      .update(auctionBids)
      .set({ status: "OUTBID" })
      .where(
        and(
          eq(auctionBids.auctionId, input.auctionId),
          eq(auctionBids.status, "ACTIVE"),
        ),
      );
    const [bid] = await tx
      .insert(auctionBids)
      .values({
        auctionId: input.auctionId,
        bidderId: input.bidderId,
        amount: input.amount.toFixed(2),
        status: "ACTIVE",
      })
      .returning();
    const [updated] = await tx
      .update(affordableAuctions)
      .set({
        currentHighestBid: input.amount.toFixed(2),
        highestBidderId: input.bidderId,
      })
      .where(eq(affordableAuctions.auctionId, input.auctionId))
      .returning();
    return { bid, updated };
  });

  if (!result) {
    return {
      accepted: false,
      reasonAr: "تم تغير قيمة المزايدة أثناء العملية، أعد المحاولة",
      reasonEn: "Bid state changed concurrently, please retry",
      required: minimumNext,
    };
  }

  await audit({
    actorUserId: input.bidderId,
    eventType: "AUCTION_BID_PLACED",
    detail: { auctionId: input.auctionId, amount: input.amount },
  });

  return { accepted: true, auction: result.updated, bidId: result.bid.bidId };
}

/**
 * Deadline worker: auto-processes every matured auction, opens escrow on the
 * winning amount and marks the package as handled. Safe to call repeatedly
 * (cron / dashboard pulse / lazy tick).
 */
export async function processMaturedAuctions(actorId = 0) {
  const matured = await db
    .select()
    .from(affordableAuctions)
    .where(
      and(
        eq(affordableAuctions.isProcessed, false),
        lte(affordableAuctions.endDate, new Date()),
      ),
    );

  const processed: number[] = [];
  for (const auction of matured) {
    if (!auction.highestBidderId) {
      await db
        .update(affordableAuctions)
        .set({ isProcessed: true, processedAt: new Date() })
        .where(eq(affordableAuctions.auctionId, auction.auctionId));
      processed.push(auction.auctionId);
      continue;
    }
    const escrow = await openEscrow({
      payerId: auction.highestBidderId,
      payeeMerchantId: auction.createdByUserId,
      grossAmount: Number(auction.currentHighestBid),
      commissionPercentage: 0,
      auctionId: auction.auctionId,
      holdImmediately: true,
    });
    await db
      .update(auctionBids)
      .set({ status: "WON" })
      .where(
        and(
          eq(auctionBids.auctionId, auction.auctionId),
          eq(auctionBids.bidderId, auction.highestBidderId),
        ),
      );
    await db
      .update(affordableAuctions)
      .set({ isProcessed: true, processedAt: new Date(), escrowId: escrow.escrowId })
      .where(eq(affordableAuctions.auctionId, auction.auctionId));
    await releaseEscrow(escrow.escrowId, actorId);
    processed.push(auction.auctionId);
  }
  return processed;
}

export async function auctionLedger() {
  return db
    .select({ escrow: escrowTransactions })
    .from(escrowTransactions)
    .where(sql`${escrowTransactions.auctionId} is not null`)
    .orderBy(desc(escrowTransactions.escrowId))
    .limit(25);
}
