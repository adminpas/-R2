/**
 * FILE 3 (part B) — AUTHENTICATION, MFA + 1-DEVICE HARDWARE BINDING ENGINE.
 * Every privileged session is bound to exactly one physical device identity.
 */
import { cookies, headers } from "next/headers";
import { and, eq, isNull, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  auditLog,
  authSessions,
  deviceBindings,
  systemUsers,
  type RoleType,
  type SystemUser,
} from "@/db/schema";
import {
  DEVICE_COOKIE,
  LIMITS,
  SESSION_COOKIE,
} from "./config";
import {
  hashPassword,
  hashToken,
  hardwareFingerprint,
  newOpaqueToken,
  signBiometricToken,
  verifyPassword,
} from "./crypto";
import { HttpError } from "./api";
import { merchantRoot } from "./storage";

export type SessionContext = {
  user: SystemUser;
  sessionId: number;
  hardwareDeviceId: string | null;
  biometricVerified: boolean;
};

export async function audit(entry: {
  actorUserId?: number | null;
  eventType: string;
  severity?: "INFO" | "WARN" | "CRITICAL";
  detail?: Record<string, unknown>;
}) {
  await db.insert(auditLog).values({
    actorUserId: entry.actorUserId ?? null,
    eventType: entry.eventType,
    severity: entry.severity ?? "INFO",
    detail: entry.detail ?? {},
  });
}

async function clientMeta() {
  const h = await headers();
  return {
    ip:
      h.get("x-forwarded-for")?.split(",")[0]?.trim() ??
      h.get("x-real-ip") ??
      "127.0.0.1",
    userAgent: h.get("user-agent") ?? "unknown",
  };
}

export function credentialError(): HttpError {
  return new HttpError(
    "INVALID_CREDENTIALS",
    "اسم المستخدم أو كلمة المرور غير صحيحة",
    "Invalid username or password",
    401,
  );
}

/** Creates the pending account row (is_active=false until Super-Admin gates it). */
export async function registerAccount(input: {
  username: string;
  password: string;
  roleType: RoleType;
  displayNameAr?: string;
  displayNameEn?: string;
  phone?: string;
  city?: string;
  autoActivate?: boolean;
}): Promise<SystemUser> {
  const existing = await db
    .select({ id: systemUsers.userId })
    .from(systemUsers)
    .where(eq(systemUsers.username, input.username))
    .limit(1);
  if (existing.length > 0) {
    throw new HttpError(
      "USERNAME_TAKEN",
      "اسم المستخدم محجوز مسبقاً",
      "Username already reserved",
      409,
    );
  }
  const [created] = await db
    .insert(systemUsers)
    .values({
      username: input.username,
      passwordHash: hashPassword(input.password),
      roleType: input.roleType,
      isActive: input.autoActivate ?? false,
      displayNameAr: input.displayNameAr ?? input.username,
      displayNameEn: input.displayNameEn ?? input.username,
      phone: input.phone,
      city: input.city,
      merchantSsdFolder:
        input.roleType === "MERCHANT"
          ? merchantRoot(0)
          : null,
    })
    .returning();
  await audit({
    actorUserId: created.userId,
    eventType: "ACCOUNT_REGISTERED",
    detail: { roleType: input.roleType },
  });
  return created;
}

/**
 * Binds (or validates) the first physical hardware identity of an account.
 * A second distinct device is always rejected: no account sharing.
 */
export async function bindHardwareDevice(input: {
  user: SystemUser;
  rawFingerprint: string;
  deviceLabel?: string;
  userAgent?: string;
  allowBind: boolean;
}): Promise<{ hardwareDeviceId: string; locked: boolean; violation: boolean }> {
  const hardwareDeviceId = hardwareFingerprint(input.rawFingerprint);

  const [existing] = await db
    .select()
    .from(deviceBindings)
    .where(eq(deviceBindings.hardwareDeviceId, hardwareDeviceId))
    .limit(1);

  if (existing && existing.userId !== input.user.userId) {
    await db
      .update(deviceBindings)
      .set({ violationCount: sql`${deviceBindings.violationCount} + 1` })
      .where(eq(deviceBindings.bindingId, existing.bindingId));
    await audit({
      actorUserId: input.user.userId,
      eventType: "DEVICE_LOCK_VIOLATION",
      severity: "CRITICAL",
      detail: {
        hardwareDeviceId,
        ownerUserId: existing.userId,
        userAgent: input.userAgent,
      },
    });
    return { hardwareDeviceId, locked: false, violation: true };
  }

  if (!existing && input.user.hardwareDeviceId && input.user.hardwareDeviceId !== hardwareDeviceId) {
    await audit({
      actorUserId: input.user.userId,
      eventType: "DEVICE_LOCK_VIOLATION",
      severity: "CRITICAL",
      detail: {
        expected: input.user.hardwareDeviceId,
        received: hardwareDeviceId,
      },
    });
    return { hardwareDeviceId, locked: false, violation: true };
  }

  if (!existing) {
    if (!input.allowBind) {
      return { hardwareDeviceId, locked: false, violation: true };
    }
    await db.insert(deviceBindings).values({
      hardwareDeviceId,
      userId: input.user.userId,
      deviceLabel: input.deviceLabel ?? "Al-Najeeb Terminal",
      deviceSignature: input.userAgent,
      approved: true,
    });
    await db
      .update(systemUsers)
      .set({ hardwareDeviceId })
      .where(eq(systemUsers.userId, input.user.userId));
    await audit({
      actorUserId: input.user.userId,
      eventType: "DEVICE_LOCKED",
      detail: { hardwareDeviceId },
    });
    return { hardwareDeviceId, locked: true, violation: false };
  }

  await db
    .update(deviceBindings)
    .set({ lastSeenAt: new Date(), approved: true, revokedAt: null })
    .where(eq(deviceBindings.bindingId, existing.bindingId));
  return { hardwareDeviceId, locked: true, violation: false };
}

export async function issueSession(input: {
  user: SystemUser;
  hardwareDeviceId: string | null;
  biometricVerified: boolean;
  locale?: string;
}): Promise<{ token: string; expiresAt: Date }> {
  const token = newOpaqueToken();
  const expiresAt = new Date(
    Date.now() + LIMITS.SESSION_TTL_HOURS * 60 * 60 * 1000,
  );
  const meta = await clientMeta();
  await db.insert(authSessions).values({
    userId: input.user.userId,
    tokenHash: hashToken(token),
    hardwareDeviceId: input.hardwareDeviceId,
    biometricVerified: input.biometricVerified,
    locale: input.locale ?? "ar",
    ipAddress: meta.ip,
    userAgent: meta.userAgent,
    expiresAt,
  });
  await db
    .update(systemUsers)
    .set({ lastLoginAt: new Date() })
    .where(eq(systemUsers.userId, input.user.userId));

  const jar = await cookies();
  const secure = process.env.NODE_ENV === "production";
  jar.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure,
    path: "/",
    expires: expiresAt,
  });
  if (input.hardwareDeviceId) {
    jar.set(DEVICE_COOKIE, input.hardwareDeviceId, {
      httpOnly: false,
      sameSite: "lax",
      secure,
      path: "/",
      expires: expiresAt,
    });
  }
  return { token, expiresAt };
}

export async function destroySession() {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (token) {
    await db
      .update(authSessions)
      .set({ revokedAt: new Date() })
      .where(eq(authSessions.tokenHash, hashToken(token)));
  }
  jar.delete(SESSION_COOKIE);
}

export async function getSessionContext(): Promise<SessionContext | null> {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const [row] = await db
    .select({ session: authSessions, user: systemUsers })
    .from(authSessions)
    .innerJoin(systemUsers, eq(systemUsers.userId, authSessions.userId))
    .where(
      and(
        eq(authSessions.tokenHash, hashToken(token)),
        isNull(authSessions.revokedAt),
      ),
    )
    .limit(1);
  if (!row) return null;
  if (row.session.expiresAt.getTime() < Date.now()) return null;
  if (!row.user.isActive) return null;
  return {
    user: row.user,
    sessionId: row.session.sessionId,
    hardwareDeviceId: row.session.hardwareDeviceId,
    biometricVerified: row.session.biometricVerified,
  };
}

export async function requireUser(roles?: RoleType[]): Promise<SessionContext> {
  const ctx = await getSessionContext();
  if (!ctx) {
    throw new HttpError(
      "UNAUTHENTICATED",
      "الجلسة غير صالحة، يرجى تسجيل الدخول",
      "Session invalid, please sign in",
      401,
    );
  }
  if (roles && roles.length > 0 && !roles.includes(ctx.user.roleType)) {
    throw new HttpError(
      "FORBIDDEN",
      "لا تملك صلاحية الوصول لهذه العملية",
      "Insufficient privileges for this operation",
      403,
    );
  }
  return ctx;
}

/** Privileged write operations additionally require a biometric handshake. */
export async function requireMfa(roles: RoleType[]): Promise<SessionContext> {
  const ctx = await requireUser(roles);
  if (!ctx.biometricVerified) {
    throw new HttpError(
      "MFA_REQUIRED",
      "يتطلب هذا الإجراء توثيق البصمة (FaceID / TouchID)",
      "This action requires the biometric handshake (FaceID / TouchID)",
      428,
    );
  }
  return ctx;
}

/** Strict merchant tenant isolation guard. */
export async function requireMerchantScope(
  merchantId: number,
): Promise<SessionContext> {
  const ctx = await requireUser(["MERCHANT", "SUPER_ADMIN", "ASSISTANT_ADMIN"]);
  const privileged =
    ctx.user.roleType === "SUPER_ADMIN" ||
    ctx.user.roleType === "ASSISTANT_ADMIN";
  if (!privileged && ctx.user.userId !== merchantId) {
    await audit({
      actorUserId: ctx.user.userId,
      eventType: "TENANT_ISOLATION_BREACH",
      severity: "CRITICAL",
      detail: { attemptedMerchantId: merchantId },
    });
    throw new HttpError(
      "TENANT_FORBIDDEN",
      "محاولة عبور حدود المستأجر — تم الحجب والتسجيل",
      "Cross-tenant access blocked and logged",
      403,
    );
  }
  return ctx;
}

export function biometricTokenFor(user: SystemUser, deviceId: string): string {
  return signBiometricToken(user.userId, deviceId);
}

export async function authenticate(
  username: string,
  password: string,
): Promise<SystemUser> {
  const [user] = await db
    .select()
    .from(systemUsers)
    .where(eq(systemUsers.username, username))
    .limit(1);
  if (!user || !verifyPassword(password, user.passwordHash)) {
    throw credentialError();
  }
  return user;
}
