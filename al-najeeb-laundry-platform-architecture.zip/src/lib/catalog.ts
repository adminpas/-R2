import { and, avg, count, desc, eq, ilike, or, sql, type SQL } from "drizzle-orm";
import { db } from "@/db";
import {
  affordableAuctions,
  categories,
  equipmentMedia,
  feedbackRatings,
  laundryEquipment,
  orders,
  shippingJobs,
  systemUsers,
} from "@/db/schema";
import { ensureSeeded } from "./seed";

export type CatalogFilters = {
  q?: string;
  categoryId?: number;
  availability?: string;
  liveOnly?: boolean;
};

export async function getCategories() {
  await ensureSeeded();
  return db
    .select({
      category: categories,
      itemCount: sql<number>`(
        select count(*)::int from ${laundryEquipment}
        where ${laundryEquipment.categoryId} = ${categories.categoryId}
      )`,
    })
    .from(categories)
    .orderBy(categories.sortOrder, categories.categoryId);
}

export async function getEquipment(filters: CatalogFilters = {}) {
  await ensureSeeded();
  const conditions: SQL[] = [];
  if (filters.q) {
    const like = `%${filters.q}%`;
    const cond = or(
      ilike(laundryEquipment.titleAr, like),
      ilike(laundryEquipment.titleEn, like),
      ilike(laundryEquipment.descriptionAr, like),
    );
    if (cond) conditions.push(cond);
  }
  if (filters.categoryId) {
    conditions.push(eq(laundryEquipment.categoryId, filters.categoryId));
  }
  if (filters.availability) {
    conditions.push(
      sql`${laundryEquipment.availabilityStatus}::text = ${filters.availability}`,
    );
  }
  if (filters.liveOnly) {
    conditions.push(eq(laundryEquipment.isLiveShowroom, true));
  }

  return db
    .select({
      equipment: laundryEquipment,
      categoryNameAr: categories.categoryNameAr,
      merchantNameAr: systemUsers.displayNameAr,
      city: systemUsers.city,
    })
    .from(laundryEquipment)
    .leftJoin(categories, eq(categories.categoryId, laundryEquipment.categoryId))
    .leftJoin(systemUsers, eq(systemUsers.userId, laundryEquipment.merchantId))
    .where(conditions.length > 0 ? and(...conditions) : sql`true`)
    .orderBy(desc(laundryEquipment.isLiveShowroom), desc(laundryEquipment.equipmentId))
    .limit(60);
}

export type TrailerCard = {
  equipmentId: number;
  titleAr: string;
  price: string;
  poster: string | null;
  videoUrl: string | null;
  logicalPath: string | null;
  live: boolean;
  status: string;
};

export async function getTrailers(): Promise<TrailerCard[]> {
  await ensureSeeded();
  const rows = await db
    .select({
      equipment: laundryEquipment,
      media: equipmentMedia,
    })
    .from(equipmentMedia)
    .innerJoin(
      laundryEquipment,
      eq(laundryEquipment.equipmentId, equipmentMedia.equipmentId),
    )
    .where(
      and(
        eq(equipmentMedia.isPromotional, true),
        eq(laundryEquipment.availabilityStatus, "AVAILABLE"),
      ),
    )
    .orderBy(desc(laundryEquipment.equipmentId))
    .limit(8);

  return rows.map((row) => ({
    equipmentId: row.equipment.equipmentId,
    titleAr: row.equipment.titleAr,
    price: row.equipment.price,
    poster: row.media.posterUrl ?? row.equipment.posterImagePath ?? null,
    videoUrl: row.media.remoteUrl ?? null,
    logicalPath: row.media.logicalPath,
    live: row.equipment.isLiveShowroom,
    status: row.equipment.equipmentStatus,
  }));
}

export async function getEquipmentDetail(equipmentId: number) {
  await ensureSeeded();
  const [row] = await db
    .select({
      equipment: laundryEquipment,
      category: categories,
      merchant: {
        userId: systemUsers.userId,
        displayNameAr: systemUsers.displayNameAr,
        city: systemUsers.city,
        phone: systemUsers.phone,
      },
    })
    .from(laundryEquipment)
    .leftJoin(categories, eq(categories.categoryId, laundryEquipment.categoryId))
    .leftJoin(systemUsers, eq(systemUsers.userId, laundryEquipment.merchantId))
    .where(eq(laundryEquipment.equipmentId, equipmentId))
    .limit(1);
  if (!row) return null;

  const media = await db
    .select()
    .from(equipmentMedia)
    .where(eq(equipmentMedia.equipmentId, equipmentId))
    .orderBy(desc(equipmentMedia.mediaId));

  const [rating] = await db
    .select({ average: avg(feedbackRatings.score), total: count() })
    .from(feedbackRatings)
    .where(
      and(
        eq(feedbackRatings.targetType, "EQUIPMENT"),
        eq(feedbackRatings.targetId, equipmentId),
      ),
    );

  const ratings = await db
    .select({ rating: feedbackRatings, authorNameAr: systemUsers.displayNameAr })
    .from(feedbackRatings)
    .leftJoin(systemUsers, eq(systemUsers.userId, feedbackRatings.authorUserId))
    .where(
      and(
        eq(feedbackRatings.targetType, "EQUIPMENT"),
        eq(feedbackRatings.targetId, equipmentId),
      ),
    )
    .orderBy(desc(feedbackRatings.ratingId))
    .limit(8);

  return {
    ...row,
    media,
    rating: {
      average: rating?.average ? Number(rating.average) : 0,
      total: rating?.total ?? 0,
    },
    ratings,
  };
}

export async function getShowroomStats() {
  await ensureSeeded();
  const [items] = await db
    .select({
      total: count(),
      live: sql<number>`coalesce(sum(case when ${laundryEquipment.isLiveShowroom} then 1 else 0 end), 0)::int`,
      sold: sql<number>`coalesce(sum(case when ${laundryEquipment.availabilityStatus}::text = 'SOLD' then 1 else 0 end), 0)::int`,
      inventory: sql<string>`coalesce(sum(${laundryEquipment.price}), 0)::text`,
    })
    .from(laundryEquipment);
  const [auctionStats] = await db
    .select({
      open: count(),
      highest: sql<string>`coalesce(max(${affordableAuctions.currentHighestBid}), 0)::text`,
    })
    .from(affordableAuctions);
  const [orderStats] = await db
    .select({ total: count(), value: sql<string>`coalesce(sum(${orders.totalAmount}), 0)::text` })
    .from(orders);
  const [delivery] = await db
    .select({ total: count() })
    .from(shippingJobs);
  return {
    items: items?.total ?? 0,
    liveFeeds: items?.live ?? 0,
    sold: items?.sold ?? 0,
    inventory: Number(items?.inventory ?? 0),
    openAuctions: auctionStats?.open ?? 0,
    topBid: Number(auctionStats?.highest ?? 0),
    orders: orderStats?.total ?? 0,
    orderValue: Number(orderStats?.value ?? 0),
    deliveries: delivery?.total ?? 0,
  };
}

export const STATUS_LABELS: Record<string, { ar: string; tone: string }> = {
  NEW_4K: { ar: "جديد 4K", tone: "bg-teal-400/15 text-teal-200 border-teal-300/30" },
  LIKE_NEW_BLUERAY: { ar: "كالجديد BlueRay", tone: "bg-sky-400/15 text-sky-200 border-sky-300/30" },
  USED_EXCELLENT_HD: { ar: "مستعمل ممتاز HD", tone: "bg-amber-400/15 text-amber-200 border-amber-300/30" },
  REFURBISHED: { ar: "مُجدد بالكامل", tone: "bg-fuchsia-400/15 text-fuchsia-200 border-fuchsia-300/30" },
};

export const AVAILABILITY_LABELS: Record<string, { ar: string; tone: string }> = {
  AVAILABLE: { ar: "متاح", tone: "bg-emerald-400/15 text-emerald-200 border-emerald-300/30" },
  HOLD_24H: { ar: "محجوز ٢٤ ساعة", tone: "bg-amber-400/15 text-amber-200 border-amber-300/30" },
  SOLD: { ar: "تم البيع", tone: "bg-rose-400/15 text-rose-200 border-rose-300/30" },
};
