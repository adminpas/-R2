/**
 * AL-NAJEEB PLATFORM — Core configuration (Hybrid Local-Cloud).
 * Server: Jeddah, Al-Khumra, KSA. Media lives on the local SSD array.
 */
import path from "node:path";

/** Logical root of the local SSD as mounted on the Jeddah (Al-Khumra) node. */
export const SSD_LOGICAL_ROOT =
  process.env.AL_NAJEEB_SSD_LOGICAL_ROOT ?? "/mnt/storage/Al_Najeeb_SSD";

/**
 * Physical root used by this runtime. In production on the Al-Khumra node the
 * SSD is mounted at SSD_LOGICAL_ROOT; in sandbox/CI we fall back to a project
 * local mirror so the streaming controller stays fully functional.
 */
export const SSD_PHYSICAL_ROOT =
  process.env.AL_NAJEEB_SSD_ROOT ?? path.join(process.cwd(), ".al-najeeb-ssd");

export const TENANT_ROOTS = {
  CATALOG: "01_Showroom_Catalog",
  TRAILERS: "02_Trailers_4K",
  LIVE: "03_Live_Feeds",
  SPARE_PARTS: "04_Spare_Parts",
  AUCTIONS: "05_Affordable_Auctions",
  TICKETS: "06_Maintenance_Evidence",
  ESCROW: "07_Escrow_Documents",
} as const;

/** Hard business ceilings mandated by the blueprint. */
export const LIMITS = {
  MAX_COMMISSION_PERCENTAGE: 15,
  AUCTION_MIN_INCREMENT_SAR: 500,
  AUCTION_DURATION_DAYS: 30,
  RESERVATION_HOLD_HOURS: 24,
  RESERVATION_DOWNPAYMENT_RATIO: 0.25,
  MAX_UPLOAD_BYTES: 512 * 1024 * 1024,
  SESSION_TTL_HOURS: 12,
} as const;

export const SESSION_COOKIE = "najeeb_session";
export const DEVICE_COOKIE = "najeeb_device";

export const DEFAULT_LOCALE = "ar";
export const SUPPORTED_LOCALES = [
  { code: "ar", labelAr: "العربية", labelEn: "Arabic", dir: "rtl" },
  { code: "en", labelAr: "الإنجليزية", labelEn: "English", dir: "ltr" },
  { code: "ur", labelAr: "الأردية", labelEn: "Urdu", dir: "rtl" },
  { code: "fr", labelAr: "الفرنسية", labelEn: "French", dir: "ltr" },
] as const;

export const COMPANY = {
  nameAr: "معرض شركة النجيب المتطورة لمعدات المغاسل",
  nameEn: "Al-Najeeb Advanced Laundry Equipment Showroom",
  adminAr: "لوحة تحكم نظام معرض شركة النجيب المتطورة لمعدات المغاسل",
  merchantAr: "لوحة تحكم نظام قطع الغيار",
  logisticsAr: "لوحة تحكم شركة التوصيل",
  techAr: "لوحة تحكم قسم التركيب والصيانة",
  serverLocation: "جدة — الخمرة، المملكة العربية السعودية",
  storageLabel: "تخزين محلي SSD — Al_Najeeb_SSD",
} as const;
