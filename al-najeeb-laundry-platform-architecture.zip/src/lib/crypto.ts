/**
 * FILE 3 (part A) — Cryptographic core:
 * password hashing, session token derivation, biometric handshake signatures
 * and the hardware fingerprint digest used by the 1-Device Lock engine.
 */
import {
  createHmac,
  createHash,
  randomBytes,
  randomUUID,
  scryptSync,
  timingSafeEqual,
} from "node:crypto";

const SECRET =
  process.env.SESSION_SECRET ??
  "al-najeeb-jeddah-alkhumra-hala-soft-local-dev-secret";

const KEYLEN = 64;

/** scrypt password hash -> `scrypt$<salt>$<hash>` */
export function hashPassword(plain: string): string {
  const salt = randomBytes(16).toString("hex");
  const derived = scryptSync(plain, salt, KEYLEN).toString("hex");
  return `scrypt$${salt}$${derived}`;
}

export function verifyPassword(plain: string, stored: string): boolean {
  const parts = stored.split("$");
  if (parts.length !== 3 || parts[0] !== "scrypt") return false;
  const [, salt, expected] = parts;
  const derived = scryptSync(plain, salt, KEYLEN).toString("hex");
  const a = Buffer.from(derived, "hex");
  const b = Buffer.from(expected, "hex");
  if (a.length !== b.length) return false;
  return timingSafeEqual(a, b);
}

export function newOpaqueToken(): string {
  return randomBytes(48).toString("base64url");
}

/** Only the HMAC digest of a session token is persisted. */
export function hashToken(token: string): string {
  return createHmac("sha256", SECRET).update(token).digest("hex");
}

/**
 * FaceID / TouchID handshake: the browser supplies an attestation blob, we bind
 * it to the user + device with an HMAC and store the signature as the
 * biometric token. Replay requires both the blob and the device id.
 */
export function signBiometricToken(userId: number, deviceId: string): string {
  return createHmac("sha512", SECRET)
    .update(`${userId}::${deviceId}::biometric`)
    .digest("base64url");
}

export function verifyBiometricToken(
  userId: number,
  deviceId: string,
  token: string,
): boolean {
  const expected = signBiometricToken(userId, deviceId);
  const a = Buffer.from(expected);
  const b = Buffer.from(token ?? "");
  if (a.length !== b.length) return false;
  return timingSafeEqual(a, b);
}

/**
 * 1-Device Lock hardware identity.
 * The client posts a raw hardware attestation (canvas + cores + platform +
 * storage serial probe). We never store the raw probe, only its digest.
 */
export function hardwareFingerprint(raw: string): string {
  return createHash("sha256")
    .update(`NAJEEB-HW::${raw}`)
    .digest("hex")
    .slice(0, 48)
    .toUpperCase();
}

export function newEscrowCode(prefix: string): string {
  return `${prefix}-${Date.now().toString(36).toUpperCase()}-${randomBytes(3)
    .toString("hex")
    .toUpperCase()}`;
}

export function newRoomId(): string {
  return randomUUID().replace(/-/g, "").slice(0, 24);
}

export function newPeerId(): string {
  return `peer_${randomBytes(8).toString("hex")}`;
}
