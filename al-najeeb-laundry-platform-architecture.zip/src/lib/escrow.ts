/**
 * FILE 4 (part B) — SMART ESCROW LEDGER.
 * Funds are held by the platform, released to the merchant net of commission,
 * and refunded automatically when a 24h hold or an auction deposit fails.
 */
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { escrowTransactions } from "@/db/schema";
import { HttpError } from "./api";
import { newEscrowCode } from "./crypto";
import { computeSplit } from "./finance";
import { audit } from "./auth";

export type EscrowStage =
  | "INITIATED"
  | "FUNDS_HELD"
  | "RELEASED"
  | "REFUNDED"
  | "DISPUTED";

export async function openEscrow(input: {
  payerId: number;
  payeeMerchantId?: number | null;
  grossAmount: number;
  commissionPercentage: number;
  orderId?: number | null;
  reservationId?: number | null;
  auctionId?: number | null;
  paymentMethod?: string;
  paymentReference?: string;
  holdImmediately?: boolean;
}) {
  const split = computeSplit(input.grossAmount, input.commissionPercentage);
  const escrowCode = newEscrowCode("ESC");
  const [row] = await db
    .insert(escrowTransactions)
    .values({
      escrowCode,
      orderId: input.orderId ?? null,
      reservationId: input.reservationId ?? null,
      auctionId: input.auctionId ?? null,
      payerId: input.payerId,
      payeeMerchantId: input.payeeMerchantId ?? null,
      grossAmount: split.price.toFixed(2),
      commissionPercentage: split.commissionPercentage.toFixed(2),
      commissionAmount: split.commissionAmount.toFixed(2),
      netAmount: split.netToMerchant.toFixed(2),
      stage: input.holdImmediately === false ? "INITIATED" : "FUNDS_HELD",
      paymentMethod: input.paymentMethod ?? "MADA_LOCAL_GATEWAY",
      paymentReference:
        input.paymentReference ?? `${escrowCode}-AUTH-${Date.now()}`,
    })
    .returning();
  await audit({
    actorUserId: input.payerId,
    eventType: "ESCROW_OPENED",
    detail: { escrowCode, gross: split.price, stage: row.stage },
  });
  return row;
}

export async function releaseEscrow(escrowId: number, actorId: number) {
  const [row] = await db
    .update(escrowTransactions)
    .set({ stage: "RELEASED", releasedAt: new Date() })
    .where(eq(escrowTransactions.escrowId, escrowId))
    .returning();
  if (!row) throw new HttpError("ESCROW_NOT_FOUND", "الضمان غير موجود", "Escrow not found", 404);
  await audit({
    actorUserId: actorId,
    eventType: "ESCROW_RELEASED",
    detail: { escrowCode: row.escrowCode, net: row.netAmount },
  });
  return row;
}

export async function refundEscrow(escrowId: number, actorId: number, reason: string) {
  const [row] = await db
    .update(escrowTransactions)
    .set({ stage: "REFUNDED", refundedAt: new Date() })
    .where(eq(escrowTransactions.escrowId, escrowId))
    .returning();
  if (!row) throw new HttpError("ESCROW_NOT_FOUND", "الضمان غير موجود", "Escrow not found", 404);
  await audit({
    actorUserId: actorId,
    eventType: "ESCROW_REFUNDED",
    severity: "WARN",
    detail: { escrowCode: row.escrowCode, reason },
  });
  return row;
}

export async function escrowSummary() {
  const [row] = await db
    .select({
      held: sql<string>`coalesce(sum(case when ${escrowTransactions.stage} = 'FUNDS_HELD' then ${escrowTransactions.grossAmount} else 0 end), 0)`,
      released: sql<string>`coalesce(sum(case when ${escrowTransactions.stage} = 'RELEASED' then ${escrowTransactions.netAmount} else 0 end), 0)`,
      commission: sql<string>`coalesce(sum(${escrowTransactions.commissionAmount}), 0)`,
      refunded: sql<string>`coalesce(sum(case when ${escrowTransactions.stage} = 'REFUNDED' then ${escrowTransactions.grossAmount} else 0 end), 0)`,
    })
    .from(escrowTransactions);
  return {
    heldSar: Number(row?.held ?? 0),
    releasedSar: Number(row?.released ?? 0),
    commissionSar: Number(row?.commission ?? 0),
    refundedSar: Number(row?.refunded ?? 0),
  };
}
