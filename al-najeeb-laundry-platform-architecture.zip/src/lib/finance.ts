/**
 * FILE 4 (part A) — CHECKOUT + SMART ESCROW MATH.
 * Dynamic auto-commission with a hard 15% ceiling and the 25% (one-quarter)
 * downpayment rule that powers the 24h live-showroom reservation.
 */
import { LIMITS } from "./config";

export function clampCommission(input: number): number {
  if (!Number.isFinite(input) || input <= 0) return LIMITS.MAX_COMMISSION_PERCENTAGE;
  return Math.min(
    Number(input.toFixed(2)),
    LIMITS.MAX_COMMISSION_PERCENTAGE,
  );
}

export type SplitResult = {
  price: number;
  commissionPercentage: number;
  commissionAmount: number;
  netToMerchant: number;
  downpaymentAmount: number;
  remainingAmount: number;
};

export function computeSplit(
  price: number,
  commissionPercentageInput: number,
): SplitResult {
  const commissionPercentage = clampCommission(commissionPercentageInput);
  const commissionAmount =
    Math.round(price * (commissionPercentage / 100) * 100) / 100;
  const netToMerchant = Math.round((price - commissionAmount) * 100) / 100;
  const downpaymentAmount =
    Math.round(
      price * LIMITS.RESERVATION_DOWNPAYMENT_RATIO * 100,
    ) / 100;
  const remainingAmount = Math.round((price - downpaymentAmount) * 100) / 100;
  return {
    price,
    commissionPercentage,
    commissionAmount,
    netToMerchant,
    downpaymentAmount,
    remainingAmount,
  };
}

export function requiredDownpayment(price: number): number {
  return computeSplit(price, LIMITS.MAX_COMMISSION_PERCENTAGE).downpaymentAmount;
}

export function assertDownpaymentAtLeastQuarter(
  price: number,
  paid: number,
): { valid: boolean; required: number } {
  const required = requiredDownpayment(price);
  return { valid: paid + 0.001 >= required, required };
}
