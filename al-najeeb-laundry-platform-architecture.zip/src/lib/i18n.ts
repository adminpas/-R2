/**
 * OMNI-RATING LOCALIZATION LAYER
 * Arabic UI by default, instantly swappable to English / Urdu / French with an
 * inline localized feedback bank.
 */
import { SUPPORTED_LOCALES } from "./config";
export { SUPPORTED_LOCALES };

export type Locale = "ar" | "en" | "ur" | "fr";

type Dict = Record<string, { ar: string; en: string; ur?: string; fr?: string }>;

export const DICT: Dict = {
  brandShort: { ar: "النجيب المتطورة", en: "Al-Najeeb Advanced" },
  brandFull: {
    ar: "معرض شركة النجيب المتطورة لمعدات المغاسل",
    en: "Al-Najeeb Advanced Laundry Equipment Showroom",
  },
  navShowroom: { ar: "المعرض", en: "Showroom" },
  navAuctions: { ar: "المزادات", en: "Auctions" },
  navSupport: { ar: "الدعم الفني المباشر", en: "Live Tech Support" },
  navDashboard: { ar: "لوحات التحكم", en: "Control Panels" },
  navLogin: { ar: "تسجيل الدخول", en: "Sign in" },
  navJoin: { ar: "حساب جديد", en: "Create account" },
  navLogout: { ar: "خروج", en: "Sign out" },
  newArrivals: { ar: "وصل حديثاً — إعلانات ترويجية", en: "New arrivals — promo trailers" },
  liveShowroom: { ar: "البث المباشر للمعرض", en: "Live showroom feed" },
  categories: { ar: "الأقسام", en: "Categories" },
  allCategories: { ar: "كل الأقسام", en: "All categories" },
  searchPlaceholder: { ar: "ابحث عن مغسلة، مجفف، طبلعة…", en: "Search washers, dryers, ironers…" },
  price: { ar: "السعر", en: "Price" },
  sar: { ar: "ر.س", en: "SAR" },
  reserve24h: { ar: "حجز 24 ساعة", en: "Reserve 24h" },
  downpayment: { ar: "الدفعة المقدمة (٢٥٪)", en: "Downpayment (25%)" },
  checkout: { ar: "إتمام الشراء", en: "Checkout" },
  specs: { ar: "المواصفات", en: "Specifications" },
  trailer: { ar: "الإعلان الترويجي", en: "Promo trailer" },
  status: { ar: "الحالة", en: "Status" },
  statusNEW_4K: { ar: "جديد 4K", en: "New 4K" },
  statusLIKE_NEW_BLUERAY: { ar: "كالجديد BlueRay", en: "Like-new BlueRay" },
  statusUSED_EXCELLENT_HD: { ar: "مستعمل ممتاز HD", en: "Used excellent HD" },
  statusREFURBISHED: { ar: "مُجدد بالكامل", en: "Refurbished" },
  availAVAILABLE: { ar: "متاح", en: "Available" },
  availHOLD_24H: { ar: "محجوز ٢٤ ساعة", en: "On 24h hold" },
  availSOLD: { ar: "تم البيع", en: "Sold" },
  auctionTitle: { ar: "المزادات الذكية — باقات التكلفة", en: "Smart auctions — cost-price packages" },
  auctionBase: { ar: "سعر التكلفة", en: "Cost price" },
  auctionHighest: { ar: "أعلى مزايدة", en: "Highest bid" },
  auctionIncrement: { ar: "أقل زيادة ٥٠٠ ر.س", en: "Min raise 500 SAR" },
  placeBid: { ar: "زايد الآن", en: "Place bid" },
  timeLeft: { ar: "الوقت المتبقي", en: "Time left" },
  days: { ar: "يوم", en: "d" },
  hours: { ar: "ساعة", en: "h" },
  minutes: { ar: "دقيقة", en: "m" },
  login: { ar: "دخول", en: "Sign in" },
  username: { ar: "اسم المستخدم", en: "Username" },
  password: { ar: "كلمة المرور", en: "Password" },
  deviceId: { ar: "بصمة الجهاز (قفل الجهاز الواحد)", en: "Device fingerprint (1-device lock)" },
  biometric: { ar: "توثيق البصمة FaceID / TouchID", en: "FaceID / TouchID handshake" },
  submit: { ar: "إرسال", en: "Submit" },
  ratingAsk: { ar: "قيّم تجربتك", en: "Rate your experience" },
  feedbackBank: { ar: "بنك الملاحظات", en: "Feedback bank" },
  send: { ar: "إرسال التقييم", en: "Send rating" },
  aiVision: { ar: "التشخيص بالكاميرا (رؤية ذكية)", en: "AI camera vision diagnostics" },
  openRoom: { ar: "افتح غرفة مؤتمر", en: "Open conference room" },
  merchantPanel: { ar: "لوحة تحكم نظام قطع الغيار", en: "Spare parts control panel" },
  adminPanel: {
    ar: "لوحة تحكم نظام معرض شركة النجيب المتطورة لمعدات المغاسل",
    en: "Al-Najeeb Super Admin control panel",
  },
  logisticsPanel: { ar: "لوحة تحكم شركة التوصيل", en: "Logistics control panel" },
  techPanel: { ar: "لوحة تحكم قسم التركيب والصيانة", en: "Installation & maintenance panel" },
  pendingApproval: { ar: "بانتظار موافقة الإدارة", en: "Pending admin approval" },
  storageRoot: { ar: "جذر التخزين المحلي", en: "Local storage root" },
  upload: { ar: "رفع إلى SSD", en: "Upload to SSD" },
  noItems: { ar: "لا توجد عناصر مطابقة", en: "No matching items" },
  commission: { ar: "العمولة", en: "Commission" },
  escrow: { ar: "الضمان (Escrow)", en: "Escrow" },
  orders: { ar: "الطلبات", en: "Orders" },
  tickets: { ar: "طلبات الصيانة", en: "Maintenance tickets" },
  shippingJobs: { ar: "مهام التوصيل", en: "Delivery jobs" },
  save: { ar: "حفظ", en: "Save" },
  titleAr: { ar: "العنوان (عربي)", en: "Title (Arabic)" },
  addItem: { ar: "إضافة معدة", en: "Add equipment" },
  deviceLockedNote: {
    ar: "لوحتك مقفلة على هذا الجهاز فقط — أي محاولة مشاركة الحساب تُسجَّل وتُحجب.",
    en: "Your panel is locked to this device only — sharing attempts are logged and blocked.",
  },
};

export function tr(locale: Locale, key: keyof Dict | string): string {
  const entry = DICT[key];
  if (!entry) return String(key);
  const value = entry[locale] ?? entry.ar;
  return value ?? entry.en;
}

export function dirFor(locale: Locale): "rtl" | "ltr" {
  return locale === "en" || locale === "fr" ? "ltr" : "rtl";
}

export function formatSar(value: string | number, locale: Locale): string {
  const n = typeof value === "string" ? Number(value) : value;
  const formatted = new Intl.NumberFormat(locale === "ar" ? "ar-SA" : "en-US", {
    maximumFractionDigits: 0,
  }).format(Number.isFinite(n) ? n : 0);
  return locale === "ar" ? `${formatted} ر.س` : `SAR ${formatted}`;
}

export const FEEDBACK_BANK: Record<
  Locale,
  { category: string; sentiment: string; body: string }[]
> = {
  ar: [
    { category: "EQUIPMENT", sentiment: "POSITIVE", body: "المعدة تعمل بكفاءة عالية والبث المباشر ساعدني في المعاينة." },
    { category: "SHIPPING", sentiment: "NEUTRAL", body: "التوصيل وصل في الوقت المحدد إلى جدة." },
    { category: "MAINTENANCE", sentiment: "POSITIVE", body: "فريق التركيب والصيانة محترف وسريع الاستجابة." },
    { category: "PLATFORM", sentiment: "NEGATIVE", body: "أحتاج خيارات دفع إضافية للدفعة المقدمة." },
  ],
  en: [
    { category: "EQUIPMENT", sentiment: "POSITIVE", body: "Machine runs perfectly and the live stream made inspection easy." },
    { category: "SHIPPING", sentiment: "NEUTRAL", body: "Delivery arrived on schedule in Jeddah." },
    { category: "MAINTENANCE", sentiment: "POSITIVE", body: "Installation crew was professional and fast." },
    { category: "PLATFORM", sentiment: "NEGATIVE", body: "I need more downpayment options at checkout." },
  ],
  ur: [
    { category: "EQUIPMENT", sentiment: "POSITIVE", body: "مشین بہترین کام کر رہی ہے۔" },
    { category: "SHIPPING", sentiment: "NEUTRAL", body: "ڈیلیوری وقت پر پہنچی۔" },
    { category: "MAINTENANCE", sentiment: "POSITIVE", body: "ٹیم نے فوری تنصیب کی۔" },
    { category: "PLATFORM", sentiment: "NEGATIVE", body: "مجھے مزید ادائیگی کے اختیارات چاہئیں۔" },
  ],
  fr: [
    { category: "EQUIPMENT", sentiment: "POSITIVE", body: "La machine fonctionne parfaitement." },
    { category: "SHIPPING", sentiment: "NEUTRAL", body: "Livraison arrivée à l'heure à Djeddah." },
    { category: "MAINTENANCE", sentiment: "POSITIVE", body: "Équipe d'installation très professionnelle." },
    { category: "PLATFORM", sentiment: "NEGATIVE", body: "Il me faut plus d'options de paiement." },
  ],
};
