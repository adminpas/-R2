/**
 * LIVE SHOWROOM 24H RESERVATION ENGINE.
 * Holding an item from the live feed is only granted after an automated
 * upfront payment of at least one-quarter (25%) of the item value, which is
 * immediately parked in the smart escrow ledger.
 */
import { and, eq, lt, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  escrowTransactions,
  laundryEquipment,
  orders,
  reservations,
} from "@/db/schema";
import { HttpError } from "./api";
import { LIMITS } from "./config";
import { newEscrowCode } from "./crypto";
import { assertDownpaymentAtLeastQuarter, computeSplit } from "./finance";
import { openEscrow, refundEscrow, releaseEscrow } from "./escrow";
import { audit } from "./auth";

export async function expireStaleHolds(): Promise<number> {
  const now = new Date();
  const stale = await db
    .select({
      reservationId: reservations.reservationId,
      equipmentId: reservations.equipmentId,
      escrowId: reservations.escrowId,
    })
    .from(reservations)
    .where(
      and(
        eq(reservations.status, "ACTIVE_HOLD"),
        lt(reservations.holdExpiresAt, now),
      ),
    );
  for (const row of stale) {
    await db
      .update(reservations)
      .set({ status: "EXPIRED" })
      .where(eq(reservations.reservationId, row.reservationId));
    await db
      .update(laundryEquipment)
      .set({ availabilityStatus: "AVAILABLE", holdExpiresAt: null })
      .where(eq(laundryEquipment.equipmentId, row.equipmentId));
    if (row.escrowId) await refundEscrow(row.escrowId, 0, "24H_HOLD_EXPIRED");
  }
  return stale.length;
}

export async function createHold(input: {
  equipmentId: number;
  customerId: number;
  amountPaid: number;
  paymentMethod?: string;
}) {
  await expireStaleHolds();

  const [item] = await db
    .select()
    .from(laundryEquipment)
    .where(eq(laundryEquipment.equipmentId, input.equipmentId))
    .limit(1);
  if (!item) {
    throw new HttpError("ITEM_NOT_FOUND", "المعدة غير موجودة", "Equipment not found", 404);
  }
  if (item.availabilityStatus === "SOLD") {
    throw new HttpError("ITEM_SOLD", "تم بيع هذه المعدة", "Item already sold", 409);
  }
  if (item.availabilityStatus === "HOLD_24H") {
    const stillActive =
      item.holdExpiresAt && item.holdExpiresAt.getTime() > Date.now();
    if (stillActive) {
      throw new HttpError(
        "ITEM_ON_HOLD",
        "المعدة محجوزة حالياً لعميل آخر لمدة ٢٤ ساعة",
        "Item is currently on a 24h hold for another client",
        409,
      );
    }
  }

  const price = Number(item.price);
  const guard = assertDownpaymentAtLeastQuarter(price, input.amountPaid);
  if (!guard.valid) {
    throw new HttpError(
      "DOWNPAYMENT_TOO_LOW",
      `الدفعة المقدمة يجب أن لا تقل عن ربع القيمة (${guard.required.toFixed(2)} ر.س)`,
      `Downpayment must be at least one quarter of the value (${guard.required.toFixed(2)} SAR)`,
      422,
    );
  }

  const commission = Number(item.commissionPercentage);
  const split = computeSplit(price, commission);
  const holdExpiresAt = new Date(
    Date.now() + LIMITS.RESERVATION_HOLD_HOURS * 60 * 60 * 1000,
  );

  const [reservation] = await db
    .insert(reservations)
    .values({
      equipmentId: item.equipmentId,
      customerId: input.customerId,
      merchantId: item.merchantId,
      holdExpiresAt,
      downpaymentAmount: input.amountPaid.toFixed(2),
      downpaymentPaidAt: new Date(),
      status: "ACTIVE_HOLD",
    })
    .returning();

  const escrow = await openEscrow({
    payerId: input.customerId,
    payeeMerchantId: item.merchantId,
    grossAmount: input.amountPaid,
    commissionPercentage: split.commissionPercentage,
    reservationId: reservation.reservationId,
    paymentMethod: input.paymentMethod,
    holdImmediately: true,
  });

  await db
    .update(reservations)
    .set({ escrowId: escrow.escrowId })
    .where(eq(reservations.reservationId, reservation.reservationId));
  await db
    .update(laundryEquipment)
    .set({ availabilityStatus: "HOLD_24H", holdExpiresAt })
    .where(eq(laundryEquipment.equipmentId, item.equipmentId));

  await audit({
    actorUserId: input.customerId,
    eventType: "RESERVATION_HOLD_CREATED",
    detail: {
      equipmentId: item.equipmentId,
      holdExpiresAt: holdExpiresAt.toISOString(),
      downpayment: input.amountPaid,
    },
  });

  return {
    reservationId: reservation.reservationId,
    escrowId: escrow.escrowId,
    escrowCode: escrow.escrowCode,
    holdExpiresAt,
    downpaymentAmount: input.amountPaid,
    requiredDownpayment: guard.required,
  };
}

/** Converts an active hold into a full order, releasing escrow to the merchant. */
export async function convertHoldToOrder(input: {
  reservationId: number;
  actorId: number;
  installationRequested?: boolean;
}) {
  const [reservation] = await db
    .select()
    .from(reservations)
    .where(eq(reservations.reservationId, input.reservationId))
    .limit(1);
  if (!reservation) {
    throw new HttpError("HOLD_NOT_FOUND", "الحجز غير موجود", "Hold not found", 404);
  }
  if (reservation.status !== "ACTIVE_HOLD") {
    throw new HttpError("HOLD_INACTIVE", "الحجز غير نشط", "Hold is not active", 409);
  }
  if (reservation.holdExpiresAt.getTime() < Date.now()) {
    throw new HttpError("HOLD_EXPIRED", "انتهت مدة الحجز", "Hold expired", 409);
  }

  const [item] = await db
    .select()
    .from(laundryEquipment)
    .where(eq(laundryEquipment.equipmentId, reservation.equipmentId))
    .limit(1);
  if (!item) throw new HttpError("ITEM_NOT_FOUND", "المعدة غير موجودة", "Equipment not found", 404);

  const split = computeSplit(Number(item.price), Number(item.commissionPercentage));
  const orderCode = newEscrowCode("ORD");
  const [order] = await db
    .insert(orders)
    .values({
      orderCode,
      reservationId: reservation.reservationId,
      equipmentId: item.equipmentId,
      customerId: reservation.customerId,
      merchantId: reservation.merchantId,
      totalAmount: split.price.toFixed(2),
      downpaymentAmount: reservation.downpaymentAmount,
      remainingAmount: split.remainingAmount.toFixed(2),
      commissionPercentage: split.commissionPercentage.toFixed(2),
      commissionAmount: split.commissionAmount.toFixed(2),
      netToMerchant: split.netToMerchant.toFixed(2),
    })
    .returning();

  const balanceEscrow = await openEscrow({
    payerId: reservation.customerId,
    payeeMerchantId: reservation.merchantId,
    grossAmount: split.remainingAmount,
    commissionPercentage: split.commissionPercentage,
    orderId: order.orderId,
    holdImmediately: true,
  });

  if (reservation.escrowId) {
    await releaseEscrow(reservation.escrowId, input.actorId);
  }

  await db
    .update(reservations)
    .set({ status: "CONVERTED" })
    .where(eq(reservations.reservationId, reservation.reservationId));
  await db
    .update(laundryEquipment)
    .set({ availabilityStatus: "SOLD", holdExpiresAt: null, stockQuantity: sql`greatest(${laundryEquipment.stockQuantity} - 1, 0)` })
    .where(eq(laundryEquipment.equipmentId, item.equipmentId));

  await audit({
    actorUserId: input.actorId,
    eventType: "ORDER_CONVERTED",
    detail: {
      orderCode,
      escrowCode: balanceEscrow.escrowCode,
      installationRequested: input.installationRequested ?? false,
    },
  });

  return { order, balanceEscrow };
}

/** Customer cancels / releases their own hold -> automatic escrow refund. */
export async function releaseHold(input: {
  reservationId: number;
  actorId: number;
}) {
  const [reservation] = await db
    .select()
    .from(reservations)
    .where(eq(reservations.reservationId, input.reservationId))
    .limit(1);
  if (!reservation) {
    throw new HttpError("HOLD_NOT_FOUND", "الحجز غير موجود", "Hold not found", 404);
  }
  if (reservation.escrowId) {
    await refundEscrow(
      reservation.escrowId,
      input.actorId,
      "HOLD_RELEASED_BY_CUSTOMER",
    );
  }
  await db
    .update(reservations)
    .set({ status: "RELEASED" })
    .where(eq(reservations.reservationId, reservation.reservationId));
  await db
    .update(laundryEquipment)
    .set({ availabilityStatus: "AVAILABLE", holdExpiresAt: null })
    .where(eq(laundryEquipment.equipmentId, reservation.equipmentId));
  await audit({
    actorUserId: input.actorId,
    eventType: "RESERVATION_RELEASED",
    detail: { reservationId: reservation.reservationId },
  });
  return { released: true };
}

export async function listReservationsFor(userId: number) {
  return db
    .select({
      reservation: reservations,
      item: laundryEquipment,
      escrowStage: escrowTransactions.stage,
    })
    .from(reservations)
    .leftJoin(
      laundryEquipment,
      eq(laundryEquipment.equipmentId, reservations.equipmentId),
    )
    .leftJoin(
      escrowTransactions,
      eq(escrowTransactions.escrowId, reservations.escrowId),
    )
    .where(eq(reservations.customerId, userId));
}
