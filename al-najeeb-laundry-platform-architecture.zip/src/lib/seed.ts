/**
 * Idempotent bootstrap of the Al-Najeeb showroom matrix:
 * tenants (with SSD folders), categories, equipment, 4K promo trailers and the
 * live quarterly auction packages.
 */
import { sql } from "drizzle-orm";
import { db } from "@/db";
import {
  affordableAuctions,
  categories,
  equipmentMedia,
  feedbackBank,
  laundryEquipment,
  systemUsers,
} from "@/db/schema";
import { hashPassword } from "./crypto";
import { SSD_LOGICAL_ROOT, TENANT_ROOTS } from "./config";
import { merchantRoot, writeLogicalFile } from "./storage";
import { FEEDBACK_BANK } from "./i18n";

const IMAGES = [
  "https://images.pexels.com/photos/8774409/pexels-photo-8774409.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  "https://images.pexels.com/photos/4386143/pexels-photo-4386143.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  "https://images.pexels.com/photos/9669475/pexels-photo-9669475.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  "https://images.pexels.com/photos/8774651/pexels-photo-8774651.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  "https://images.pexels.com/photos/8774373/pexels-photo-8774373.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  "https://images.pexels.com/photos/8774638/pexels-photo-8774638.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  "https://images.pexels.com/photos/8774512/pexels-photo-8774512.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  "https://images.pexels.com/photos/10344209/pexels-photo-10344209.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
];

const TRAILERS = [
  {
    url: "https://videos.pexels.com/video-files/8756698/8756698-uhd_2160_4096_25fps.mp4",
    poster:
      "https://images.pexels.com/videos/8756698/pexels-photo-8756698.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=630",
  },
  {
    url: "https://videos.pexels.com/video-files/8756631/8756631-uhd_2160_4096_25fps.mp4",
    poster:
      "https://images.pexels.com/videos/8756631/pexels-photo-8756631.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=630",
  },
  {
    url: "https://videos.pexels.com/video-files/8756701/8756701-uhd_2160_4096_25fps.mp4",
    poster:
      "https://images.pexels.com/videos/8756701/pexels-photo-8756701.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=630",
  },
  {
    url: "https://videos.pexels.com/video-files/8756956/8756956-uhd_2160_4096_25fps.mp4",
    poster:
      "https://images.pexels.com/videos/8756956/pexels-photo-8756956.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=630",
  },
  {
    url: "https://videos.pexels.com/video-files/8756636/8756636-uhd_2160_4096_25fps.mp4",
    poster:
      "https://images.pexels.com/videos/8756636/pexels-photo-8756636.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=630",
  },
  {
    url: "https://videos.pexels.com/video-files/8756704/8756704-uhd_2160_4096_25fps.mp4",
    poster:
      "https://images.pexels.com/videos/8756704/pexels-photo-8756704.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=630",
  },
];

let seedPromise: Promise<void> | null = null;

export function ensureSeeded(): Promise<void> {
  if (!seedPromise) {
    seedPromise = runSeed()
      .then(() => ensureTenantFolders())
      .catch((error) => {
        seedPromise = null;
        throw error;
      });
  }
  return seedPromise;
}

/** Idempotent: materializes every merchant sandbox on the local SSD. */
async function ensureTenantFolders(): Promise<void> {
  const merchants = await db
    .select({ userId: systemUsers.userId, username: systemUsers.username, roleType: systemUsers.roleType })
    .from(systemUsers)
    .where(sql`${systemUsers.roleType}::text = 'MERCHANT'`);
  for (const merchant of merchants) {
    const folder = merchantRoot(merchant.userId);
    await writeLogicalFile(
      folder,
      "TENANT_INDEX.txt",
      new TextEncoder().encode(
        [
          `TENANT ${merchant.username} (${merchant.roleType})`,
          `LOGICAL_ROOT ${folder}`,
          "NODE JEDDAH-ALKHUMRA-01",
          "POLICY isolation=strict traversal=block",
        ].join("\n"),
      ),
      true,
    );
  }
  await writeLogicalFile(
    `${SSD_LOGICAL_ROOT}/${TENANT_ROOTS.TRAILERS}`,
    "README_STREAMING.txt",
    new TextEncoder().encode(
      "4K promotional trailers — streamed with HTTP byte-range from the local SSD.",
    ),
    true,
  );
  await writeLogicalFile(
    `${SSD_LOGICAL_ROOT}/${TENANT_ROOTS.CATALOG}`,
    "CATALOG_INDEX.txt",
    new TextEncoder().encode("Al-Najeeb showroom catalog — mapped SSD folder."),
    true,
  );
}

async function runSeed(): Promise<void> {
  const [{ count }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(systemUsers);
  if (count > 0) return;

  const users = await db
    .insert(systemUsers)
    .values([
      {
        username: "najeeb_admin",
        passwordHash: hashPassword("Najeeb@1447"),
        roleType: "SUPER_ADMIN",
        isActive: true,
        displayNameAr: "الإدارة العليا — النجيب",
        displayNameEn: "Al-Najeeb Super Admin",
        phone: "+966500000001",
        city: "جدة — الخمرة",
      },
      {
        username: "najeeb_deputy",
        passwordHash: hashPassword("Najeeb@1447"),
        roleType: "ASSISTANT_ADMIN",
        isActive: true,
        displayNameAr: "مساعد الإدارة",
        displayNameEn: "Assistant Admin",
        city: "جدة",
      },
      {
        username: "merchant_jeddah",
        passwordHash: hashPassword("Merchant@1447"),
        roleType: "MERCHANT",
        isActive: true,
        displayNameAr: "مستشار قطع الغيار — جدة",
        displayNameEn: "Jeddah Spare Parts Merchant",
        city: "جدة",
        merchantSsdFolder: merchantRoot(0),
      },
      {
        username: "merchant_riyadh",
        passwordHash: hashPassword("Merchant@1447"),
        roleType: "MERCHANT",
        isActive: true,
        displayNameAr: "مستشار قطع الغيار — الرياض",
        displayNameEn: "Riyadh Spare Parts Merchant",
        city: "الرياض",
        merchantSsdFolder: merchantRoot(0),
      },
      {
        username: "merchant_pending",
        passwordHash: hashPassword("Merchant@1447"),
        roleType: "MERCHANT",
        isActive: false,
        displayNameAr: "تاجر جديد بانتظار الموافقة",
        displayNameEn: "Pending merchant",
        city: "مكة المكرمة",
      },
      {
        username: "tech_najeeb",
        passwordHash: hashPassword("Tech@1447"),
        roleType: "MAINTENANCE_TECH",
        isActive: true,
        displayNameAr: "قسم التركيب والصيانة",
        displayNameEn: "Installation & Maintenance",
        city: "جدة",
      },
      {
        username: "shipping_alkhumra",
        passwordHash: hashPassword("Shipping@1447"),
        roleType: "SHIPPING_COMPANY",
        isActive: true,
        displayNameAr: "شركة التوصيل — الخمرة",
        displayNameEn: "Al-Khumra Delivery Co.",
        city: "جدة — الخمرة",
      },
    ])
    .returning();

  const byUsername = new Map(users.map((u) => [u.username, u]));
  const jeddahMerchant = byUsername.get("merchant_jeddah")!;
  const riyadhMerchant = byUsername.get("merchant_riyadh")!;
  void byUsername.get("merchant_pending");

  for (const merchant of [jeddahMerchant, riyadhMerchant]) {
    const folder = merchantRoot(merchant.userId);
    await db
      .update(systemUsers)
      .set({ merchantSsdFolder: folder })
      .where(sql`${systemUsers.userId} = ${merchant.userId}`);

    // Materialize the tenant sandbox on the local SSD with its index manifest.
    await writeLogicalFile(
      folder,
      "TENANT_INDEX.txt",
      new TextEncoder().encode(
        [
          `TENANT ${merchant.username} (${merchant.roleType})`,
          `LOGICAL_ROOT ${folder}`,
          `NODE JEDDAH-ALKHUMRA-01`,
          `POLICY isolation=strict traversal=block`,
        ].join("\n"),
      ),
    );
    await writeLogicalFile(
      `${folder}/Compressors`,
      "compressor-specs.txt",
      new TextEncoder().encode("SS6206-2RS bearing / Kevlar belt set — spec sheet"),
    );
  }

  const parentCategories = await db
    .insert(categories)
    .values([
      {
        categoryNameAr: "مغاسل صناعية",
        categoryNameEn: "Industrial Washers",
        ssdFolderPath: `${SSD_LOGICAL_ROOT}/${TENANT_ROOTS.CATALOG}/Industrial_Washers`,
        iconGlyph: "🫧",
        sortOrder: 1,
      },
      {
        categoryNameAr: "مجففات غازية وكهربائية",
        categoryNameEn: "Gas & Electric Dryers",
        ssdFolderPath: `${SSD_LOGICAL_ROOT}/${TENANT_ROOTS.CATALOG}/Dryers`,
        iconGlyph: "🌀",
        sortOrder: 2,
      },
      {
        categoryNameAr: "مكابس وحدلات كي",
        categoryNameEn: "Ironers & Presses",
        ssdFolderPath: `${SSD_LOGICAL_ROOT}/${TENANT_ROOTS.CATALOG}/Ironers`,
        iconGlyph: "♨️",
        sortOrder: 3,
      },
      {
        categoryNameAr: "قطع غيار أصلية",
        categoryNameEn: "Original Spare Parts",
        ssdFolderPath: `${SSD_LOGICAL_ROOT}/${TENANT_ROOTS.SPARE_PARTS}`,
        iconGlyph: "⚙️",
        sortOrder: 4,
      },
    ])
    .returning();

  const subCategories = await db
    .insert(categories)
    .values([
      {
        parentCategoryId: parentCategories[0].categoryId,
        categoryNameAr: "مغاسل 10 كجم — 30 كجم",
        categoryNameEn: "Washers 10-30 kg",
        ssdFolderPath: `${SSD_LOGICAL_ROOT}/${TENANT_ROOTS.CATALOG}/Industrial_Washers/10_30kg`,
        iconGlyph: "🧺",
        sortOrder: 5,
      },
      {
        parentCategoryId: parentCategories[1].categoryId,
        categoryNameAr: "مجففات 15 كجم — 50 كجم",
        categoryNameEn: "Dryers 15-50 kg",
        ssdFolderPath: `${SSD_LOGICAL_ROOT}/${TENANT_ROOTS.CATALOG}/Dryers/15_50kg`,
        iconGlyph: "🔥",
        sortOrder: 6,
      },
    ])
    .returning();

  const allCategories = [...parentCategories, ...subCategories];

  type CatalogEntry = {
    titleAr: string;
    titleEn: string;
    price: number;
    status: "NEW_4K" | "LIKE_NEW_BLUERAY" | "USED_EXCELLENT_HD" | "REFURBISHED";
    live: boolean;
    specs: Record<string, string>;
  };

  const catalog: CatalogEntry[] = [
    {
      titleAr: "مغسلة صناعية 25 كجم — موديل نجيب برو 4K",
      titleEn: "Industrial Washer 25kg — Najeeb Pro 4K",
      price: 48500,
      status: "NEW_4K" as const,
      live: true,
      specs: {
        capacity: "25 kg",
        spin: "1200 rpm",
        power: "380V / 3Phase",
        warranty: "3 years",
      },
    },
    {
      titleAr: "مغسلة 12 كجم — حالتها كالجديد BlueRay",
      titleEn: "Washer 12kg — Like New BlueRay",
      price: 21900,
      status: "LIKE_NEW_BLUERAY" as const,
      live: true,
      specs: { capacity: "12 kg", spin: "1000 rpm", power: "220V" },
    },
    {
      titleAr: "مغسلة 8 كجم مستعملة ممتازة HD",
      titleEn: "Washer 8kg Used Excellent HD",
      price: 9400,
      status: "USED_EXCELLENT_HD" as const,
      live: false,
      specs: { capacity: "8 kg", spin: "800 rpm", power: "220V" },
    },
    {
      titleAr: "مجفف غازي 30 كجم مُجدد بالكامل",
      titleEn: "Gas Dryer 30kg Fully Refurbished",
      price: 27800,
      status: "REFURBISHED" as const,
      live: true,
      specs: { capacity: "30 kg", heat: "Gas LPG", power: "380V" },
    },
    {
      titleAr: "مجفف كهربائي 50 كجم — إصدار 4K",
      titleEn: "Electric Dryer 50kg — 4K Edition",
      price: 61200,
      status: "NEW_4K" as const,
      live: true,
      specs: { capacity: "50 kg", heat: "Electric 27kW", power: "380V" },
    },
    {
      titleAr: "مكبس بخاري احترافي 1.2 متر",
      titleEn: "Professional Steam Press 1.2m",
      price: 18300,
      status: "NEW_4K" as const,
      live: false,
      specs: { width: "1.2 m", steam: "6 bar", power: "220V" },
    },
    {
      titleAr: "حدلة كي مصناعية 3 مترات",
      titleEn: "Industrial Ironer 3m",
      price: 89750,
      status: "LIKE_NEW_BLUERAY" as const,
      live: true,
      specs: { width: "3 m", speed: "8 m/min", power: "380V" },
    },
    {
      titleAr: "طبلية ستانلس ستيل 20 كجم",
      titleEn: "Stainless Steel Drum 20kg",
      price: 14200,
      status: "NEW_4K" as const,
      live: false,
      specs: { material: "SS316", capacity: "20 kg" },
    },
    {
      titleAr: "طقم سيور حركة أصلية (10 قطع)",
      titleEn: "Original Drive Belt Set (10 pcs)",
      price: 2650,
      status: "NEW_4K" as const,
      live: false,
      specs: { pieces: "10", material: "Kevlar" },
    },
    {
      titleAr: "رولمان بلبي مقاوم للماء — عبوة 4",
      titleEn: "Waterproof Drum Bearing — Pack of 4",
      price: 1880,
      status: "NEW_4K" as const,
      live: false,
      specs: { model: "SS6206-2RS", pieces: "4" },
    },
    {
      titleAr: "لوحة تحكم إلكترونية ذكية v4",
      titleEn: "Smart Control Board v4",
      price: 3750,
      status: "REFURBISHED" as const,
      live: false,
      specs: { firmware: "v4.2.1", channels: "12" },
    },
    {
      titleAr: "مضخة تصريف صناعية 1.5 حصان",
      titleEn: "Industrial Drain Pump 1.5 HP",
      price: 2190,
      status: "NEW_4K" as const,
      live: false,
      specs: { power: "1.5 HP", flow: "400 L/min" },
    },
  ];

  const insertedItems = await db
    .insert(laundryEquipment)
    .values(
      catalog.map((entry, index) => {
        const category = allCategories[index % allCategories.length];
        const merchant = index % 3 === 2 ? riyadhMerchant : jeddahMerchant;
        const trailer = TRAILERS[index % TRAILERS.length];
        return {
          categoryId: category.categoryId,
          merchantId: merchant.userId,
          titleAr: entry.titleAr,
          titleEn: entry.titleEn,
          descriptionAr:
            "معدة مفحوصة بالكامل في ورشة النجيب بجدة — الخمرة، مع بث مباشر للمعرض وإعلان ترويجي 4K مسحوب من تخزين SSD المحلي.",
          descriptionEn:
            "Fully inspected at the Al-Najeeb Jeddah Al-Khumra workshop, with a live showroom feed and a 4K promo trailer streamed from the local SSD.",
          price: entry.price.toFixed(2),
          commissionPercentage: index % 2 === 0 ? "15.00" : "10.00",
          equipmentStatus: entry.status,
          availabilityStatus: "AVAILABLE" as const,
          specsJson: entry.specs,
          videoTrailerPath: `${SSD_LOGICAL_ROOT}/${TENANT_ROOTS.TRAILERS}/item_${index + 1}.mp4`,
          posterImagePath: IMAGES[index % IMAGES.length],
          isLiveShowroom: entry.live,
          stockQuantity: 1 + (index % 3),
        };
      }),
    )
    .returning();

  const mediaRows = insertedItems.flatMap((item, index) => {
    const trailer = TRAILERS[index % TRAILERS.length];
    return [
      {
        equipmentId: item.equipmentId,
        merchantId: item.merchantId,
        kind: "IMAGE" as const,
        logicalPath: item.posterImagePath ?? "",
        remoteUrl: item.posterImagePath,
        isVertical: true,
      },
      {
        equipmentId: item.equipmentId,
        merchantId: item.merchantId,
        kind: "TRAILER" as const,
        logicalPath: item.videoTrailerPath ?? "",
        remoteUrl: trailer.url,
        posterUrl: trailer.poster,
        isVertical: true,
        isPromotional: true,
      },
    ];
  });
  await db.insert(equipmentMedia).values(mediaRows);

  const now = Date.now();
  await db.insert(affordableAuctions).values([
    {
      packageTitle:
        "باقة مشروع مغسلة متكاملة — تكلفة بدون ربح (غسيل + تجفيف + كي)",
      baseCostPrice: "74000.00",
      currentHighestBid: "74000.00",
      minimumIncrement: "500.00",
      startDate: new Date(now - 2 * 24 * 60 * 60 * 1000),
      endDate: new Date(now + 30 * 24 * 60 * 60 * 1000),
      packageDetails: {
        items: [
          "مغسلة صناعية 12 كجم",
          "مجفف غازي 30 كجم",
          "مكبس بخاري 1.2 متر",
          "توريد وتركيب مجاني داخل جدة",
        ],
        localeNoteAr: "باقة مخصصة لدعم أصحاب الدخل المحدود بسعر التكلفة الحقيقي.",
        localeNoteEn: "Cost-price package supporting lower-income entrepreneurs.",
      },
      createdByUserId: jeddahMerchant.userId,
    },
    {
      packageTitle: "باقة مغسلة ذاتية مصغرة (Self-Service) — 3 وحدات",
      baseCostPrice: "39500.00",
      currentHighestBid: "41500.00",
      minimumIncrement: "500.00",
      startDate: new Date(now - 6 * 24 * 60 * 60 * 1000),
      endDate: new Date(now + 3 * 24 * 60 * 60 * 1000),
      packageDetails: {
        items: [
          "مغسلة 8 كجم × 2",
          "مجفف 15 كجم × 1",
          "لوحة تحكم مركزية + عملات ذكية",
        ],
        localeNoteAr: "المزايدة الحالية أعلى من التكلفة بمقدار 2000 ر.س.",
        localeNoteEn: "Current bid is 2000 SAR above cost.",
      },
      highestBidderId: riyadhMerchant.userId,
      createdByUserId: jeddahMerchant.userId,
    },
  ]);

  const bankRows = Object.entries(FEEDBACK_BANK).flatMap(([locale, entries]) =>
    entries.map((entry) => ({
      locale,
      category: entry.category,
      body: entry.body,
      sentiment: entry.sentiment,
    })),
  );
  await db.insert(feedbackBank).values(bankRows);
}
