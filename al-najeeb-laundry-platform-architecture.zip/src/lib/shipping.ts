import { desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { laundryEquipment, orders, shippingJobs, systemUsers } from "@/db/schema";
import { HttpError } from "./api";
import { audit } from "./auth";

export async function createShippingJob(input: {
  orderId: number;
  courierUserId?: number | null;
  installationRequested?: boolean;
  driverName?: string;
  driverPhone?: string;
  vehiclePlate?: string;
}) {
  const trackingCode = `NAJ-${input.orderId}-${Math.random()
    .toString(36)
    .slice(2, 7)
    .toUpperCase()}`;
  const [job] = await db
    .insert(shippingJobs)
    .values({
      orderId: input.orderId,
      courierUserId: input.courierUserId ?? null,
      trackingCode,
      driverName: input.driverName ?? null,
      driverPhone: input.driverPhone ?? null,
      vehiclePlate: input.vehiclePlate ?? null,
      installationRequested: input.installationRequested ?? false,
      status: "ASSIGNED",
      scheduledAt: new Date(Date.now() + 48 * 60 * 60 * 1000),
    })
    .returning();
  await audit({
    actorUserId: input.courierUserId ?? null,
    eventType: "SHIPPING_JOB_CREATED",
    detail: { trackingCode, orderId: input.orderId },
  });
  return job;
}

export async function listShippingJobs(courierUserId?: number) {
  return db
    .select({
      job: shippingJobs,
      order: orders,
      itemTitleAr: laundryEquipment.titleAr,
      customerNameAr: systemUsers.displayNameAr,
    })
    .from(shippingJobs)
    .leftJoin(orders, eq(orders.orderId, shippingJobs.orderId))
    .leftJoin(
      laundryEquipment,
      eq(laundryEquipment.equipmentId, orders.equipmentId),
    )
    .leftJoin(systemUsers, eq(systemUsers.userId, orders.customerId))
    .where(
      courierUserId
        ? sql`(${shippingJobs.courierUserId} = ${courierUserId} or ${shippingJobs.courierUserId} is null)`
        : sql`true`,
    )
    .orderBy(desc(shippingJobs.jobId))
    .limit(80);
}

export async function updateShippingStatus(input: {
  jobId: number;
  actorId: number;
  status: "ASSIGNED" | "PICKED_UP" | "IN_TRANSIT" | "DELIVERED" | "FAILED";
  driverName?: string;
  driverPhone?: string;
  notes?: string;
}) {
  const [job] = await db
    .update(shippingJobs)
    .set({
      status: input.status,
      driverName: input.driverName,
      driverPhone: input.driverPhone,
      notes: input.notes,
      deliveredAt: input.status === "DELIVERED" ? new Date() : null,
      courierUserId: input.actorId,
    })
    .where(eq(shippingJobs.jobId, input.jobId))
    .returning();
  if (!job) throw new HttpError("JOB_NOT_FOUND", "المهمة غير موجودة", "Job not found", 404);
  await audit({
    actorUserId: input.actorId,
    eventType: "SHIPPING_STATUS_UPDATED",
    detail: { jobId: input.jobId, status: input.status },
  });
  return job;
}
