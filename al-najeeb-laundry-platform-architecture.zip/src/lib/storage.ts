/**
 * FILE 2 (part A) — SSD STORAGE MAPPING CONTROLLER
 * Maps logical `/mnt/storage/Al_Najeeb_SSD/...` paths onto the physical SSD of
 * the Jeddah (Al-Khumra) node, enforces strict multi-tenant folder isolation
 * and intercepts every illegal cross-tenant path traversal attempt.
 */
import { promises as fs } from "node:fs";
import path from "node:path";
import { SSD_LOGICAL_ROOT, SSD_PHYSICAL_ROOT, TENANT_ROOTS } from "./config";
import { HttpError } from "./api";
import type { RoleType } from "@/db/schema";

export class PathTraversalError extends HttpError {
  constructor(detail: { attempted: string; tenant?: string }) {
    super(
      "TENANT_PATH_BLOCKED",
      "محاولة وصول غير مصرح بها إلى مجلد مستأجر آخر — تم تسجيل الحدث",
      `Illegal cross-tenant path traversal blocked: ${detail.attempted}`,
      403,
    );
  }
}

/** logical `/mnt/storage/Al_Najeeb_SSD/x` -> physical absolute path */
export function toPhysical(logicalPath: string): string {
  const normalized = logicalPath.replace(/\\/g, "/").trim();
  const rel = normalized.startsWith(SSD_LOGICAL_ROOT)
    ? normalized.slice(SSD_LOGICAL_ROOT.length)
    : normalized;
  const clean = rel.replace(/^\/+/, "");
  const target = path.resolve(SSD_PHYSICAL_ROOT, clean);
  const root = path.resolve(SSD_PHYSICAL_ROOT);
  if (target !== root && !target.startsWith(root + path.sep)) {
    throw new PathTraversalError({ attempted: logicalPath });
  }
  return target;
}

/** physical absolute path -> logical SSD path shown to clients */
export function toLogical(physicalPath: string): string {
  const root = path.resolve(SSD_PHYSICAL_ROOT);
  const rel = path.relative(root, physicalPath).split(path.sep).join("/");
  return `${SSD_LOGICAL_ROOT}/${rel}`;
}

/**
 * The dedicated tenant sandbox of a merchant:
 * `/mnt/storage/Al_Najeeb_SSD/04_Spare_Parts/Merchant_[id]/`
 */
export function merchantRoot(merchantId: number): string {
  return `${SSD_LOGICAL_ROOT}/${TENANT_ROOTS.SPARE_PARTS}/Merchant_${merchantId}`;
}

export type TenantScope = {
  userId: number;
  roleType: RoleType;
  merchantId?: number | null;
};

/**
 * Resolves a folder the caller is allowed to touch.
 * - SUPER_ADMIN / ASSISTANT_ADMIN: whole SSD array (audited).
 * - MERCHANT / MAINTENANCE_TECH / SHIPPING_COMPANY: own tenant folder only.
 */
export function resolveScopeFolder(
  scope: TenantScope,
  requestedFolder?: string,
): string {
  const privileged =
    scope.roleType === "SUPER_ADMIN" || scope.roleType === "ASSISTANT_ADMIN";

  if (privileged) {
    return sanitizeInsideRoot(requestedFolder ?? SSD_LOGICAL_ROOT);
  }

  const base = merchantRoot(scope.merchantId ?? scope.userId);
  if (!requestedFolder || requestedFolder === base) return base;

  const candidate = path.resolve(base, requestedFolder.replace(/^\/+/, ""));
  const normalizedBase = path.resolve(base);
  if (candidate !== normalizedBase && !candidate.startsWith(normalizedBase + path.sep)) {
    throw new PathTraversalError({
      attempted: requestedFolder,
      tenant: String(scope.merchantId ?? scope.userId),
    });
  }
  return toLogical(candidate);
}

function sanitizeInsideRoot(folder: string): string {
  const candidate = path.resolve(SSD_PHYSICAL_ROOT, folder.replace(/^\/+/, ""));
  const root = path.resolve(SSD_PHYSICAL_ROOT);
  if (candidate !== root && !candidate.startsWith(root + path.sep)) {
    throw new PathTraversalError({ attempted: folder });
  }
  return toLogical(candidate);
}

/** Rejects any logical path that escapes the caller tenant sandbox. */
export function assertTenantPath(scope: TenantScope, logicalPath: string): string {
  const normalized = logicalPath.replace(/\\/g, "/");
  if (!normalized.startsWith(SSD_LOGICAL_ROOT)) {
    throw new PathTraversalError({ attempted: logicalPath });
  }
  const privileged =
    scope.roleType === "SUPER_ADMIN" || scope.roleType === "ASSISTANT_ADMIN";
  if (privileged) return toPhysical(normalized);

  const base = merchantRoot(scope.merchantId ?? scope.userId);
  if (!normalized.startsWith(base)) {
    throw new PathTraversalError({
      attempted: logicalPath,
      tenant: String(scope.merchantId ?? scope.userId),
    });
  }
  return toPhysical(normalized);
}

export function safeFileName(original: string): string {
  const ext = path.extname(original).toLowerCase().replace(/[^.a-z0-9]/g, "");
  const stem = path
    .basename(original, path.extname(original))
    .replace(/[^\p{L}\p{N}_-]+/gu, "-")
    .slice(0, 60);
  const stamp = Date.now().toString(36);
  return `${stem || "media"}_${stamp}${ext || ".bin"}`;
}

export async function ensureLogicalFolder(logicalFolder: string): Promise<string> {
  const physical = toPhysical(logicalFolder);
  await fs.mkdir(physical, { recursive: true });
  return logicalFolder;
}

export async function writeLogicalFile(
  logicalFolder: string,
  fileName: string,
  data: Uint8Array,
  fixed = false,
): Promise<{ logicalPath: string; sizeBytes: number }> {
  await ensureLogicalFolder(logicalFolder);
  const name = fixed ? path.basename(fileName) : safeFileName(fileName);
  const physical = path.join(toPhysical(logicalFolder), name);
  await fs.writeFile(physical, data);
  return { logicalPath: toLogical(physical), sizeBytes: data.byteLength };
}

export async function statLogical(logicalPath: string) {
  try {
    const info = await fs.stat(toPhysical(logicalPath));
    return { size: info.size, mtimeMs: info.mtimeMs };
  } catch {
    return null;
  }
}

export const STORAGE_TREE = TENANT_ROOTS;
