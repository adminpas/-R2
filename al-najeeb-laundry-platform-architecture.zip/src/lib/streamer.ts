/**
 * FILE 2 (part B) — LOCAL SSD VIDEO FILE STREAMER
 * Byte-range streaming engine for the 4K promotional trailers and the live
 * showroom feeds hosted on the local SSD (`Al_Najeeb_SSD`). Falls back to a
 * signed remote CDN mirror when a physical asset is not present on this node.
 */
import { createReadStream, promises as fs } from "node:fs";
import { Readable } from "node:stream";
import type { ReadableStream as WebReadableStream } from "node:stream/web";
import { toPhysical } from "./storage";

export type RangeSpec = { start: number; end: number };

export function parseRange(
  header: string | null,
  size: number,
): RangeSpec | null {
  if (!header) return null;
  const match = /bytes=(\d*)-(\d*)/.exec(header);
  if (!match) return null;
  const [, rawStart, rawEnd] = match;
  let start: number;
  let end: number;
  if (rawStart === "") {
    // suffix range: last N bytes
    const suffix = Number(rawEnd || 0);
    start = Math.max(size - suffix, 0);
    end = size - 1;
  } else {
    start = Number(rawStart);
    end = rawEnd === "" ? size - 1 : Math.min(Number(rawEnd), size - 1);
  }
  if (!Number.isFinite(start) || start > end || start < 0) return null;
  return { start, end };
}

export async function logicalFileSize(logicalPath: string): Promise<number | null> {
  try {
    const info = await fs.stat(toPhysical(logicalPath));
    return info.isFile() ? info.size : null;
  } catch {
    return null;
  }
}

function nodeToWeb(stream: Readable): ReadableStream<Uint8Array> {
  return Readable.toWeb(stream) as unknown as WebReadableStream<Uint8Array> as ReadableStream<Uint8Array>;
}

/**
 * Streams a local SSD asset honoring HTTP Range (206 Partial Content) so the
 * media-player style UI can seek instantly across huge 4K files.
 */
export async function streamLogicalFile(options: {
  logicalPath: string;
  mimeType: string;
  rangeHeader: string | null;
  downloadName?: string;
}): Promise<Response> {
  const { logicalPath, mimeType, rangeHeader } = options;
  const physical = toPhysical(logicalPath);
  const size = await logicalFileSize(logicalPath);
  if (size === null) {
    return new Response("Asset not resident on local SSD", { status: 404 });
  }

  const range = parseRange(rangeHeader, size);
  const headers = new Headers({
    "Content-Type": mimeType,
    "Accept-Ranges": "bytes",
    "Cache-Control": "public, max-age=86400",
    "X-Al-Najeeb-Storage": "LOCAL_SSD",
    "X-Al-Najeeb-Node": "JEDDAH-ALKHUMRA-01",
  });
  if (options.downloadName) {
    headers.set(
      "Content-Disposition",
      `inline; filename="${encodeURIComponent(options.downloadName)}"`,
    );
  }

  if (!range) {
    headers.set("Content-Length", String(size));
    return new Response(nodeToWeb(createReadStream(physical)), {
      status: 200,
      headers,
    });
  }

  headers.set("Content-Range", `bytes ${range.start}-${range.end}/${size}`);
  headers.set("Content-Length", String(range.end - range.start + 1));
  const partial = createReadStream(physical, {
    start: range.start,
    end: range.end,
  });
  return new Response(nodeToWeb(partial), { status: 206, headers });
}

export function mimeFromExtension(logicalPath: string): string {
  const ext = logicalPath.split(".").pop()?.toLowerCase() ?? "";
  const map: Record<string, string> = {
    mp4: "video/mp4",
    m4v: "video/mp4",
    mov: "video/quicktime",
    webm: "video/webm",
    mkv: "video/x-matroska",
    ts: "video/mp2t",
    jpg: "image/jpeg",
    jpeg: "image/jpeg",
    png: "image/png",
    webp: "image/webp",
    gif: "image/gif",
    pdf: "application/pdf",
  };
  return map[ext] ?? "application/octet-stream";
}
