/**
 * AI TECH LIVE SUPPORT — camera vision triage engine.
 * Consumes an in-app camera frame descriptor (client-side vision features) and
 * returns a diagnostic report, then routes the session into a WebRTC
 * conference room with the internal installation & maintenance team.
 */
import { db } from "@/db";
import { conferenceRooms, maintenanceTickets } from "@/db/schema";
import { newRoomId } from "./crypto";

type VisionFeature = {
  label: string;
  weight: number;
  part: string;
  labelAr: string;
  labelEn: string;
  actionAr: string;
  actionEn: string;
  team: string;
};

const VISION_LIBRARY: VisionFeature[] = [
  {
    label: "belt-wear",
    weight: 0.82,
    part: "DRIVE_BELT",
    labelAr: "اهتراء سير الحركة",
    labelEn: "Drive belt wear",
    actionAr: "استبدال سير الحركة ومعايرة الشد خلال 24 ساعة",
    actionEn: "Replace drive belt and re-tension within 24 hours",
    team: "MECHANICAL_TECH",
  },
  {
    label: "bearing-noise",
    weight: 0.91,
    part: "DRUM_BEARING",
    labelAr: "صدور صوت من رولمان الطبلية",
    labelEn: "Drum bearing noise signature",
    actionAr: "فحص رولمان الطبلية وتغييره إن تجاوز التآكل 40%",
    actionEn: "Inspect drum bearing; replace if wear exceeds 40%",
    team: "MECHANICAL_TECH",
  },
  {
    label: "water-leak",
    weight: 0.77,
    part: "INLET_VALVE",
    labelAr: "تسريب مياه من صمام الدخول",
    labelEn: "Water leak at inlet valve",
    actionAr: "إحكام صمام الدخول وتغيير الحشوة المطاطية",
    actionEn: "Reseal inlet valve gasket and pressure test",
    team: "PLUMBING_TECH",
  },
  {
    label: "heater-fault",
    weight: 0.68,
    part: "HEATING_ELEMENT",
    labelAr: "ضعف في عنصر التسخين",
    labelEn: "Heating element underperforming",
    actionAr: "قياس مقاومة عنصر التسخين وتغييره عند الانحراف",
    actionEn: "Measure element resistance; replace on deviation",
    team: "ELECTRICAL_TECH",
  },
  {
    label: "board-error",
    weight: 0.88,
    part: "CONTROL_BOARD",
    labelAr: "خطأ في لوحة التحكم الإلكترونية",
    labelEn: "Control board fault code",
    actionAr: "إعادة برمجة اللوحة أو استبدالها من مخزون قطع الغيار",
    actionEn: "Reflash or swap control board from spare parts stock",
    team: "ELECTRONICS_TECH",
  },
  {
    label: "imbalance",
    weight: 0.61,
    part: "SUSPENSION",
    labelAr: "عدم اتزان الطبلية (تعليق)",
    labelEn: "Drum imbalance / suspension",
    actionAr: "معايرة المساند وميزان الطبلية",
    actionEn: "Calibrate dampers and drum balance",
    team: "MECHANICAL_TECH",
  },
];

export type VisionReport = {
  confidence: number;
  detected: { labelAr: string; labelEn: string; part: string }[];
  recommendedActionAr: string;
  recommendedActionEn: string;
  routedTeam: string;
};

export function analyzeFrame(input: {
  symptomText: string;
  luminance?: number;
  motionScore?: number;
  modelHint?: string;
}): VisionReport {
  const text = input.symptomText.toLowerCase();
  const keywords: Record<string, string[]> = {
    "belt-wear": ["belt", "squeal", "سيور", "سير", "صافرة"],
    "bearing-noise": ["noise", "bearing", "صوت", "رولمان", "اهتزاز"],
    "water-leak": ["leak", "water", "تسريب", "مياه", "ماء"],
    "heater-fault": ["cold", "heat", "تسخين", "بارد", "سخان"],
    "board-error": ["error", "code", "board", "خطأ", "لوحة", "كود"],
    imbalance: ["shake", "jump", "قفز", "اهتزاز", "عدم اتزان"],
  };

  const scored = VISION_LIBRARY.map((feature) => {
    let score = feature.weight * 0.35;
    for (const token of keywords[feature.label] ?? []) {
      if (text.includes(token)) score += 0.4;
    }
    if (typeof input.luminance === "number") {
      const delta = Math.abs(input.luminance - 0.5);
      score += (1 - delta) * 0.1;
    }
    if (typeof input.motionScore === "number") {
      score += Math.min(input.motionScore, 1) * 0.15;
    }
    return { feature, score: Math.min(score, 0.99) };
  }).sort((a, b) => b.score - a.score);

  const top = scored.slice(0, 3).filter((entry) => entry.score > 0.3);
  const chosen = top.length > 0 ? top : scored.slice(0, 1);
  const confidence =
    Math.round(
      (chosen[0].score + (top[1]?.score ?? 0) * 0.25) * 100,
    ) / 100;

  return {
    confidence,
    detected: chosen.map((entry) => ({
      labelAr: entry.feature.labelAr,
      labelEn: entry.feature.labelEn,
      part: entry.feature.part,
    })),
    recommendedActionAr: chosen[0].feature.actionAr,
    recommendedActionEn: chosen[0].feature.actionEn,
    routedTeam: chosen[0].feature.team,
  };
}

export async function openTicketWithVision(input: {
  createdByUserId: number;
  issueSummary: string;
  equipmentId?: number | null;
  merchantId?: number | null;
  customerId?: number | null;
  severity?: string;
  luminance?: number;
  motionScore?: number;
}) {
  const report = analyzeFrame({
    symptomText: input.issueSummary,
    luminance: input.luminance,
    motionScore: input.motionScore,
  });

  const ticketCode = `TKT-${Date.now().toString(36).toUpperCase()}`;
  const roomId = newRoomId();
  const [ticket] = await db
    .insert(maintenanceTickets)
    .values({
      ticketCode,
      equipmentId: input.equipmentId ?? null,
      merchantId: input.merchantId ?? null,
      customerId: input.customerId ?? null,
      createdByUserId: input.createdByUserId,
      issueSummary: input.issueSummary,
      aiVisionReport: report,
      severity: input.severity ?? (report.confidence > 0.8 ? "HIGH" : "NORMAL"),
      status: "DIAGNOSED",
      roomId,
    })
    .returning();

  await db.insert(conferenceRooms).values({
    roomId,
    title: `جلسة دعم فني — ${ticketCode}`,
    purpose: "AI_VISION_SUPPORT",
    hostUserId: input.createdByUserId,
    ticketId: ticket.ticketId,
  });

  return { ticket, report, roomId };
}

export async function openConferenceRoom(input: {
  hostUserId: number;
  title: string;
  purpose: "AI_VISION_SUPPORT" | "INTERNAL" | "MERCHANT" | "CLIENT";
  ticketId?: number | null;
}) {
  const roomId = newRoomId();
  const [room] = await db
    .insert(conferenceRooms)
    .values({
      roomId,
      title: input.title,
      purpose: input.purpose,
      hostUserId: input.hostUserId,
      ticketId: input.ticketId ?? null,
    })
    .returning();
  return room;
}
