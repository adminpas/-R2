import { useEffect } from "react";
import { HashRouter, Route, Routes, useLocation } from "react-router-dom";
import AdminApp from "./admin/AdminApp";
import CustomerApp from "./customer/CustomerApp";
import { StoreProvider } from "./store";

function ManifestSwitch() {
  const loc = useLocation();
  useEffect(() => {
    const isAdmin = loc.pathname.startsWith("/admin");
    let link = document.querySelector('link[rel="manifest"]') as HTMLLinkElement | null;
    if (!link) {
      link = document.createElement("link");
      link.rel = "manifest";
      document.head.appendChild(link);
    }
    link.href = isAdmin ? "/admin-manifest.json" : "/manifest.json";
    const theme = document.querySelector('meta[name="theme-color"]');
    if (theme) theme.setAttribute("content", isAdmin ? "#0a1018" : "#10242c");
  }, [loc.pathname]);
  return null;
}

function Boot() {
  useEffect(() => {
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch(() => undefined);
    }
  }, []);
  return (
    <HashRouter>
      <ManifestSwitch />
      <Routes>
        <Route path="/admin/*" element={<AdminApp />} />
        <Route path="/*" element={<CustomerApp />} />
      </Routes>
    </HashRouter>
  );
}

export default function App() {
  return (
    <StoreProvider>
      <Boot />
    </StoreProvider>
  );
}
