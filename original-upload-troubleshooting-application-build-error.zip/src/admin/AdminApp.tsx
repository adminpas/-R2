import { FormEvent, useState, type ReactNode } from "react";
import { Link, NavLink, Route, Routes, useLocation, useNavigate } from "react-router-dom";
import {
  BadgeDollarSign,
  BarChart3,
  Bell,
  Boxes,
  ClipboardList,
  Folders,
  Gauge,
  ImageIcon,
  LayoutDashboard,
  Lock,
  LogOut,
  Mail,
  Phone,
  Plus,
  Settings,
  Shield,
  Smartphone,
  Trash2,
  UserCog,
  Users,
  Wrench,
} from "lucide-react";
import { ALL_PERMISSIONS, OWNER_PERMISSIONS, type BookingStatus, type Category, type OrderStatus, type PaymentStatus, type PermissionKey, type Product, type Staff } from "../types";
import { HALA_SOFT, bookingStatusLabel, formatDate, formatSar, nowIso, orderStatusLabel, paymentStatusLabel, readFileAsDataUrl, uid } from "../lib";
import { useStore } from "../store";
import { HalaLogo, NajeebLogo } from "../brand";
import { Field, Modal, adminInputClass } from "../ui";
import { cn } from "../utils/cn";

export default function AdminApp() {
  const { staffUser } = useStore();
  const loc = useLocation();
  const isInstall = loc.pathname.replace(/\/$/, "").endsWith("/install");

  if (!staffUser && isInstall) return <AdminInstall />;
  if (!staffUser) return <AdminLogin />;

  return (
    <div className="admin-grid min-h-screen bg-night text-white">
      <AdminChrome>
        <Routes>
          <Route index element={<Guard perm="dashboard"><Dashboard /></Guard>} />
          <Route path="products" element={<Guard perm="products"><ProductsPage /></Guard>} />
          <Route path="categories" element={<Guard perm="categories"><CategoriesPage /></Guard>} />
          <Route path="media" element={<Guard perm="media"><MediaPage /></Guard>} />
          <Route path="orders" element={<Guard perm="orders"><OrdersPage /></Guard>} />
          <Route path="maintenance" element={<Guard perm="maintenance"><MaintenanceAdmin /></Guard>} />
          <Route path="customers" element={<Guard perm="customers"><CustomersPage /></Guard>} />
          <Route path="payments" element={<Guard perm="payments"><PaymentsPage /></Guard>} />
          <Route path="staff" element={<Guard perm="staff"><StaffPage /></Guard>} />
          <Route path="reports" element={<Guard perm="reports"><ReportsPage /></Guard>} />
          <Route path="settings" element={<Guard perm="settings"><SettingsPage /></Guard>} />
          <Route path="profile" element={<ProfilePage />} />
          <Route path="install" element={<AdminInstall />} />
          <Route path="*" element={<Guard perm="dashboard"><Dashboard /></Guard>} />
        </Routes>
      </AdminChrome>
    </div>
  );
}

function Guard({ perm, children }: { perm: PermissionKey; children: ReactNode }) {
  const { can } = useStore();
  if (!can(perm)) {
    return (
      <div className="rounded-3xl border border-white/10 bg-panel p-10 text-center">
        <Lock className="mx-auto mb-3 text-gold" />
        <h2 className="text-xl font-bold">صلاحية غير ممنوحة</h2>
        <p className="mt-2 text-sm text-white/50">هذا القسم خارج صلاحيات حسابك. اطلب من المالك توسيع الصلاحية.</p>
      </div>
    );
  }
  return <>{children}</>;
}

const NAV: { to: string; label: string; icon: ReactNode; perm: PermissionKey }[] = [
  { to: "/admin", label: "غرفة التحكم", icon: <LayoutDashboard size={18} />, perm: "dashboard" },
  { to: "/admin/products", label: "المنتجات", icon: <Boxes size={18} />, perm: "products" },
  { to: "/admin/categories", label: "الأقسام", icon: <Folders size={18} />, perm: "categories" },
  { to: "/admin/media", label: "الوسائط", icon: <ImageIcon size={18} />, perm: "media" },
  { to: "/admin/orders", label: "الطلبات", icon: <ClipboardList size={18} />, perm: "orders" },
  { to: "/admin/maintenance", label: "الصيانة", icon: <Wrench size={18} />, perm: "maintenance" },
  { to: "/admin/customers", label: "العملاء", icon: <Users size={18} />, perm: "customers" },
  { to: "/admin/payments", label: "المالية", icon: <BadgeDollarSign size={18} />, perm: "payments" },
  { to: "/admin/staff", label: "المساعدون", icon: <UserCog size={18} />, perm: "staff" },
  { to: "/admin/reports", label: "التقارير", icon: <BarChart3 size={18} />, perm: "reports" },
  { to: "/admin/settings", label: "الإعدادات", icon: <Settings size={18} />, perm: "settings" },
];

function AdminChrome({ children }: { children: ReactNode }) {
  const { staffUser, can, logoutStaff, state } = useStore();
  const nav = useNavigate();
  const [open, setOpen] = useState(false);
  const items = NAV.filter((n) => can(n.perm));

  const side = (
    <div className="flex h-full flex-col">
      <div className="px-3 py-4">
        <NajeebLogo compact light />
        <div className="mt-1 text-[11px] text-gold">ADMIN MINI APP</div>
      </div>
      <nav className="flex-1 space-y-1 overflow-auto px-3 pb-4">
        {items.map((n) => (
          <NavLink
            key={n.to}
            to={n.to}
            end={n.to === "/admin"}
            onClick={() => setOpen(false)}
            className={({ isActive }) =>
              cn(
                "flex items-center gap-3 rounded-2xl px-3 py-2.5 text-sm font-semibold",
                isActive ? "bg-gold text-night" : "text-white/70 hover:bg-white/5",
              )
            }
          >
            {n.icon}
            {n.label}
          </NavLink>
        ))}
        <NavLink
          to="/admin/profile"
          onClick={() => setOpen(false)}
          className={({ isActive }) =>
            cn("flex items-center gap-3 rounded-2xl px-3 py-2.5 text-sm font-semibold", isActive ? "bg-gold text-night" : "text-white/70 hover:bg-white/5")
          }
        >
          <Shield size={18} /> حسابي
        </NavLink>
        <NavLink
          to="/admin/install"
          onClick={() => setOpen(false)}
          className={({ isActive }) =>
            cn("flex items-center gap-3 rounded-2xl px-3 py-2.5 text-sm font-semibold", isActive ? "bg-gold text-night" : "text-white/70 hover:bg-white/5")
          }
        >
          <Smartphone size={18} /> تثبيت التطبيق
        </NavLink>
      </nav>
      <button
        className="m-3 flex items-center gap-2 rounded-2xl bg-white/5 px-3 py-3 text-sm text-white/70"
        onClick={() => {
          logoutStaff();
          nav("/admin");
        }}
      >
        <LogOut size={16} /> خروج آمن
      </button>
    </div>
  );

  return (
    <div className="mx-auto flex min-h-screen max-w-[1400px]">
      <aside className="sticky top-0 hidden h-screen w-64 shrink-0 border-l border-white/5 bg-panel/80 lg:block">{side}</aside>
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex items-center gap-3 border-b border-white/5 bg-night/80 px-4 py-3 backdrop-blur">
          <button className="rounded-xl p-2 lg:hidden" onClick={() => setOpen(true)} aria-label="القائمة">
            <Gauge />
          </button>
          <div className="min-w-0 flex-1">
            <div className="truncate text-sm font-bold">{staffUser?.name}</div>
            <div className="truncate text-[11px] text-white/40">
              {staffUser?.role === "owner" ? "مالك النظام" : "مساعد بصلاحيات محدودة"} · {staffUser?.username}
            </div>
          </div>
          <span className="hidden items-center gap-1 rounded-full bg-white/5 px-3 py-1 text-[11px] text-white/50 sm:flex">
            <Bell size={12} /> {state.bookings.filter((b) => b.status === "new").length} صيانة جديدة
          </span>
        </header>
        <div className="p-4 md:p-6">{children}</div>
      </div>
      {open ? (
        <div className="fixed inset-0 z-50 bg-black/50 lg:hidden" onClick={() => setOpen(false)}>
          <aside className="absolute inset-y-0 right-0 w-72 bg-panel" onClick={(e) => e.stopPropagation()}>
            {side}
          </aside>
        </div>
      ) : null}
    </div>
  );
}

function AdminLogin() {
  const { adminLogin, state } = useStore();
  const nav = useNavigate();
  const [form, setForm] = useState({ username: "", password: "", phone: "", email: "" });
  const [err, setErr] = useState("");
  const [hint, setHint] = useState(false);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (!form.username || !form.password || !form.phone || !form.email) {
      setErr("الدخول يتطلب اسم المستخدم وكلمة المرور ورقم الجوال والبريد الإلكتروني معاً.");
      return;
    }
    const r = adminLogin(form.username, form.password, form.phone, form.email);
    if (r) setErr(r);
    else nav("/admin");
  };

  return (
    <div className="admin-grid flex min-h-screen items-center justify-center bg-night p-4 text-white">
      <div className="w-full max-w-md rounded-[2rem] border border-white/10 bg-panel p-6 shadow-2xl">
        <div className="text-center">
          <div className="mb-4 flex justify-center">
            <NajeebLogo light />
          </div>
          <h1 className="mt-2 text-2xl font-black">غرفة تحكم المالك</h1>
          <p className="mt-2 text-sm text-white/50">لوحة إدارة المنتجات والحجوزات والصيانة والفنيين — تطبيق مصغر منفصل عن منصة العملاء</p>
        </div>
        <form onSubmit={submit} className="mt-6 space-y-3">
          <label className="block">
            <span className="mb-1 flex items-center gap-1 text-xs text-white/50">
              <UserCog size={12} /> اسم المستخدم
            </span>
            <input className={adminInputClass} value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} autoComplete="username" />
          </label>
          <label className="block">
            <span className="mb-1 flex items-center gap-1 text-xs text-white/50">
              <Lock size={12} /> كلمة المرور
            </span>
            <input type="password" className={adminInputClass} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} autoComplete="current-password" />
          </label>
          <label className="block">
            <span className="mb-1 flex items-center gap-1 text-xs text-white/50">
              <Phone size={12} /> رقم الجوال
            </span>
            <input className={adminInputClass} value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} inputMode="tel" />
          </label>
          <label className="block">
            <span className="mb-1 flex items-center gap-1 text-xs text-white/50">
              <Mail size={12} /> البريد الإلكتروني
            </span>
            <input type="email" className={adminInputClass} value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} autoComplete="email" />
          </label>
          {err ? <p className="text-sm text-rose-400">{err}</p> : null}
          <button className="w-full rounded-2xl bg-gold py-3 font-black text-night">دخول لوحة التحكم</button>
        </form>
        <Link to="/admin/install" className="mt-4 block text-center text-sm text-gold">
          📲 تثبيت لوحة المدير كتطبيق
        </Link>
        <button type="button" onClick={() => setHint(!hint)} className="mt-3 w-full text-center text-[11px] text-white/35">
          عرض بيانات تجريبية للمعاينة
        </button>
        {hint ? (
          <div className="mt-2 rounded-2xl bg-night p-3 text-[11px] leading-6 text-white/60">
            <div>المالك: najeeb / admin123 / {state.staff[0]?.phone} / {state.staff[0]?.email}</div>
            <div>مساعد محدود: saleh / saleh123 / 0555123456 / saleh@alnajeeb.sa</div>
          </div>
        ) : null}
        <div className="mt-5 rounded-2xl bg-white px-3 py-2" dir="ltr">
          <HalaLogo />
        </div>
        <p className="mt-3 text-center text-[10px] leading-5 text-white/30">
          ملكية النظام: {HALA_SOFT.name} · {HALA_SOFT.lead} ·{" "}
          <a href={`https://wa.me/${HALA_SOFT.wa}`} className="text-gold" target="_blank" rel="noreferrer">
            {HALA_SOFT.phoneIntl}
          </a>
        </p>
      </div>
    </div>
  );
}

function AdminInstall() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-night p-4 text-white">
      <div className="w-full max-w-md rounded-[2rem] border border-white/10 bg-panel p-6 text-center">
        <div className="flex justify-center">
          <NajeebLogo light />
        </div>
        <p className="mt-4 text-[11px] tracking-[0.25em] text-gold">ADMIN MINI APP</p>
        <h1 className="mt-2 text-2xl font-black">🎛️ تثبيت لوحة إدارة النجيب</h1>
        <p className="mt-3 text-sm leading-7 text-white/60">
          تطبيق مصغر يفتح مباشرة على لوحة المدير لإدارة المنتجات والأسعار والوسائط والأقسام والحجوزات والمدفوعات والأمن.
        </p>
        <p className="mt-3 text-xs text-white/40">إن لم يظهر زر التثبيت، افتح قائمة المتصفح ⋮ واختر «تثبيت التطبيق» أو «إضافة إلى الشاشة الرئيسية».</p>
        <div className="mt-6 grid grid-cols-2 gap-2 text-xs">
          <div className="rounded-2xl bg-night p-3">📦 إدارة المعدات</div>
          <div className="rounded-2xl bg-night p-3">📱 رفع من الجوال</div>
          <div className="rounded-2xl bg-night p-3">🏦 المال والمدفوعات</div>
          <div className="rounded-2xl bg-night p-3">🛡️ الأمن والذكاء</div>
        </div>
        <Link to="/admin" className="mt-6 inline-block rounded-full bg-gold px-5 py-3 text-sm font-black text-night">
          ← العودة إلى لوحة المدير
        </Link>
      </div>
    </div>
  );
}

function Dashboard() {
  const { state, products, parentCategories } = useStore();
  const sales = state.orders.filter((o) => o.status !== "cancelled").reduce((s, o) => s + o.total, 0);
  const paid = state.payments.filter((p) => p.status === "paid").reduce((s, p) => s + p.amount, 0);
  const low = products.filter((p) => p.stock <= 2);
  const cards = [
    { l: "قيمة الطلبات", v: formatSar(sales) },
    { l: "تحصيل مدفوع", v: formatSar(paid) },
    { l: "المعدات", v: String(products.length) },
    { l: "طلبات معلّقة", v: String(state.orders.filter((o) => o.status === "pending").length) },
  ];
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-black">غرفة التحكم</h1>
        <p className="text-sm text-white/45">إدارة حقيقية لكل صغيرة وكبيرة داخل معرض الشركة</p>
      </div>
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {cards.map((c) => (
          <div key={c.l} className="rounded-3xl border border-white/8 bg-panel p-5">
            <div className="text-xs text-white/40">{c.l}</div>
            <div className="mt-2 text-2xl font-black text-gold-2">{c.v}</div>
          </div>
        ))}
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <div className="rounded-3xl border border-white/8 bg-panel p-5">
          <h2 className="font-bold">نشاط أخير</h2>
          <ul className="mt-3 space-y-3 text-sm">
            {state.activity.slice(0, 8).map((a) => (
              <li key={a.id} className="flex justify-between gap-3 border-b border-white/5 pb-2">
                <span>
                  <span className="text-gold">{a.actor}</span> — {a.action}
                </span>
                <span className="shrink-0 text-[11px] text-white/35">{formatDate(a.at)}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="rounded-3xl border border-white/8 bg-panel p-5">
          <h2 className="font-bold">مخزون منخفض</h2>
          <ul className="mt-3 space-y-2 text-sm">
            {low.slice(0, 8).map((p) => (
              <li key={p.id} className="flex justify-between">
                <span className="text-white/80">{p.name}</span>
                <span className="text-rose-400">{p.stock}</span>
              </li>
            ))}
          </ul>
          <h2 className="mt-6 font-bold">توزيع الأقسام</h2>
          <ul className="mt-3 space-y-2 text-sm">
            {parentCategories.map((c) => {
              const n = products.filter((p) => p.categoryId === c.id).length;
              const pct = products.length ? Math.round((n / products.length) * 100) : 0;
              return (
                <li key={c.id}>
                  <div className="mb-1 flex justify-between text-xs">
                    <span>{c.name}</span>
                    <span>{n}</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-white/10">
                    <div className="h-1.5 rounded-full bg-gold" style={{ width: `${pct}%` }} />
                  </div>
                </li>
              );
            })}
          </ul>
        </div>
      </div>
    </div>
  );
}

function emptyProduct(catId: string, subId: string): Product {
  return {
    id: uid("p"),
    name: "",
    nameEn: "",
    sku: `NJ-${Math.floor(3000 + Math.random() * 6000)}`,
    categoryId: catId,
    subcategoryId: subId,
    brand: "",
    origin: "إيطالي",
    condition: "new",
    price: 0,
    stock: 1,
    capacity: "",
    power: "",
    year: 2026,
    description: "",
    features: [],
    images: [],
    videos: [],
    featured: false,
    isNewArrival: true,
    isOffer: false,
    createdAt: nowIso(),
  };
}

function ProductsPage() {
  const { products, categories, parentCategories, subcategories, saveProduct, deleteProduct, can, log } = useStore();
  const [q, setQ] = useState("");
  const [edit, setEdit] = useState<Product | null>(null);
  const [err, setErr] = useState("");
  const list = products.filter((p) => !q || p.name.includes(q) || p.sku.includes(q) || p.brand.toLowerCase().includes(q.toLowerCase()));

  const onSave = () => {
    if (!edit) return;
    if (!edit.name || !edit.price) {
      setErr("الاسم والسعر مطلوبان");
      return;
    }
    const sub = categories.find((c) => c.id === edit.subcategoryId);
    const product: Product = {
      ...edit,
      categoryId: sub?.parentId || edit.categoryId,
      features: typeof (edit as Product & { featuresText?: string }).features === "object" ? edit.features : edit.features,
    };
    saveProduct(product);
    log(`حفظ المنتج ${product.name}`);
    setEdit(null);
  };

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-2xl font-black">المنتجات والمعدات</h1>
        <button
          className="flex items-center gap-2 rounded-full bg-gold px-4 py-2 text-sm font-black text-night"
          onClick={() => {
            const first = parentCategories[0];
            const sub = first ? subcategories(first.id)[0] : undefined;
            setErr("");
            setEdit(emptyProduct(first?.id || "washers", sub?.id || "computer"));
          }}
        >
          <Plus size={16} /> معدة جديدة
        </button>
      </div>
      <input className={cn(adminInputClass, "mt-4")} placeholder="بحث بالاسم أو الرمز..." value={q} onChange={(e) => setQ(e.target.value)} />
      <div className="mt-4 overflow-auto rounded-3xl border border-white/8">
        <table className="w-full min-w-[720px] text-right text-sm">
          <thead className="bg-panel text-white/40">
            <tr>
              <th className="p-3">المعدة</th>
              <th className="p-3">السعر</th>
              <th className="p-3">المخزون</th>
              <th className="p-3">الحالة</th>
              <th className="p-3"> </th>
            </tr>
          </thead>
          <tbody>
            {list.map((p) => (
              <tr key={p.id} className="border-t border-white/5">
                <td className="p-3">
                  <div className="flex items-center gap-3">
                    <img src={p.images[0] || "/images/washer-industrial.jpg"} className="h-12 w-12 rounded-xl object-cover" alt="" />
                    <div>
                      <div className="font-bold">{p.name}</div>
                      <div className="text-[11px] text-white/40">{p.sku} · {p.brand}</div>
                    </div>
                  </div>
                </td>
                <td className="p-3">
                  {can("prices") ? formatSar(p.price) : "•••"}
                  {p.oldPrice ? <div className="text-[11px] text-white/30 line-through">{formatSar(p.oldPrice)}</div> : null}
                </td>
                <td className="p-3">{p.stock}</td>
                <td className="p-3">{p.condition === "new" ? "جديد" : "مستعمل"}</td>
                <td className="p-3">
                  <button className="text-gold" onClick={() => { setErr(""); setEdit({ ...p }); }}>تعديل</button>
                  <button className="mr-3 text-rose-400" onClick={() => { if (confirm("حذف المعدة؟")) { deleteProduct(p.id); log(`حذف ${p.name}`); } }}>حذف</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Modal open={!!edit} onClose={() => setEdit(null)} title={edit && products.some((p) => p.id === edit.id) ? "تعديل معدة" : "إضافة معدة"} wide>
        {edit ? (
          <div className="grid gap-3 md:grid-cols-2">
            <Field label="الاسم بالعربي">
              <input className={adminInputClass} value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} />
            </Field>
            <Field label="الاسم بالإنجليزي">
              <input className={adminInputClass} value={edit.nameEn} onChange={(e) => setEdit({ ...edit, nameEn: e.target.value })} />
            </Field>
            <Field label="العلامة">
              <input className={adminInputClass} value={edit.brand} onChange={(e) => setEdit({ ...edit, brand: e.target.value })} />
            </Field>
            <Field label="رمز المخزون">
              <input className={adminInputClass} value={edit.sku} onChange={(e) => setEdit({ ...edit, sku: e.target.value })} />
            </Field>
            <Field label="القسم الفرعي">
              <select
                className={adminInputClass}
                value={edit.subcategoryId}
                onChange={(e) => {
                  const sub = categories.find((c) => c.id === e.target.value);
                  setEdit({ ...edit, subcategoryId: e.target.value, categoryId: sub?.parentId || e.target.value });
                }}
              >
                {parentCategories.map((p) => (
                  <optgroup key={p.id} label={p.name}>
                    {subcategories(p.id).map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.name}
                      </option>
                    ))}
                  </optgroup>
                ))}
              </select>
            </Field>
            <Field label="المنشأ">
              <select className={adminInputClass} value={edit.origin} onChange={(e) => setEdit({ ...edit, origin: e.target.value as Product["origin"] })}>
                {["إيطالي", "تركي", "ألماني", "أمريكي", "صيني"].map((o) => (
                  <option key={o}>{o}</option>
                ))}
              </select>
            </Field>
            <Field label="الحالة">
              <select className={adminInputClass} value={edit.condition} onChange={(e) => setEdit({ ...edit, condition: e.target.value as Product["condition"] })}>
                <option value="new">جديد كرت</option>
                <option value="used">مستعمل مضمون</option>
              </select>
            </Field>
            <Field label="السعر">
              <input
                type="number"
                className={adminInputClass}
                disabled={!can("prices")}
                value={edit.price}
                onChange={(e) => setEdit({ ...edit, price: Number(e.target.value) })}
              />
            </Field>
            <Field label="السعر قبل الخصم">
              <input
                type="number"
                className={adminInputClass}
                disabled={!can("prices")}
                value={edit.oldPrice || ""}
                onChange={(e) => setEdit({ ...edit, oldPrice: e.target.value ? Number(e.target.value) : undefined, isOffer: !!e.target.value })}
              />
            </Field>
            <Field label="المخزون">
              <input type="number" className={adminInputClass} value={edit.stock} onChange={(e) => setEdit({ ...edit, stock: Number(e.target.value) })} />
            </Field>
            <Field label="السعة">
              <input className={adminInputClass} value={edit.capacity} onChange={(e) => setEdit({ ...edit, capacity: e.target.value })} />
            </Field>
            <Field label="القدرة">
              <input className={adminInputClass} value={edit.power} onChange={(e) => setEdit({ ...edit, power: e.target.value })} />
            </Field>
            <Field label="سنة الصنع">
              <input type="number" className={adminInputClass} value={edit.year} onChange={(e) => setEdit({ ...edit, year: Number(e.target.value) })} />
            </Field>
            <div className="md:col-span-2">
              <Field label="الوصف">
                <textarea className={adminInputClass} rows={3} value={edit.description} onChange={(e) => setEdit({ ...edit, description: e.target.value })} />
              </Field>
            </div>
            <div className="md:col-span-2">
              <Field label="المميزات (سطر لكل ميزة)">
                <textarea className={adminInputClass} rows={3} value={edit.features.join("\n")} onChange={(e) => setEdit({ ...edit, features: e.target.value.split("\n") })} />
              </Field>
            </div>
            {can("media") ? (
              <div className="md:col-span-2 space-y-2">
                <Field label="صور (رفع من الجهاز)">
                  <input
                    type="file"
                    accept="image/*"
                    multiple
                    className="text-sm"
                    onChange={async (e) => {
                      try {
                        const files = e.target.files;
                        if (!files) return;
                        const urls: string[] = [];
                        for (const f of Array.from(files)) urls.push(await readFileAsDataUrl(f));
                        setEdit({ ...edit, images: [...edit.images, ...urls] });
                      } catch (ex) {
                        setErr(ex instanceof Error ? ex.message : "تعذر الرفع");
                      }
                    }}
                  />
                </Field>
                <div className="flex flex-wrap gap-2">
                  {edit.images.map((src, i) => (
                    <div key={i} className="relative">
                      <img src={src} className="h-16 w-20 rounded-xl object-cover" alt="" />
                      <button type="button" className="absolute -top-1 -left-1 rounded-full bg-rose-600 p-1" onClick={() => setEdit({ ...edit, images: edit.images.filter((_, j) => j !== i) })}>
                        <Trash2 size={10} />
                      </button>
                    </div>
                  ))}
                </div>
                <Field label="رابط صورة إضافي">
                  <input
                    className={adminInputClass}
                    placeholder="https://..."
                    onKeyDown={(e) => {
                      const t = e.target as HTMLInputElement;
                      if (e.key === "Enter" && t.value) {
                        e.preventDefault();
                        setEdit({ ...edit, images: [...edit.images, t.value] });
                        t.value = "";
                      }
                    }}
                  />
                </Field>
                <Field label="فيديو (رفع أو رابط)">
                  <input
                    type="file"
                    accept="video/*"
                    className="mb-2 text-sm"
                    onChange={async (e) => {
                      try {
                        const f = e.target.files?.[0];
                        if (!f) return;
                        const url = await readFileAsDataUrl(f);
                        setEdit({ ...edit, videos: [...edit.videos, url] });
                      } catch (ex) {
                        setErr(ex instanceof Error ? ex.message : "تعذر رفع الفيديو");
                      }
                    }}
                  />
                  <input
                    className={adminInputClass}
                    placeholder="الصق رابط فيديو ثم Enter"
                    onKeyDown={(e) => {
                      const t = e.target as HTMLInputElement;
                      if (e.key === "Enter" && t.value) {
                        e.preventDefault();
                        setEdit({ ...edit, videos: [...edit.videos, t.value] });
                        t.value = "";
                      }
                    }}
                  />
                  {edit.videos.map((v, i) => (
                    <div key={i} className="mt-1 flex items-center justify-between text-xs text-white/50">
                      <span className="truncate">{v.slice(0, 48)}</span>
                      <button type="button" onClick={() => setEdit({ ...edit, videos: edit.videos.filter((_, j) => j !== i) })}>
                        حذف
                      </button>
                    </div>
                  ))}
                </Field>
              </div>
            ) : (
              <p className="md:col-span-2 text-xs text-white/40">رفع الصور والفيديو يحتاج صلاحية الوسائط.</p>
            )}
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={edit.featured} onChange={(e) => setEdit({ ...edit, featured: e.target.checked })} /> مميز
            </label>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={edit.isNewArrival} onChange={(e) => setEdit({ ...edit, isNewArrival: e.target.checked })} /> وصل حديثاً
            </label>
            {err ? <p className="md:col-span-2 text-sm text-rose-400">{err}</p> : null}
            <div className="md:col-span-2">
              <button type="button" onClick={onSave} className="rounded-2xl bg-gold px-5 py-3 font-black text-night">
                حفظ المعدة
              </button>
            </div>
          </div>
        ) : null}
      </Modal>
    </div>
  );
}

function CategoriesPage() {
  const { categories, parentCategories, saveCategory, deleteCategory, log } = useStore();
  const blank = (): Category => ({
    id: uid("cat"),
    name: "",
    nameEn: "",
    emoji: "🧺",
    description: "",
    image: "/images/washer-industrial.jpg",
    parentId: null,
    order: categories.length + 1,
  });
  const [edit, setEdit] = useState<Category | null>(null);

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-black">الأقسام والأقسام الفرعية</h1>
        <button className="rounded-full bg-gold px-4 py-2 text-sm font-black text-night" onClick={() => setEdit(blank())}>
          قسم جديد
        </button>
      </div>
      <div className="mt-6 space-y-4">
        {parentCategories.map((p) => (
          <div key={p.id} className="rounded-3xl border border-white/8 bg-panel p-4">
            <div className="flex items-center justify-between gap-2">
              <h2 className="font-extrabold">
                {p.emoji} {p.name}
              </h2>
              <div className="flex gap-3 text-sm">
                <button className="text-gold" onClick={() => setEdit({ ...p })}>
                  تعديل
                </button>
                <button
                  className="text-emerald-400"
                  onClick={() =>
                    setEdit({
                      ...blank(),
                      parentId: p.id,
                      emoji: p.emoji,
                      image: p.image,
                    })
                  }
                >
                  + فرعي
                </button>
                <button className="text-rose-400" onClick={() => { if (confirm("حذف القسم وفروعه؟")) { deleteCategory(p.id); log(`حذف قسم ${p.name}`); } }}>
                  حذف
                </button>
              </div>
            </div>
            <div className="mt-3 grid gap-2 md:grid-cols-2">
              {categories
                .filter((c) => c.parentId === p.id)
                .map((s) => (
                  <div key={s.id} className="flex items-center justify-between rounded-2xl bg-night px-3 py-2 text-sm">
                    <span>
                      {s.emoji} {s.name}
                    </span>
                    <span className="flex gap-3">
                      <button className="text-gold" onClick={() => setEdit({ ...s })}>
                        تعديل
                      </button>
                      <button className="text-rose-400" onClick={() => deleteCategory(s.id)}>
                        حذف
                      </button>
                    </span>
                  </div>
                ))}
            </div>
          </div>
        ))}
      </div>
      <Modal open={!!edit} onClose={() => setEdit(null)} title="حفظ القسم">
        {edit ? (
          <div className="space-y-3">
            <Field label="الاسم">
              <input className={adminInputClass} value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} />
            </Field>
            <Field label="English">
              <input className={adminInputClass} value={edit.nameEn} onChange={(e) => setEdit({ ...edit, nameEn: e.target.value })} />
            </Field>
            <Field label="أيقونة إيموجي">
              <input className={adminInputClass} value={edit.emoji} onChange={(e) => setEdit({ ...edit, emoji: e.target.value })} />
            </Field>
            <Field label="الوصف">
              <input className={adminInputClass} value={edit.description} onChange={(e) => setEdit({ ...edit, description: e.target.value })} />
            </Field>
            <Field label="يتبع قسماً رئيسياً؟">
              <select className={adminInputClass} value={edit.parentId || ""} onChange={(e) => setEdit({ ...edit, parentId: e.target.value || null })}>
                <option value="">قسم رئيسي</option>
                {parentCategories.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="صورة الغلاف (رابط أو رفع)">
              <input
                type="file"
                accept="image/*"
                className="mb-2 text-sm"
                onChange={async (e) => {
                  const f = e.target.files?.[0];
                  if (!f) return;
                  setEdit({ ...edit, image: await readFileAsDataUrl(f) });
                }}
              />
              <input className={adminInputClass} value={edit.image} onChange={(e) => setEdit({ ...edit, image: e.target.value })} />
            </Field>
            <button
              className="rounded-2xl bg-gold px-5 py-3 font-black text-night"
              onClick={() => {
                if (!edit.name) return;
                saveCategory(edit);
                log(`حفظ قسم ${edit.name}`);
                setEdit(null);
              }}
            >
              حفظ
            </button>
          </div>
        ) : null}
      </Modal>
    </div>
  );
}

function MediaPage() {
  const { products, saveProduct, can } = useStore();
  const items = products.flatMap((p) => [
    ...p.images.map((src, i) => ({ type: "image" as const, src, product: p, i })),
    ...p.videos.map((src, i) => ({ type: "video" as const, src, product: p, i })),
  ]);
  return (
    <div>
      <h1 className="text-2xl font-black">مكتبة الصور والفيديو</h1>
      <p className="mt-1 text-sm text-white/45">ارفع من صفحة المنتج أو الصق الروابط. المساعد يحتاج صلاحية الوسائط.</p>
      <div className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-4">
        {items.map((it, idx) => (
          <div key={idx} className="overflow-hidden rounded-3xl border border-white/8 bg-panel">
            {it.type === "image" ? (
              <img src={it.src} className="h-32 w-full object-cover" alt="" />
            ) : (
              <video src={it.src} className="h-32 w-full object-cover" />
            )}
            <div className="p-2 text-[11px] text-white/50">
              {it.product.name}
              {can("media") ? (
                <button
                  className="mr-2 text-rose-400"
                  onClick={() => {
                    if (it.type === "image") saveProduct({ ...it.product, images: it.product.images.filter((_, j) => j !== it.i) });
                    else saveProduct({ ...it.product, videos: it.product.videos.filter((_, j) => j !== it.i) });
                  }}
                >
                  حذف
                </button>
              ) : null}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function OrdersPage() {
  const { state, setOrderStatus } = useStore();
  const statuses: OrderStatus[] = ["pending", "confirmed", "processing", "shipped", "delivered", "cancelled"];
  return (
    <div>
      <h1 className="text-2xl font-black">الطلبات</h1>
      <div className="mt-4 space-y-3">
        {state.orders.map((o) => (
          <div key={o.id} className="rounded-3xl border border-white/8 bg-panel p-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <div className="font-bold">{o.id} · {o.customerName}</div>
                <div className="text-xs text-white/40">
                  {o.phone} · {o.city} · {formatDate(o.createdAt)}
                </div>
              </div>
              <div className="text-gold font-black">{formatSar(o.total)}</div>
            </div>
            <ul className="mt-2 text-sm text-white/70">
              {o.items.map((i) => (
                <li key={i.productId}>
                  {i.name} × {i.qty}
                </li>
              ))}
            </ul>
            <select className={cn(adminInputClass, "mt-3 max-w-xs")} value={o.status} onChange={(e) => setOrderStatus(o.id, e.target.value as OrderStatus)}>
              {statuses.map((s) => (
                <option key={s} value={s}>
                  {orderStatusLabel(s)}
                </option>
              ))}
            </select>
          </div>
        ))}
      </div>
    </div>
  );
}

function MaintenanceAdmin() {
  const { state, setBookingStatus, saveTechnician, deleteTechnician } = useStore();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [specialty, setSpecialty] = useState("غسالات");
  const [city, setCity] = useState("جدة");
  const bStatus: BookingStatus[] = ["new", "scheduled", "in_progress", "done", "cancelled"];
  return (
    <div className="grid gap-6 lg:grid-cols-5">
      <div className="lg:col-span-3">
        <h1 className="text-2xl font-black">حجوزات الصيانة</h1>
        <div className="mt-4 space-y-3">
          {state.bookings.map((b) => (
            <div key={b.id} className="rounded-3xl border border-white/8 bg-panel p-4 text-sm">
              <div className="font-bold">{b.customerName} · {b.equipment}</div>
              <p className="text-white/60">{b.issue}</p>
              <p className="mt-1 text-xs text-white/40">
                {b.phone} · {b.city} · {b.preferredDate}
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                <select className={adminInputClass} value={b.status} onChange={(e) => setBookingStatus(b.id, e.target.value as BookingStatus, b.technicianId)}>
                  {bStatus.map((s) => (
                    <option key={s} value={s}>
                      {bookingStatusLabel(s)}
                    </option>
                  ))}
                </select>
                <select className={adminInputClass} value={b.technicianId || ""} onChange={(e) => setBookingStatus(b.id, b.status, e.target.value || undefined)}>
                  <option value="">بدون فني</option>
                  {state.technicians.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          ))}
        </div>
      </div>
      <div className="lg:col-span-2">
        <h2 className="text-xl font-black">الفنيون</h2>
        <div className="mt-3 space-y-2">
          {state.technicians.map((t) => (
            <div key={t.id} className="flex items-center justify-between rounded-2xl bg-panel px-3 py-2 text-sm">
              <span>
                {t.name} · {t.specialty}
                <div className="text-[11px] text-white/40">{t.city} · {t.phone}</div>
              </span>
              <button className="text-rose-400" onClick={() => deleteTechnician(t.id)}>
                حذف
              </button>
            </div>
          ))}
        </div>
        <div className="mt-4 space-y-2 rounded-3xl border border-white/8 p-4">
          <div className="font-bold">إضافة فني</div>
          <input className={adminInputClass} placeholder="الاسم" value={name} onChange={(e) => setName(e.target.value)} />
          <input className={adminInputClass} placeholder="الجوال" value={phone} onChange={(e) => setPhone(e.target.value)} />
          <input className={adminInputClass} placeholder="التخصص" value={specialty} onChange={(e) => setSpecialty(e.target.value)} />
          <input className={adminInputClass} placeholder="المدينة" value={city} onChange={(e) => setCity(e.target.value)} />
          <button
            className="w-full rounded-2xl bg-gold py-2 font-black text-night"
            onClick={() => {
              if (!name || !phone) return;
              saveTechnician({ id: uid("tech"), name, phone, specialty, city, active: true });
              setName("");
              setPhone("");
            }}
          >
            حفظ الفني
          </button>
        </div>
      </div>
    </div>
  );
}

function CustomersPage() {
  const { state } = useStore();
  return (
    <div>
      <h1 className="text-2xl font-black">حسابات العملاء</h1>
      <div className="mt-4 overflow-auto rounded-3xl border border-white/8">
        <table className="w-full min-w-[640px] text-sm">
          <thead className="bg-panel text-white/40">
            <tr>
              <th className="p-3">الاسم</th>
              <th className="p-3">الجوال</th>
              <th className="p-3">البريد</th>
              <th className="p-3">المدينة</th>
            </tr>
          </thead>
          <tbody>
            {state.customers.map((c) => (
              <tr key={c.id} className="border-t border-white/5">
                <td className="p-3">{c.name}</td>
                <td className="p-3">{c.phone}</td>
                <td className="p-3">{c.email}</td>
                <td className="p-3">{c.city}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function PaymentsPage() {
  const { state, setPaymentStatus } = useStore();
  return (
    <div>
      <h1 className="text-2xl font-black">المدفوعات والمالية</h1>
      <div className="mt-4 space-y-3">
        {state.payments.map((p) => (
          <div key={p.id} className="flex flex-wrap items-center justify-between gap-3 rounded-3xl border border-white/8 bg-panel p-4">
            <div>
              <div className="font-bold">{p.orderId}</div>
              <div className="text-xs text-white/40">
                {p.method} · {formatDate(p.createdAt)} {p.note && `· ${p.note}`}
              </div>
            </div>
            <div className="font-black text-gold">{formatSar(p.amount)}</div>
            <select className={cn(adminInputClass, "max-w-[160px]")} value={p.status} onChange={(e) => setPaymentStatus(p.orderId, e.target.value as PaymentStatus)}>
              {(["unpaid", "paid", "refunded"] as PaymentStatus[]).map((s) => (
                <option key={s} value={s}>
                  {paymentStatusLabel(s)}
                </option>
              ))}
            </select>
          </div>
        ))}
      </div>
    </div>
  );
}

function StaffPage() {
  const { state, saveStaff, deleteStaff, log } = useStore();
  const blank = (): Staff => ({
    id: uid("staff"),
    role: "assistant",
    name: "",
    username: "",
    password: "",
    phone: "",
    email: "",
    active: true,
    permissions: ["dashboard", "products", "prices", "media", "categories"],
    createdAt: nowIso(),
  });
  const [edit, setEdit] = useState<Staff | null>(null);
  const [err, setErr] = useState("");

  return (
    <div>
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-black">المساعدون والصلاحيات</h1>
          <p className="text-sm text-white/45">أنشئ حسابات بدخول رباعي (مستخدم + كلمة مرور + جوال + بريد) وصلاحيات محدودة.</p>
        </div>
        <button className="rounded-full bg-gold px-4 py-2 text-sm font-black text-night" onClick={() => { setErr(""); setEdit(blank()); }}>
          مساعد جديد
        </button>
      </div>
      <div className="mt-5 space-y-3">
        {state.staff.map((s) => (
          <div key={s.id} className="rounded-3xl border border-white/8 bg-panel p-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <div className="font-bold">
                  {s.name} <span className="text-xs text-gold">{s.role === "owner" ? "مالك" : "مساعد"}</span>
                </div>
                <div className="text-xs text-white/40">
                  {s.username} · {s.phone} · {s.email} · {s.active ? "نشط" : "موقوف"}
                </div>
              </div>
              <div className="flex gap-3 text-sm">
                <button className="text-gold" onClick={() => { setErr(""); setEdit({ ...s }); }}>
                  تعديل
                </button>
                {s.role !== "owner" ? (
                  <button
                    className="text-rose-400"
                    onClick={() => {
                      const r = deleteStaff(s.id);
                      if (r) alert(r);
                      else log(`حذف مساعد ${s.name}`);
                    }}
                  >
                    حذف
                  </button>
                ) : null}
              </div>
            </div>
            <div className="mt-2 flex flex-wrap gap-1">
              {(s.role === "owner" ? OWNER_PERMISSIONS : s.permissions).map((p) => (
                <span key={p} className="rounded-full bg-white/5 px-2 py-0.5 text-[10px] text-white/60">
                  {ALL_PERMISSIONS.find((x) => x.key === p)?.label}
                </span>
              ))}
            </div>
          </div>
        ))}
      </div>
      <Modal open={!!edit} onClose={() => setEdit(null)} title="حساب الدخول للوحة" wide>
        {edit ? (
          <div className="grid gap-3 md:grid-cols-2">
            <Field label="الاسم الظاهر">
              <input className={adminInputClass} value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} />
            </Field>
            <Field label="اسم المستخدم">
              <input className={adminInputClass} value={edit.username} onChange={(e) => setEdit({ ...edit, username: e.target.value })} disabled={edit.role === "owner"} />
            </Field>
            <Field label="كلمة المرور">
              <input className={adminInputClass} value={edit.password} onChange={(e) => setEdit({ ...edit, password: e.target.value })} />
            </Field>
            <Field label="رقم الجوال">
              <input className={adminInputClass} value={edit.phone} onChange={(e) => setEdit({ ...edit, phone: e.target.value })} />
            </Field>
            <Field label="البريد الإلكتروني">
              <input className={adminInputClass} value={edit.email} onChange={(e) => setEdit({ ...edit, email: e.target.value })} />
            </Field>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={edit.active} disabled={edit.role === "owner"} onChange={(e) => setEdit({ ...edit, active: e.target.checked })} /> الحساب نشط
            </label>
            {edit.role === "assistant" ? (
              <div className="md:col-span-2">
                <div className="mb-2 text-xs font-bold text-white/50">صلاحيات محدودة</div>
                <div className="grid gap-2 sm:grid-cols-2">
                  {ALL_PERMISSIONS.map((p) => (
                    <label key={p.key} className="flex items-start gap-2 rounded-2xl bg-night p-3 text-sm">
                      <input
                        type="checkbox"
                        className="mt-1"
                        checked={edit.permissions.includes(p.key)}
                        onChange={(e) => {
                          const next = e.target.checked
                            ? [...edit.permissions, p.key]
                            : edit.permissions.filter((k) => k !== p.key);
                          setEdit({ ...edit, permissions: next });
                        }}
                      />
                      <span>
                        <span className="font-bold">{p.label}</span>
                        <span className="block text-[11px] text-white/40">{p.hint}</span>
                      </span>
                    </label>
                  ))}
                </div>
              </div>
            ) : (
              <p className="md:col-span-2 text-xs text-white/40">حساب المالك يملك كل الصلاحيات ولا يُحذف.</p>
            )}
            {err ? <p className="md:col-span-2 text-sm text-rose-400">{err}</p> : null}
            <div className="md:col-span-2">
              <button
                className="rounded-2xl bg-gold px-5 py-3 font-black text-night"
                onClick={() => {
                  if (!edit.name || !edit.username || !edit.password || !edit.phone || !edit.email) {
                    setErr("كل حقول الدخول الأربعة بالإضافة للاسم مطلوبة");
                    return;
                  }
                  const r = saveStaff(edit);
                  if (r) setErr(r);
                  else {
                    log(`حفظ حساب ${edit.name}`);
                    setEdit(null);
                  }
                }}
              >
                حفظ الحساب
              </button>
            </div>
          </div>
        ) : null}
      </Modal>
    </div>
  );
}

function ProfilePage() {
  const { staffUser, updateOwnProfile } = useStore();
  const [form, setForm] = useState({
    name: staffUser?.name || "",
    username: staffUser?.username || "",
    password: "",
    phone: staffUser?.phone || "",
    email: staffUser?.email || "",
  });
  const [msg, setMsg] = useState("");
  if (!staffUser) return null;
  return (
    <div className="max-w-lg">
      <h1 className="text-2xl font-black">حسابي في لوحة التحكم</h1>
      <p className="mt-1 text-sm text-white/45">يمكنك تعديل اسم المستخدم وكلمة المرور والجوال والبريد. الدخول التالي سيعتمد على القيم الجديدة الأربعة معاً.</p>
      <div className="mt-6 space-y-3 rounded-3xl border border-white/8 bg-panel p-5">
        <Field label="الاسم">
          <input className={adminInputClass} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        </Field>
        <Field label="اسم المستخدم">
          <input className={adminInputClass} value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} />
        </Field>
        <Field label="كلمة مرور جديدة (اتركها فارغة للإبقاء)">
          <input type="password" className={adminInputClass} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
        </Field>
        <Field label="رقم الجوال">
          <input className={adminInputClass} value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
        </Field>
        <Field label="البريد الإلكتروني">
          <input className={adminInputClass} value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
        </Field>
        {msg ? <p className="text-sm text-emerald-400">{msg}</p> : null}
        <button
          className="rounded-2xl bg-gold px-5 py-3 font-black text-night"
          onClick={() => {
            const r = updateOwnProfile(form);
            setMsg(r || "تم حفظ بيانات الدخول");
          }}
        >
          حفظ بياناتي
        </button>
      </div>
    </div>
  );
}

function ReportsPage() {
  const { state, products, parentCategories } = useStore();
  const byCat = parentCategories.map((c) => {
    const sold = state.orders.flatMap((o) => o.items).filter((i) => products.find((p) => p.id === i.productId)?.categoryId === c.id);
    const total = sold.reduce((s, i) => s + i.price * i.qty, 0);
    return { c, total, qty: sold.reduce((s, i) => s + i.qty, 0) };
  });
  return (
    <div>
      <h1 className="text-2xl font-black">التقارير</h1>
      <div className="mt-5 space-y-3">
        {byCat.map((r) => (
          <div key={r.c.id} className="flex items-center justify-between rounded-3xl bg-panel p-4">
            <span>
              {r.c.emoji} {r.c.name}
            </span>
            <span className="text-sm text-white/50">{r.qty} قطعة</span>
            <span className="font-black text-gold">{formatSar(r.total)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function SettingsPage() {
  const { state, updateCompany, resetDemo } = useStore();
  const [c, setC] = useState(state.company);
  return (
    <div className="max-w-lg space-y-4">
      <h1 className="text-2xl font-black">إعدادات الشركة</h1>
      <Field label="اسم الشركة">
        <input className={adminInputClass} value={c.name} onChange={(e) => setC({ ...c, name: e.target.value })} />
      </Field>
      <Field label="English">
        <input className={adminInputClass} value={c.nameEn} onChange={(e) => setC({ ...c, nameEn: e.target.value })} />
      </Field>
      <Field label="الهاتف">
        <input className={adminInputClass} value={c.phone} onChange={(e) => setC({ ...c, phone: e.target.value })} />
      </Field>
      <Field label="واتساب">
        <input className={adminInputClass} value={c.whatsapp} onChange={(e) => setC({ ...c, whatsapp: e.target.value })} />
      </Field>
      <Field label="البريد">
        <input className={adminInputClass} value={c.email} onChange={(e) => setC({ ...c, email: e.target.value })} />
      </Field>
      <Field label="المستودع">
        <input className={adminInputClass} value={c.warehouse} onChange={(e) => setC({ ...c, warehouse: e.target.value })} />
      </Field>
      <button className="rounded-2xl bg-gold px-5 py-3 font-black text-night" onClick={() => updateCompany(c)}>
        حفظ بيانات الشركة
      </button>
      <button
        className="block text-sm text-rose-400"
        onClick={() => {
          if (confirm("إعادة ضبط بيانات العرض التجريبية؟")) resetDemo();
        }}
      >
        إعادة ضبط بيانات المعاينة
      </button>
    </div>
  );
}


