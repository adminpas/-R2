import { HALA_SOFT } from "./lib";
import { cn } from "./utils/cn";

export function NajeebLogo({
  className,
  compact = false,
  light = false,
}: {
  className?: string;
  compact?: boolean;
  light?: boolean;
}) {
  return (
    <div className={cn("flex items-center gap-3", className)} dir="rtl">
      <svg viewBox="0 0 120 120" className={cn(compact ? "h-11 w-11" : "h-16 w-16 md:h-[72px] md:w-[72px]")} aria-hidden>
        <defs>
          <linearGradient id="ng" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#f3e0a6" />
            <stop offset=".5" stopColor="#c4a35a" />
            <stop offset="1" stopColor="#7c5c1e" />
          </linearGradient>
        </defs>
        <circle cx="60" cy="60" r="56" fill="#10242c" stroke="url(#ng)" strokeWidth="6" />
        <circle cx="60" cy="66" r="28" fill="none" stroke="#c4a35a" strokeWidth="8" />
        <circle cx="60" cy="66" r="10" fill="#c4a35a" />
        <rect x="40" y="22" width="40" height="12" rx="4" fill="url(#ng)" />
        <rect x="46" y="16" width="28" height="8" rx="3" fill="#e6cc8a" />
      </svg>
      <div className="leading-tight text-right">
        <div className={cn("font-black", compact ? "text-sm md:text-base" : "text-lg md:text-2xl", light ? "text-white" : "text-ink")}>
          شركة النجيب المتطورة
        </div>
        <div className={cn(compact ? "text-[10px] md:text-[11px]" : "text-xs md:text-sm", light ? "text-gold-2" : "text-sea")}>
          لمعدات المغاسل
        </div>
        {!compact && (
          <div className={cn("text-[10px] md:text-xs", light ? "text-white/60" : "text-ink/45")}>جدة · جديد ومستخدم</div>
        )}
      </div>
    </div>
  );
}

export function HalaLogo({ className, dark = false }: { className?: string; dark?: boolean }) {
  return (
    <a
      href={`https://wa.me/${HALA_SOFT.wa}`}
      target="_blank"
      rel="noreferrer"
      className={cn("inline-flex flex-col items-center", className)}
      title={`${HALA_SOFT.name} — ${HALA_SOFT.lead}`}
    >
      <img
        src="/hala-soft.svg"
        alt="هلا سوفت"
        dir="ltr"
        className={cn("h-16 w-auto max-w-[240px] object-contain", dark && "brightness-110")}
        style={{ transform: "none" }}
      />
      <span className={cn("mt-1 text-[10px] font-bold", dark ? "text-gold-2" : "text-[#3d156e]")}>
        {HALA_SOFT.name} · {HALA_SOFT.lead}
      </span>
    </a>
  );
}
