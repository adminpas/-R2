import { FormEvent, useMemo, useState, type ReactNode } from "react";
import { Link, NavLink, Route, Routes, useNavigate, useParams, useSearchParams } from "react-router-dom";
import {
  BadgeCheck,
  Hammer,
  Home,
  MapPin,
  Menu,
  Phone,
  Search,
  ShieldCheck,
  ShoppingBag,
  Sparkles,
  UserRound,
  Wrench,
  X,
} from "lucide-react";
import { SHOWCASE_POSTER, SHOWCASE_VIDEO } from "../data";
import { conditionLabel, formatDate, formatSar, orderStatusLabel, whatsappLink } from "../lib";
import { useStore } from "../store";
import type { Condition, Product } from "../types";
import { NajeebLogo } from "../brand";
import { ConditionBadge, Field, Price, ProductCard, SectionHead, inputClass } from "../ui";
import { cn } from "../utils/cn";
import {
  AboutPage,
  AdvisorPage,
  AuctionPage,
  BundlesPage,
  ClearancePage,
  HalaStamp,
  ImportPage,
  InstallPage,
  LegalPage,
  PlannerPage,
} from "./Modules";

function useFilteredProducts() {
  const { products } = useStore();
  const [params] = useSearchParams();
  const c = params.get("c") as Condition | null;
  return useMemo(() => {
    if (c === "new" || c === "used") return products.filter((p) => p.condition === c);
    return products;
  }, [products, c]);
}

export default function CustomerApp() {
  return (
    <div className="min-h-screen bg-sand text-ink">
      <TopBar />
      <Header />
      <main className="pb-24 md:pb-8">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/section/:id" element={<SectionPage />} />
          <Route path="/product/:id" element={<ProductPage />} />
          <Route path="/cart" element={<CartPage />} />
          <Route path="/checkout" element={<CheckoutPage />} />
          <Route path="/offers" element={<OffersPage />} />
          <Route path="/bundles" element={<BundlesPage />} />
          <Route path="/planner" element={<PlannerPage />} />
          <Route path="/auction" element={<AuctionPage />} />
          <Route path="/clearance" element={<ClearancePage />} />
          <Route path="/import" element={<ImportPage />} />
          <Route path="/advisor" element={<AdvisorPage />} />
          <Route path="/search" element={<SearchPage />} />
          <Route path="/login" element={<AuthPage mode="login" />} />
          <Route path="/register" element={<AuthPage mode="register" />} />
          <Route path="/account" element={<AccountPage />} />
          <Route path="/maintenance" element={<MaintenancePage />} />
          <Route path="/services" element={<ServicesPage />} />
          <Route path="/install" element={<InstallPage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/legal" element={<LegalPage />} />
          <Route path="*" element={<HomePage />} />
        </Routes>
      </main>
      <Footer />
      <MobileNav />
    </div>
  );
}

function TopBar() {
  const { state } = useStore();
  return (
    <div className="bg-ink text-sand">
      <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-2 px-4 py-2 text-[11px] md:text-xs">
        <div className="flex items-center gap-3">
          <span>🌍 المملكة</span>
          <span className="hidden sm:inline">🧺 جديد ومستخدم</span>
          <span className="hidden md:inline">🛡️ ضمان وفحص فني</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1">
            <MapPin size={12} /> {state.company.warehouse}
          </span>
          <a href={`tel:${state.company.phone}`} className="flex items-center gap-1 hover:text-gold-2">
            <Phone size={12} /> {state.company.phone}
          </a>
        </div>
      </div>
    </div>
  );
}

function Header() {
  const { cartCount, state } = useStore();
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const nav = useNavigate();
  const parents = useStore().parentCategories;

  const goSearch = (e: FormEvent) => {
    e.preventDefault();
    nav(`/search?q=${encodeURIComponent(q)}`);
    setOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 border-b border-ink/8 bg-sand/90 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-3">
        <button className="rounded-xl p-2 md:hidden" onClick={() => setOpen(true)} aria-label="القائمة">
          <Menu size={22} />
        </button>
        <Link to="/" className="min-w-0">
          <NajeebLogo compact />
        </Link>
        <form onSubmit={goSearch} className="mx-2 hidden flex-1 md:flex">
          <div className="flex w-full items-center rounded-2xl bg-white ring-1 ring-ink/10">
            <Search className="mr-3 ml-1 text-ink/40" size={18} />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="ابحث عن غسالة، نشافة، غلاية، مكبس..."
              className="w-full bg-transparent px-3 py-2.5 text-sm outline-none"
            />
          </div>
        </form>
        <div className="ms-auto flex items-center gap-1">
          <Link to="/account" className="rounded-2xl p-2.5 hover:bg-white" aria-label="حسابي">
            <UserRound size={20} />
          </Link>
          <Link to="/cart" className="relative rounded-2xl p-2.5 hover:bg-white" aria-label="السلة">
            <ShoppingBag size={20} />
            {cartCount > 0 ? (
              <span className="absolute -top-0.5 -left-0.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-rose-600 px-1 text-[10px] font-bold text-white">
                {cartCount}
              </span>
            ) : null}
          </Link>
        </div>
      </div>
      <nav className="mx-auto hidden max-w-7xl items-center gap-1 overflow-x-auto px-4 pb-3 no-scrollbar md:flex">
        {parents.map((c) => (
          <NavLink
            key={c.id}
            to={`/section/${c.id}`}
            className={({ isActive }) =>
              cn(
                "rounded-full px-3 py-1.5 text-sm font-semibold whitespace-nowrap",
                isActive ? "bg-ink text-gold-2" : "text-ink/70 hover:bg-white",
              )
            }
          >
            {c.emoji} {c.name.replace("قسم ", "")}
          </NavLink>
        ))}
        <NavLink to="/offers" className={({ isActive }) => cn("rounded-full px-3 py-1.5 text-sm font-semibold", isActive ? "bg-rose-600 text-white" : "text-rose-700 hover:bg-white")}>
          العروض
        </NavLink>
        <NavLink to="/bundles" className={({ isActive }) => cn("rounded-full px-3 py-1.5 text-sm font-semibold", isActive ? "bg-ink text-gold-2" : "text-ink/70 hover:bg-white")}>
          باقات جاهزة
        </NavLink>
        <NavLink to="/planner" className={({ isActive }) => cn("rounded-full px-3 py-1.5 text-sm font-semibold", isActive ? "bg-ink text-gold-2" : "text-ink/70 hover:bg-white")}>
          تجهيز بميزانية
        </NavLink>
        <NavLink to="/maintenance" className={({ isActive }) => cn("rounded-full px-3 py-1.5 text-sm font-semibold", isActive ? "bg-ink text-gold-2" : "text-ink/70 hover:bg-white")}>
          الصيانة
        </NavLink>
        <NavLink to="/services" className={({ isActive }) => cn("rounded-full px-3 py-1.5 text-sm font-semibold", isActive ? "bg-ink text-gold-2" : "text-ink/70 hover:bg-white")}>
          الخدمات
        </NavLink>
      </nav>
      {open ? (
        <div className="fixed inset-0 z-[70] bg-black/40 md:hidden" onClick={() => setOpen(false)}>
          <aside className="absolute inset-y-0 right-0 w-[86%] max-w-sm overflow-auto bg-sand p-5" onClick={(e) => e.stopPropagation()}>
            <div className="mb-4 flex items-center justify-between">
              <span className="font-extrabold">القائمة</span>
              <button onClick={() => setOpen(false)}>
                <X />
              </button>
            </div>
            <form onSubmit={goSearch} className="mb-4">
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="بحث..." className={inputClass} />
            </form>
            <div className="grid gap-1">
              {parents.map((c) => (
                <Link key={c.id} to={`/section/${c.id}`} onClick={() => setOpen(false)} className="rounded-2xl px-3 py-3 hover:bg-white">
                  {c.emoji} {c.name}
                </Link>
              ))}
              <Link to="/offers" onClick={() => setOpen(false)} className="rounded-2xl px-3 py-3">العروض</Link>
              <Link to="/bundles" onClick={() => setOpen(false)} className="rounded-2xl px-3 py-3">باقات جاهزة</Link>
              <Link to="/planner" onClick={() => setOpen(false)} className="rounded-2xl px-3 py-3">تجهيز بميزانية</Link>
              <Link to="/auction" onClick={() => setOpen(false)} className="rounded-2xl px-3 py-3">مزاد التمكين</Link>
              <Link to="/clearance" onClick={() => setOpen(false)} className="rounded-2xl px-3 py-3">التصفية اليومية</Link>
              <Link to="/import" onClick={() => setOpen(false)} className="rounded-2xl px-3 py-3">الاستيراد</Link>
              <Link to="/advisor" onClick={() => setOpen(false)} className="rounded-2xl px-3 py-3">مستشار المشروع</Link>
              <Link to="/maintenance" onClick={() => setOpen(false)} className="rounded-2xl px-3 py-3">الصيانة</Link>
              <Link to="/services" onClick={() => setOpen(false)} className="rounded-2xl px-3 py-3">الخدمات</Link>
              <Link to="/about" onClick={() => setOpen(false)} className="rounded-2xl px-3 py-3">عن النظام وحقوق الملكية</Link>
              <a href={whatsappLink(state.company.whatsapp)} className="mt-2 rounded-2xl bg-emerald-600 px-3 py-3 text-center font-bold text-white">واتساب المبيعات</a>
            </div>
          </aside>
        </div>
      ) : null}
    </header>
  );
}

function ConditionSwitch() {
  const [params, setParams] = useSearchParams();
  const c = params.get("c");
  const set = (v: string | null) => {
    const next = new URLSearchParams(params);
    if (!v) next.delete("c");
    else next.set("c", v);
    setParams(next, { replace: true });
  };
  const btn = (id: string | null, label: string) => (
    <button
      type="button"
      onClick={() => set(id)}
      className={cn(
        "rounded-full px-4 py-2 text-sm font-bold",
        (c || null) === id ? "bg-ink text-gold-2" : "bg-white text-ink/70 ring-1 ring-ink/10",
      )}
    >
      {label}
    </button>
  );
  return (
    <div className="flex flex-wrap gap-2">
      {btn(null, "الكل")}
      {btn("new", "جديد كرت")}
      {btn("used", "مستعمل مضمون")}
    </div>
  );
}

function HomePage() {
  const { parentCategories, subcategories } = useStore();
  const filtered = useFilteredProducts();
  const weekly = [...filtered].filter((p) => p.weeklyRank).sort((a, b) => (a.weeklyRank || 99) - (b.weeklyRank || 99));
  const arrivals = filtered.filter((p) => p.isNewArrival);
  const offers = filtered.filter((p) => p.isOffer);
  const featured = filtered.filter((p) => p.featured);

  return (
    <div>
      <section className="relative overflow-hidden">
        <img src="/images/hero-showroom.jpg" alt="معرض النجيب" className="h-[58vh] min-h-[420px] w-full object-cover md:h-[70vh]" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/55 to-ink/20" />
        <div className="absolute inset-0 flex items-end">
          <div className="mx-auto w-full max-w-7xl px-4 pb-10 pt-24 text-white">
            <div className="mb-4">
              <NajeebLogo light />
            </div>
            <p className="mb-3 inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1 text-xs font-semibold ring-1 ring-gold/40">
              <Sparkles size={14} className="text-gold-2" /> مستودع جدة · جديد كرت ومستعمل مفحوص
            </p>
            <h1 className="max-w-3xl text-3xl font-black leading-tight md:text-5xl">
              منصة شركة النجيب المتطورة لجميع أنواع معدات المغاسل
            </h1>
            <p className="mt-3 max-w-xl text-sm text-white/75 md:text-base">
              غسالات · نشافات · خطوط سجاد · مكابس · سيور · غلايات — إيطالي وتركي وألماني، تركيب وتشغيل وصيانة.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Link to="/section/washers" className="rounded-full bg-gold px-5 py-3 text-sm font-extrabold text-ink">
                تصفح المعرض
              </Link>
              <Link to="/offers" className="rounded-full bg-white/10 px-5 py-3 text-sm font-bold ring-1 ring-white/25">
                العروض الحالية
              </Link>
            </div>
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-7xl space-y-14 px-4 py-10">
        <ConditionSwitch />

        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 lg:grid-cols-8">
          {[
            ["/bundles", "📦", "باقات جاهزة"],
            ["/planner", "🧮", "تجهيز بميزانية"],
            ["/auction", "🔨", "مزاد التمكين"],
            ["/clearance", "📉", "تصفية يومية"],
            ["/import", "🌍", "استيراد"],
            ["/advisor", "🧭", "المستشار"],
            ["/maintenance", "🛠️", "صيانة"],
            ["/about", "ℹ️", "حقوق النظام"],
          ].map(([to, ic, lb]) => (
            <Link key={to} to={to} className="rounded-2xl bg-white px-3 py-3 text-center text-xs font-bold shadow-sm">
              <div className="text-lg">{ic}</div>
              {lb}
            </Link>
          ))}
        </div>

        <section>
          <SectionHead emoji="🔥" title="الأعلى طلباً هذا الأسبوع" hint="أكثر المعدات طلباً من أصحاب المغاسل والفنادق" />
          <div className="flex gap-4 overflow-x-auto pb-2 no-scrollbar">
            {(weekly.length ? weekly : featured.slice(0, 10)).map((p) => (
              <div key={p.id} className="w-64 shrink-0">
                <ProductCard product={p} />
              </div>
            ))}
          </div>
        </section>

        <section className="overflow-hidden rounded-[2rem] bg-ink text-white">
          <div className="grid md:grid-cols-2">
            <div className="p-6 md:p-10">
              <SectionHead emoji="📺" title="تابع استعراض المعدات" hint="جولة داخل مستودع جدة الرئيسي" />
              <p className="text-sm leading-7 text-white/70">
                شاهد خطوط الغسيل والنشاف والغلايات كما هي معروضة للمعاينة. يمكن ترتيب زيارة المعرض أو طلب فيديو خاص للمعدة قبل الشراء.
              </p>
            </div>
            <div className="relative min-h-[240px]">
              <video className="h-full w-full object-cover" poster={SHOWCASE_POSTER} controls playsInline>
                <source src={SHOWCASE_VIDEO} type="video/mp4" />
              </video>
            </div>
          </div>
        </section>

        <section>
          <SectionHead emoji="🆕" title="وصل حديثاً — جديد كرت" to="/search?c=new" hint="أحدث ما وصل مستودع جدة الرئيسي" />
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            {arrivals.slice(0, 8).map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>

        <section>
          <SectionHead emoji="💸" title="عروض وخصومات" to="/offers" hint="أسعار مخفّضة لفترة محدودة" />
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            {offers.slice(0, 8).map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>

        {parentCategories.map((cat) => {
          const subs = subcategories(cat.id);
          const items = filtered.filter((p) => p.categoryId === cat.id);
          return (
            <section key={cat.id} id={cat.id}>
              <SectionHead
                emoji={cat.emoji}
                title={cat.name}
                en={cat.nameEn}
                to={`/section/${cat.id}`}
                hint={`${cat.description} · ${items.length} قطعة ضمن الفلتر الحالي`}
              />
              <div className="mb-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                {subs.map((s) => {
                  const count = filtered.filter((p) => p.subcategoryId === s.id).length;
                  return (
                    <Link
                      key={s.id}
                      to={`/section/${s.id}`}
                      className="group relative overflow-hidden rounded-3xl bg-ink text-white"
                    >
                      <img src={s.image} alt={s.name} className="h-40 w-full object-cover opacity-60 transition group-hover:scale-105 group-hover:opacity-80" />
                      <div className="absolute inset-0 flex flex-col justify-end p-4">
                        <h3 className="font-extrabold">
                          {s.name} {s.emoji}
                        </h3>
                        <p className="text-xs text-white/70">
                          {count} قطعة متاحة · إيطالي وتركي
                        </p>
                        <span className="mt-1 text-xs font-bold text-gold-2">عرض الكل ›</span>
                      </div>
                    </Link>
                  );
                })}
              </div>
              <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
                {items.slice(0, 4).map((p) => (
                  <ProductCard key={p.id} product={p} />
                ))}
              </div>
            </section>
          );
        })}
      </div>
    </div>
  );
}

function SectionPage() {
  const { id } = useParams();
  const { categoryById, subcategories, products } = useStore();
  const [params] = useSearchParams();
  const c = params.get("c") as Condition | null;
  const cat = categoryById(id || "");
  const filtered = useMemo(() => {
    let list = products;
    if (c === "new" || c === "used") list = list.filter((p) => p.condition === c);
    if (!cat) return list;
    if (!cat.parentId) return list.filter((p) => p.categoryId === cat.id);
    return list.filter((p) => p.subcategoryId === cat.id);
  }, [products, cat, c]);

  if (!cat) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-16">
        القسم غير موجود
      </div>
    );
  }
  const kids = subcategories(cat.id);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <p className="text-sm text-ink/50">
        <Link to="/">الرئيسية</Link> / {cat.name}
      </p>
      <div className="mt-3 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black">
            {cat.emoji} {cat.name}
          </h1>
          <p className="mt-1 text-ink/60">{cat.description}</p>
        </div>
        <ConditionSwitch />
      </div>
      {kids.length ? (
        <div className="mt-6 flex gap-2 overflow-x-auto pb-2 no-scrollbar">
          {kids.map((s) => (
            <Link key={s.id} to={`/section/${s.id}`} className="rounded-full bg-white px-4 py-2 text-sm font-bold ring-1 ring-ink/10 whitespace-nowrap">
              {s.name}
            </Link>
          ))}
        </div>
      ) : null}
      <p className="mt-4 text-sm text-ink/50">{filtered.length} قطعة</p>
      <div className="mt-4 grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-4">
        {filtered.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
    </div>
  );
}

function ProductPage() {
  const { id } = useParams();
  const { productById, addToCart, products, state } = useStore();
  const p = productById(id || "");
  const [img, setImg] = useState(0);
  if (!p) return <div className="px-4 py-16">المعدة غير موجودة</div>;
  const related = products.filter((x) => x.subcategoryId === p.subcategoryId && x.id !== p.id).slice(0, 4);
  const wa = whatsappLink(
    state.company.whatsapp,
    `مرحباً، أريد الاستفسار عن ${p.name} (${p.sku}) بسعر ${p.price} ر.س`,
  );

  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <div className="grid gap-8 lg:grid-cols-2">
        <div>
          <div className="overflow-hidden rounded-[2rem] bg-white">
            <img src={p.images[img] || p.images[0]} alt={p.name} className="h-[360px] w-full object-cover md:h-[460px]" />
          </div>
          <div className="mt-3 flex gap-2 overflow-x-auto no-scrollbar">
            {p.images.map((src, i) => (
              <button
                key={src + i}
                type="button"
                onClick={() => setImg(i)}
                className={cn("h-16 w-20 overflow-hidden rounded-2xl ring-2", i === img ? "ring-gold" : "ring-transparent")}
              >
                <img src={src} className="h-full w-full object-cover" alt="" />
              </button>
            ))}
          </div>
          {p.videos[0] ? (
            <video className="mt-4 w-full rounded-[1.5rem]" controls poster={p.images[0]}>
              <source src={p.videos[0]} />
            </video>
          ) : null}
        </div>
        <div>
          <ConditionBadge condition={p.condition} />
          <h1 className="mt-3 text-3xl font-black leading-tight">{p.name}</h1>
          <p className="mt-1 text-sm text-ink/50">
            {p.nameEn} · {p.brand} · {p.origin} · SKU {p.sku}
          </p>
          <div className="mt-4">
            <Price value={p.price} old={p.oldPrice} />
          </div>
          <p className="mt-4 text-sm leading-7 text-ink/75">{p.description}</p>
          <dl className="mt-5 grid grid-cols-2 gap-3 text-sm">
            <Info label="السعة" value={p.capacity} />
            <Info label="القدرة" value={p.power} />
            <Info label="سنة الصنع" value={String(p.year)} />
            <Info label="المخزون" value={`${p.stock} قطعة`} />
          </dl>
          <ul className="mt-5 space-y-2 text-sm">
            {p.features.map((f) => (
              <li key={f} className="flex gap-2">
                <BadgeCheck size={16} className="mt-0.5 text-sea" /> {f}
              </li>
            ))}
          </ul>
          <div className="mt-6 flex flex-wrap gap-3">
            <button
              type="button"
              onClick={() => addToCart(p.id)}
              className="rounded-full bg-ink px-6 py-3 text-sm font-extrabold text-gold-2"
            >
              أضف إلى السلة
            </button>
            <a href={wa} target="_blank" rel="noreferrer" className="rounded-full bg-emerald-600 px-6 py-3 text-sm font-bold text-white">
              اطلب عبر واتساب
            </a>
          </div>
        </div>
      </div>
      {related.length ? (
        <div className="mt-14">
          <SectionHead emoji="✨" title="معدات مشابهة" />
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            {related.map((r) => (
              <ProductCard key={r.id} product={r} />
            ))}
          </div>
        </div>
      ) : null}
    </div>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl bg-white p-3">
      <div className="text-[11px] text-ink/45">{label}</div>
      <div className="font-bold">{value}</div>
    </div>
  );
}

function CartPage() {
  const { cartLines, cartTotal, setCartQty } = useStore();
  if (!cartLines.length) {
    return (
      <div className="mx-auto max-w-lg px-4 py-20 text-center">
        <ShoppingBag className="mx-auto mb-4 text-ink/30" size={42} />
        <h1 className="text-2xl font-black">السلة فارغة</h1>
        <Link to="/" className="mt-4 inline-block rounded-full bg-ink px-5 py-3 text-sm font-bold text-gold-2">
          العودة للمعرض
        </Link>
      </div>
    );
  }
  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      <h1 className="text-3xl font-black">سلة المشتريات</h1>
      <div className="mt-6 space-y-3">
        {cartLines.map(({ product, qty }) => (
          <div key={product.id} className="flex gap-3 rounded-3xl bg-white p-3">
            <img src={product.images[0]} alt="" className="h-24 w-24 rounded-2xl object-cover" />
            <div className="flex-1">
              <Link to={`/product/${product.id}`} className="font-bold">
                {product.name}
              </Link>
              <p className="text-xs text-ink/50">{conditionLabel(product.condition)}</p>
              <Price value={product.price} />
            </div>
            <div className="flex flex-col items-center justify-center gap-2">
              <button className="h-8 w-8 rounded-full bg-sand" onClick={() => setCartQty(product.id, qty + 1)}>+</button>
              <span className="text-sm font-bold">{qty}</span>
              <button className="h-8 w-8 rounded-full bg-sand" onClick={() => setCartQty(product.id, qty - 1)}>−</button>
            </div>
          </div>
        ))}
      </div>
      <div className="mt-6 flex items-center justify-between rounded-3xl bg-ink p-5 text-white">
        <div>
          <div className="text-xs text-white/50">الإجمالي</div>
          <div className="text-2xl font-black">{formatSar(cartTotal)}</div>
        </div>
        <Link to="/checkout" className="rounded-full bg-gold px-6 py-3 text-sm font-extrabold text-ink">
          إتمام الطلب
        </Link>
      </div>
    </div>
  );
}

function CheckoutPage() {
  const { cartLines, cartTotal, customer, placeOrder } = useStore();
  const nav = useNavigate();
  const [form, setForm] = useState({
    customerName: customer?.name || "",
    phone: customer?.phone || "",
    email: customer?.email || "",
    city: customer?.city || "جدة",
    address: customer?.address || "",
    notes: "",
  });
  const [err, setErr] = useState("");
  const [done, setDone] = useState<string | null>(null);

  if (done) {
    return (
      <div className="mx-auto max-w-lg px-4 py-20 text-center">
        <ShieldCheck className="mx-auto mb-3 text-emerald-600" size={48} />
        <h1 className="text-2xl font-black">تم استلام طلبك</h1>
        <p className="mt-2 text-ink/60">رقم الطلب {done}. سنتواصل معك لتأكيد التوريد والتركيب.</p>
        <Link to="/account" className="mt-6 inline-block rounded-full bg-ink px-5 py-3 text-sm font-bold text-gold-2">
          متابعة الطلبات
        </Link>
      </div>
    );
  }
  if (!cartLines.length) return <CartPage />;

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (!form.customerName || !form.phone) {
      setErr("الاسم والجوال مطلوبان");
      return;
    }
    const res = placeOrder(form);
    if (typeof res === "string") setErr(res);
    else setDone(res.id);
  };

  return (
    <div className="mx-auto grid max-w-5xl gap-6 px-4 py-8 lg:grid-cols-5">
      <form onSubmit={submit} className="space-y-3 rounded-[2rem] bg-white p-6 lg:col-span-3">
        <h1 className="text-2xl font-black">بيانات التوريد</h1>
        <Field label="الاسم / المنشأة">
          <input className={inputClass} value={form.customerName} onChange={(e) => setForm({ ...form, customerName: e.target.value })} />
        </Field>
        <Field label="الجوال">
          <input className={inputClass} value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
        </Field>
        <Field label="البريد">
          <input className={inputClass} value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
        </Field>
        <Field label="المدينة">
          <input className={inputClass} value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
        </Field>
        <Field label="العنوان / موقع التركيب">
          <input className={inputClass} value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
        </Field>
        <Field label="ملاحظات">
          <textarea className={inputClass} rows={3} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
        </Field>
        {err ? <p className="text-sm text-rose-600">{err}</p> : null}
        <button className="w-full rounded-full bg-ink py-3 font-extrabold text-gold-2">تأكيد الطلب · {formatSar(cartTotal)}</button>
      </form>
      <aside className="rounded-[2rem] bg-ink p-6 text-white lg:col-span-2">
        <h2 className="font-bold">ملخص</h2>
        <ul className="mt-4 space-y-3 text-sm">
          {cartLines.map((l) => (
            <li key={l.product.id} className="flex justify-between gap-2">
              <span className="text-white/80">
                {l.product.name} × {l.qty}
              </span>
              <span>{formatSar(l.product.price * l.qty)}</span>
            </li>
          ))}
        </ul>
        <div className="gold-line my-4" />
        <div className="flex justify-between text-lg font-black">
          <span>الإجمالي</span>
          <span>{formatSar(cartTotal)}</span>
        </div>
        <button type="button" onClick={() => nav("/cart")} className="mt-4 text-xs text-gold-2">
          تعديل السلة
        </button>
      </aside>
    </div>
  );
}

function OffersPage() {
  const products = useFilteredProducts().filter((p) => p.isOffer);
  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="text-3xl font-black">عروض وخصومات</h1>
      <div className="mt-4">
        <ConditionSwitch />
      </div>
      <div className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-4">
        {products.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
    </div>
  );
}

function SearchPage() {
  const [params] = useSearchParams();
  const q = (params.get("q") || "").trim();
  const list = useFilteredProducts();
  const results = useMemo(() => {
    if (!q) return list;
    const s = q.toLowerCase();
    return list.filter(
      (p) =>
        p.name.includes(q) ||
        p.nameEn.toLowerCase().includes(s) ||
        p.brand.toLowerCase().includes(s) ||
        p.sku.toLowerCase().includes(s) ||
        p.description.includes(q),
    );
  }, [list, q]);
  return (
    <div className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="text-3xl font-black">نتائج البحث</h1>
      <p className="mt-1 text-sm text-ink/50">
        {q ? `«${q}» — ${results.length} نتيجة` : `${results.length} معدة`}
      </p>
      <div className="mt-4">
        <ConditionSwitch />
      </div>
      <div className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-4">
        {results.map((p: Product) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
    </div>
  );
}

function AuthPage({ mode }: { mode: "login" | "register" }) {
  const { loginCustomer, registerCustomer } = useStore();
  const nav = useNavigate();
  const [err, setErr] = useState("");
  const [form, setForm] = useState({
    name: "",
    phone: "",
    email: "",
    password: "",
    city: "جدة",
    address: "",
  });
  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (mode === "login") {
      const r = loginCustomer(form.email || form.phone, form.password);
      if (r) setErr(r);
      else nav("/account");
    } else {
      if (!form.name || !form.phone || !form.email || !form.password) {
        setErr("أكمل البيانات المطلوبة");
        return;
      }
      const r = registerCustomer(form);
      if (r) setErr(r);
      else nav("/account");
    }
  };
  return (
    <div className="mx-auto max-w-md px-4 py-12">
      <div className="rounded-[2rem] bg-white p-6 shadow-sm">
        <h1 className="text-2xl font-black">{mode === "login" ? "دخول العملاء" : "إنشاء حساب عميل"}</h1>
        <p className="mt-1 text-sm text-ink/50">لوحة الإدارة منفصلة تماماً وغير ظاهرة للعملاء.</p>
        <form onSubmit={submit} className="mt-5 space-y-3">
          {mode === "register" ? (
            <>
              <Field label="الاسم / المنشأة">
                <input className={inputClass} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              </Field>
              <Field label="المدينة">
                <input className={inputClass} value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
              </Field>
              <Field label="العنوان">
                <input className={inputClass} value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
              </Field>
            </>
          ) : null}
          <Field label={mode === "login" ? "البريد أو الجوال" : "الجوال"}>
            <input className={inputClass} value={mode === "login" ? form.email : form.phone} onChange={(e) => setForm(mode === "login" ? { ...form, email: e.target.value } : { ...form, phone: e.target.value })} />
          </Field>
          {mode === "register" ? (
            <Field label="البريد">
              <input className={inputClass} value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </Field>
          ) : null}
          <Field label="كلمة المرور">
            <input type="password" className={inputClass} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} />
          </Field>
          {err ? <p className="text-sm text-rose-600">{err}</p> : null}
          <button className="w-full rounded-full bg-ink py-3 font-extrabold text-gold-2">{mode === "login" ? "دخول" : "تسجيل"}</button>
        </form>
        <p className="mt-4 text-center text-sm">
          {mode === "login" ? (
            <Link to="/register" className="font-bold text-sea">
              عميل جديد؟ أنشئ حساباً
            </Link>
          ) : (
            <Link to="/login" className="font-bold text-sea">
              لديك حساب؟ دخول
            </Link>
          )}
        </p>
      </div>
    </div>
  );
}

function AccountPage() {
  const { customer, logoutCustomer, state } = useStore();
  const nav = useNavigate();
  if (!customer) {
    return (
      <div className="mx-auto max-w-md px-4 py-16 text-center">
        <h1 className="text-2xl font-black">لوحة العميل</h1>
        <p className="mt-2 text-ink/60">سجّل الدخول لمتابعة الطلبات والحجوزات.</p>
        <div className="mt-6 flex justify-center gap-3">
          <Link to="/login" className="rounded-full bg-ink px-5 py-3 text-sm font-bold text-gold-2">
            دخول
          </Link>
          <Link to="/register" className="rounded-full bg-white px-5 py-3 text-sm font-bold ring-1 ring-ink/10">
            حساب جديد
          </Link>
        </div>
      </div>
    );
  }
  const orders = state.orders.filter((o) => o.customerId === customer.id || o.phone === customer.phone);
  const bookings = state.bookings.filter((b) => b.phone === customer.phone);
  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h1 className="text-3xl font-black">{customer.name}</h1>
          <p className="text-sm text-ink/50">
            {customer.city} · {customer.phone}
          </p>
        </div>
        <button
          className="rounded-full bg-white px-4 py-2 text-sm font-bold"
          onClick={() => {
            logoutCustomer();
            nav("/");
          }}
        >
          خروج
        </button>
      </div>
      <h2 className="mt-8 font-extrabold">طلباتي</h2>
      <div className="mt-3 space-y-3">
        {orders.length ? (
          orders.map((o) => (
            <div key={o.id} className="rounded-3xl bg-white p-4">
              <div className="flex justify-between gap-2">
                <span className="font-bold">{o.id}</span>
                <span className="text-sm">{orderStatusLabel(o.status)}</span>
              </div>
              <p className="text-xs text-ink/50">{formatDate(o.createdAt)}</p>
              <p className="mt-2 text-sm">{o.items.map((i) => `${i.name} × ${i.qty}`).join(" · ")}</p>
              <p className="mt-1 font-extrabold">{formatSar(o.total)}</p>
            </div>
          ))
        ) : (
          <p className="text-sm text-ink/50">لا توجد طلبات بعد.</p>
        )}
      </div>
      <h2 className="mt-8 font-extrabold">حجوزات الصيانة</h2>
      <div className="mt-3 space-y-3">
        {bookings.length ? (
          bookings.map((b) => (
            <div key={b.id} className="rounded-3xl bg-white p-4 text-sm">
              <div className="font-bold">{b.equipment}</div>
              <p className="text-ink/60">{b.issue}</p>
              <p className="mt-1 text-xs text-ink/45">{b.status}</p>
            </div>
          ))
        ) : (
          <p className="text-sm text-ink/50">لا حجوزات.</p>
        )}
      </div>
    </div>
  );
}

function MaintenancePage() {
  const { addBooking, customer } = useStore();
  const [done, setDone] = useState(false);
  const [form, setForm] = useState({
    customerName: customer?.name || "",
    phone: customer?.phone || "",
    email: customer?.email || "",
    city: customer?.city || "جدة",
    equipment: "",
    issue: "",
    preferredDate: "",
  });
  const submit = (e: FormEvent) => {
    e.preventDefault();
    addBooking(form);
    setDone(true);
  };
  return (
    <div className="mx-auto grid max-w-6xl gap-8 px-4 py-10 lg:grid-cols-2">
      <div>
        <p className="text-sm font-bold text-sea">خدمة ما بعد البيع</p>
        <h1 className="mt-2 text-3xl font-black">الصيانة والفحص الفني</h1>
        <p className="mt-3 text-ink/65 leading-7">
          فريق فني في جدة ومكة لتشغيل المعدات، الصيانة الدورية، وقطع الغيار الأصلية. اطلب زيارة فني وسيتم جدولة الموعد من غرفة التحكم.
        </p>
        <img src="/images/warehouse.jpg" alt="" className="mt-6 h-64 w-full rounded-[2rem] object-cover" />
      </div>
      <form onSubmit={submit} className="rounded-[2rem] bg-white p-6">
        {done ? (
          <div className="py-10 text-center">
            <Wrench className="mx-auto mb-3 text-sea" />
            <h2 className="text-xl font-black">تم إرسال طلب الصيانة</h2>
            <p className="mt-2 text-sm text-ink/60">سيتواصل معك الفني لتأكيد الموعد.</p>
          </div>
        ) : (
          <div className="space-y-3">
            <h2 className="text-xl font-black">حجز زيارة فني</h2>
            <Field label="الاسم">
              <input className={inputClass} required value={form.customerName} onChange={(e) => setForm({ ...form, customerName: e.target.value })} />
            </Field>
            <Field label="الجوال">
              <input className={inputClass} required value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            </Field>
            <Field label="البريد">
              <input className={inputClass} value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </Field>
            <Field label="المدينة">
              <input className={inputClass} value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
            </Field>
            <Field label="المعدة">
              <input className={inputClass} required value={form.equipment} onChange={(e) => setForm({ ...form, equipment: e.target.value })} />
            </Field>
            <Field label="وصف العطل">
              <textarea className={inputClass} rows={3} required value={form.issue} onChange={(e) => setForm({ ...form, issue: e.target.value })} />
            </Field>
            <Field label="التاريخ المفضل">
              <input type="date" className={inputClass} value={form.preferredDate} onChange={(e) => setForm({ ...form, preferredDate: e.target.value })} />
            </Field>
            <button className="w-full rounded-full bg-ink py-3 font-extrabold text-gold-2">إرسال الحجز</button>
          </div>
        )}
      </form>
    </div>
  );
}

function ServicesPage() {
  const items = [
    { t: "التركيب والتشغيل", d: "تركيب في موقع المغسلة مع تجربة تشغيل وتدريب العمال." },
    { t: "قطع الغيار", d: "مخزون سيور، طارات، محابس بخار، وحساسات من مستودع جدة." },
    { t: "عقود الصيانة", d: "زيارة دورية شهرية أو ربع سنوية للفنادق والمغاسل الكبرى." },
    { t: "تجهيز مغسلة كاملة", d: "دراسة مساحة، اختيار الخط، غلاية، مكابس وسيور حسب الطاقة الإنتاجية." },
  ];
  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <h1 className="text-3xl font-black">خدمات النجيب</h1>
      <div className="mt-6 grid gap-4 md:grid-cols-2">
        {items.map((i) => (
          <div key={i.t} className="rounded-[2rem] bg-white p-6">
            <h2 className="text-xl font-extrabold">{i.t}</h2>
            <p className="mt-2 text-ink/65">{i.d}</p>
          </div>
        ))}
      </div>
    </div>
  );
}



function Footer() {
  const { state, parentCategories } = useStore();
  return (
    <footer className="border-t border-ink/10 bg-ink text-white">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-12 md:grid-cols-4">
        <div className="md:col-span-2">
          <NajeebLogo light />
          <p className="mt-4 max-w-md text-sm leading-7 text-white/65">
            المستودع الرئيسي: {state.company.warehouse} · هاتف: {state.company.phone} · واتساب: {state.company.whatsapp}
          </p>
          <div className="mt-4 flex flex-wrap gap-3 text-sm">
            <Link to="/install" className="rounded-full bg-white/10 px-3 py-1.5">
              📲 تثبيت تطبيق العملاء
            </Link>
            <Link to="/legal" className="rounded-full bg-white/10 px-3 py-1.5">
              الشروط والخصوصية
            </Link>
            <Link to="/about" className="rounded-full bg-white/10 px-3 py-1.5">
              عن النظام وحقوق الملكية
            </Link>
            <Link to="/auction" className="rounded-full bg-white/10 px-3 py-1.5">
              مزاد التمكين
            </Link>
            <Link to="/import" className="rounded-full bg-white/10 px-3 py-1.5">
              الاستيراد
            </Link>
            <Link to="/advisor" className="rounded-full bg-white/10 px-3 py-1.5">
              المستشار
            </Link>
          </div>
        </div>
        <div>
          <h3 className="font-bold">الأقسام</h3>
          <ul className="mt-3 space-y-2 text-sm text-white/70">
            {parentCategories.map((c) => (
              <li key={c.id}>
                <Link to={`/section/${c.id}`}>{c.name}</Link>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h3 className="font-bold">التواصل</h3>
          <ul className="mt-3 space-y-2 text-sm text-white/70">
            <li>
              <a href={`tel:${state.company.phone}`}>{state.company.phone}</a>
            </li>
            <li>
              <a href={whatsappLink(state.company.whatsapp)}>واتساب المبيعات</a>
            </li>
            <li>{state.company.email}</li>
          </ul>
        </div>
      </div>
      <HalaStamp />
    </footer>
  );
}

function MobileNav() {
  const { cartCount } = useStore();
  const item = (to: string, label: string, icon: ReactNode, badge?: number) => (
    <NavLink
      to={to}
      className={({ isActive }) =>
        cn("relative flex flex-1 flex-col items-center gap-0.5 py-2 text-[11px] font-bold", isActive ? "text-gold" : "text-white/60")
      }
    >
      {icon}
      {label}
      {badge ? <span className="absolute top-1 left-1/2 flex h-4 min-w-4 -translate-x-6 items-center justify-center rounded-full bg-rose-600 text-[9px] text-white">{badge}</span> : null}
    </NavLink>
  );
  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 flex border-t border-white/10 bg-ink/95 text-white backdrop-blur md:hidden">
      {item("/", "الرئيسية", <Home size={18} />)}
      {item("/offers", "العروض", <Sparkles size={18} />)}
      {item("/maintenance", "صيانة", <Hammer size={18} />)}
      {item("/cart", "السلة", <ShoppingBag size={18} />, cartCount)}
      {item("/account", "حسابي", <UserRound size={18} />)}
    </nav>
  );
}


