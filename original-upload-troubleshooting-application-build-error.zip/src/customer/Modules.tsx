import { FormEvent, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { HalaLogo, NajeebLogo } from "../brand";
import { HALA_SOFT, formatSar } from "../lib";
import { useStore } from "../store";
import { Field, ProductCard, inputClass } from "../ui";

export function HalaStamp() {
  return (
    <div className="border-t border-white/10 px-4 py-6 text-center text-xs leading-7 text-white/50">
      <div className="mx-auto mb-3 flex justify-center rounded-2xl bg-white px-4 py-3" dir="ltr">
        <HalaLogo />
      </div>
      <div>© 2026 جميع الحقوق محفوظة</div>
      <div className="mt-2 font-bold text-gold-2">💻 تطوير وملكية النظام: {HALA_SOFT.name} — {HALA_SOFT.country}</div>
      <div>
        رئيس المجموعة: {HALA_SOFT.lead} ·{" "}
        <a className="text-gold-2 underline" href={`https://wa.me/${HALA_SOFT.wa}`} target="_blank" rel="noreferrer">
          {HALA_SOFT.phoneIntl}
        </a>
      </div>
      <div className="mt-1">جميع حقوق ملكية النظام محفوظة لـ {HALA_SOFT.name} © 2026 — لا يجوز النسخ أو إعادة البيع دون إذن خطي.</div>
    </div>
  );
}

const PACKAGES = [
  { id: "pkg-small", tag: "🏠 مغسلة عادية", save: 12, title: "باقة مغسلة ملابس صغيرة — جاهزة للتشغيل", desc: "تكفي 80–120 كجم غسيل يومياً · مناسبة لمغسلة حي سكني", price: 42050, old: 47800, pieces: 4, warranty: 12, img: "/images/washer-industrial.jpg" },
  { id: "pkg-mid", tag: "🏢 مغسلة متوسطة", save: 14, title: "باقة مغسلة متوسطة — خط إنتاج متكامل", desc: "تكفي 250–400 كجم غسيل يومياً · مناسبة للمغاسل التجارية", price: 70000, old: 81400, pieces: 8, warranty: 12, img: "/images/hero-showroom.jpg" },
  { id: "pkg-central", tag: "🏭 مغسلة مركزية", save: 16, title: "باقة مغسلة مركزية — طاقة إنتاجية عالية", desc: "تكفي 1000+ كجم غسيل يومياً · تخدم عدة فروع أو منشآت", price: 96600, old: 115000, pieces: 12, warranty: 24, img: "/images/warehouse.jpg" },
  { id: "pkg-hotel", tag: "🏨 فنادق", save: 15, title: "باقة مغسلة فندق — بياضات ومفروشات", desc: "تخدم فندقاً حتى 150 غرفة · بياضات ومناشف ومفارش", price: 68600, old: 80700, pieces: 8, warranty: 24, img: "/images/dryer-industrial.jpg" },
  { id: "pkg-hospital", tag: "🏥 مستشفيات", save: 15, title: "باقة مغسلة مستشفى — تعقيم طبي", desc: "دورات تعقيم حرارية · مطابقة لاشتراطات المنشآت الصحية", price: 60700, old: 71400, pieces: 6, warranty: 24, img: "/images/press-steam.jpg" },
  { id: "pkg-carpet", tag: "🧶 سجاد وموكيت", save: 13, title: "باقة مغسلة سجاد وموكيت", desc: "خط غسيل وعصر وتجفيف للسجاد · حتى 500 م²/يوم", price: 65950, old: 75800, pieces: 3, warranty: 12, img: "/images/carpet-line.jpg" },
];

export function BundlesPage() {
  const { addToCart, products, state } = useStore();
  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <p className="text-xs font-bold tracking-[0.2em] text-sea">TURNKEY PACKAGES</p>
      <h1 className="mt-2 text-3xl font-black">📦 العروض المتكاملة — مغسلة جاهزة بصفقة واحدة</h1>
      <p className="mt-3 max-w-2xl text-ink/65">كل ما تحتاجه لتجهيز مغسلتك في باقة واحدة: المعدات + النقل + التركيب الميداني + التدريب على التشغيل + الضمان.</p>
      <div className="mt-8 grid gap-6 lg:grid-cols-2">
        {PACKAGES.map((p) => (
          <article key={p.id} className="overflow-hidden rounded-[2rem] bg-white shadow-sm">
            <img src={p.img} alt="" className="h-48 w-full object-cover" />
            <div className="p-5">
              <div className="flex items-center justify-between text-xs font-bold">
                <span>{p.tag}</span>
                <span className="rounded-full bg-rose-100 px-2 py-0.5 text-rose-700">وفّر {p.save}%</span>
              </div>
              <h2 className="mt-2 text-xl font-extrabold">{p.title}</h2>
              <p className="mt-1 text-sm text-ink/60">{p.desc}</p>
              <p className="mt-3 text-xs text-ink/45">سعر الباقة شاملاً التركيب</p>
              <div className="mt-1 flex items-baseline gap-2">
                <span className="text-2xl font-black">{formatSar(p.price)}</span>
                <span className="text-sm text-ink/35 line-through">{formatSar(p.old)}</span>
              </div>
              <p className="text-sm font-bold text-emerald-700">توفير {formatSar(p.old - p.price)}</p>
              <p className="mt-2 text-sm">
                <b>{p.pieces}</b> قطعة · <b>{p.warranty}</b> شهر ضمان
              </p>
              <p className="mt-2 text-xs text-sea">🚛 نقل وتركيب ميداني · 🎓 تدريب · 🛡️ ضمان شامل</p>
              <button
                className="mt-4 w-full rounded-full bg-ink py-3 text-sm font-extrabold text-gold-2"
                onClick={() => {
                  const match = products.find((x) => x.price <= p.price);
                  if (match) addToCart(match.id);
                }}
              >
                اطلب الباقة · واتساب {state.company.whatsapp}
              </button>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}

export function PlannerPage() {
  const { products } = useStore();
  const [budget, setBudget] = useState(80000);
  const pick = useMemo(() => {
    const pool = [...products].sort((a, b) => a.price - b.price);
    const out = [];
    let left = budget;
    for (const p of pool) {
      if (p.price <= left && out.length < 8) {
        out.push(p);
        left -= p.price;
      }
    }
    return { out, left, spent: budget - left };
  }, [products, budget]);
  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <h1 className="text-3xl font-black">🧮 تجهيز المغاسل بالميزانية</h1>
      <p className="mt-2 text-ink/65">أدخل رأس مالك ويقترح النظام باقة من معدات المستودع دون تجاوز المبلغ.</p>
      <div className="mt-6 rounded-[2rem] bg-white p-6">
        <label className="text-sm font-bold">الميزانية: {formatSar(budget)}</label>
        <input type="range" min={15000} max={300000} step={1000} value={budget} onChange={(e) => setBudget(Number(e.target.value))} className="mt-3 w-full" />
        <p className="mt-2 text-sm text-ink/50">المقترح {formatSar(pick.spent)} · المتبقي {formatSar(pick.left)}</p>
      </div>
      <div className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-4">
        {pick.out.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
    </div>
  );
}

export function AuctionPage() {
  const { products, addBooking } = useStore();
  const items = products.filter((p) => p.condition === "used").slice(0, 6);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [bid, setBid] = useState("");
  const [eq, setEq] = useState(items[0]?.name || "");
  const [ok, setOk] = useState(false);
  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <h1 className="text-3xl font-black">🔨 مزاد تمكين المشاريع</h1>
      <p className="mt-2 max-w-2xl text-ink/65">عروض سرّية بسعر قريب من التكلفة. لا يرى قيمة العرض سوى إدارة النظام. يُعلن الفائز بعد الترسية فقط.</p>
      <div className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-3">
        {items.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
      <form
        className="mt-8 max-w-lg space-y-3 rounded-[2rem] bg-white p-6"
        onSubmit={(e: FormEvent) => {
          e.preventDefault();
          addBooking({ customerName: name, phone, email: "", city: "جدة", equipment: eq, issue: `عرض مزاد سري: ${bid} ر.س`, preferredDate: "" });
          setOk(true);
        }}
      >
        <h2 className="font-extrabold">قدّم عرضاً سرياً</h2>
        {ok ? <p className="text-emerald-700">تم تسجيل عرضك بسرية لدى الإدارة.</p> : null}
        <Field label="الاسم"><input className={inputClass} required value={name} onChange={(e) => setName(e.target.value)} /></Field>
        <Field label="الجوال"><input className={inputClass} required value={phone} onChange={(e) => setPhone(e.target.value)} /></Field>
        <Field label="المعدة">
          <select className={inputClass} value={eq} onChange={(e) => setEq(e.target.value)}>
            {items.map((p) => (
              <option key={p.id}>{p.name}</option>
            ))}
          </select>
        </Field>
        <Field label="قيمة العرض (ر.س)"><input className={inputClass} required value={bid} onChange={(e) => setBid(e.target.value)} /></Field>
        <button className="w-full rounded-full bg-ink py-3 font-extrabold text-gold-2">إرسال سري</button>
      </form>
    </div>
  );
}

export function ClearancePage() {
  const { products } = useStore();
  const list = products.filter((p) => p.isOffer || p.condition === "used");
  return (
    <div className="mx-auto max-w-7xl px-4 py-10">
      <h1 className="text-3xl font-black">📉 التصفية اليومية</h1>
      <p className="mt-2 text-ink/65">خفض السعر لتصريف المخزون الراكد والمعدات المجددة — حتى نفاد الكمية.</p>
      <div className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-4">
        {list.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
    </div>
  );
}

export function ImportPage() {
  const { addBooking } = useStore();
  const [ok, setOk] = useState(false);
  const [form, setForm] = useState({ name: "", phone: "", equipment: "", city: "جدة", origin: "الخليج" });
  return (
    <div className="mx-auto max-w-xl px-4 py-10">
      <h1 className="text-3xl font-black">🌍 الطلبات والاستيراد</h1>
      <p className="mt-2 text-ink/65">نؤمّن أي معدة من داخل المملكة أو الخليج أو عالمياً ضمن نشاط الشركة.</p>
      <form
        className="mt-6 space-y-3 rounded-[2rem] bg-white p-6"
        onSubmit={(e) => {
          e.preventDefault();
          addBooking({ customerName: form.name, phone: form.phone, email: "", city: form.city, equipment: form.equipment, issue: `طلب استيراد من ${form.origin}`, preferredDate: "" });
          setOk(true);
        }}
      >
        {ok ? <p className="text-emerald-700">استلمنا طلب التأمين وسنتواصل بعرض سعر.</p> : null}
        <Field label="الاسم"><input className={inputClass} required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
        <Field label="الجوال"><input className={inputClass} required value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></Field>
        <Field label="المعدة"><input className={inputClass} required value={form.equipment} onChange={(e) => setForm({ ...form, equipment: e.target.value })} /></Field>
        <Field label="مصدر التوريد">
          <select className={inputClass} value={form.origin} onChange={(e) => setForm({ ...form, origin: e.target.value })}>
            <option>المملكة</option>
            <option>الخليج</option>
            <option>إيطاليا</option>
            <option>تركيا</option>
            <option>عالمي</option>
          </select>
        </Field>
        <button className="w-full rounded-full bg-ink py-3 font-extrabold text-gold-2">إرسال طلب التوريد</button>
      </form>
    </div>
  );
}

export function AdvisorPage() {
  const [budget, setBudget] = useState(80000);
  const [q, setQ] = useState("");
  const [a, setA] = useState("اسأل عن نوع المغسلة أو الميزانية أو التشغيل بعد التركيب.");
  return (
    <div className="mx-auto max-w-3xl px-4 py-10">
      <p className="text-xs font-bold tracking-[0.2em] text-sea">AI PROJECT ADVISOR</p>
      <h1 className="mt-2 text-3xl font-black">🧭 مستشار المشروع الذكي</h1>
      <p className="mt-2 text-ink/65">يرافقك من دراسة الجدوى حتى ما بعد التركيب. أرقام واقعية بلا مبالغة.</p>
      <div className="mt-6 rounded-[2rem] bg-white p-6">
        <p className="font-bold">هل رأس مالي يكفي؟ {formatSar(budget)}</p>
        <input type="range" min={20000} max={250000} step={1000} value={budget} onChange={(e) => setBudget(Number(e.target.value))} className="mt-3 w-full" />
        <p className="mt-3 text-sm leading-7 text-ink/70">
          {budget >= 42050
            ? "نعم، يمكن بدء مغسلة صغيرة أو متوسطة. أبقِ 10–15٪ للطوارئ والكهرباء. راجع العروض المتكاملة أو صفحة التجهيز بالميزانية."
            : "المبلغ أقل من باقة المغسلة الصغيرة (42,050 ر.س). ننصح بمعدة مستعملة مفحوصة أو طلب استيراد جزئي."}
        </p>
        <Link to="/planner" className="mt-3 inline-block text-sm font-bold text-sea">ابنِ الباقة تلقائياً ‹</Link>
      </div>
      <div className="mt-4 rounded-[2rem] bg-ink p-6 text-white">
        <p className="font-bold">💬 اسأل المستشار</p>
        <p className="mt-3 min-h-20 text-sm leading-7 text-white/75">{a}</p>
        <div className="mt-3 flex gap-2">
          <input className="flex-1 rounded-2xl bg-white/10 px-3 py-2 text-sm outline-none" value={q} onChange={(e) => setQ(e.target.value)} placeholder="مثال: مغسلة سجاد بـ 70 ألف في جدة" />
          <button
            className="rounded-2xl bg-gold px-4 py-2 text-sm font-black text-ink"
            onClick={() => {
              setA(`بخصوص «${q || "تجهيز مغسلة"}» وميزانية ${formatSar(budget)}: ابدأ بغسالة + نشافة متوافقة الجهد، ولا تشترِ غلاية مركزية قبل ثبوت الطلب. بعد التركيب راقب استهلاك الماء والكهرباء أسبوعياً.`);
              setQ("");
            }}
          >
            اسأل
          </button>
        </div>
      </div>
    </div>
  );
}

export function AboutPage() {
  const { state, products } = useStore();
  const modules = [
    ["🛒", "المتجر والأقسام", "عرض المعدات بأقسام رئيسية وفرعية قابلة للتوسع"],
    ["🔎", "البحث الذكي", "بحث بالاسم والنوع والحجم والجودة والسعر"],
    ["🧮", "تجهيز المغاسل بالميزانية", "بناء باقة متكاملة تلقائياً ضمن رأس المال"],
    ["📦", "العروض المتكاملة", "باقات جاهزة تشمل النقل والتركيب والتدريب والضمان"],
    ["🔨", "مزاد التمكين", "عروض سرّية بسعر قريب من التكلفة"],
    ["📉", "التصفية اليومية", "خفض السعر لتصريف المخزون الراكد"],
    ["🌍", "الطلبات والاستيراد", "تأمين أي معدة من المملكة أو الخليج أو عالمياً"],
    ["🧭", "مستشار المشروع", "دراسة جدوى ومتابعة ما بعد التركيب"],
    ["🛠️", "مركز الصيانة", "طلبات ميدانية وورشية مع تتبع الفني"],
    ["🛡️", "مركز الأمن", "دخول رباعي الحقول للوحة التحكم وصلاحيات محدودة"],
    ["🧠", "النواة الذكية", "توصيات تسعير ومخزون وبحث"],
    ["🎛️", "لوحة التحكم", "إدارة كاملة: أقسام، وسائط، أسعار، مساعدون"],
  ];
  return (
    <div className="mx-auto max-w-5xl px-4 py-10">
      <p className="text-xs font-bold tracking-[0.25em] text-sea">ABOUT & OWNERSHIP</p>
      <h1 className="mt-2 text-3xl font-black">ℹ️ عن النظام وحقوق الملكية</h1>
      <div className="mt-6 rounded-[2rem] bg-white p-5">
        <NajeebLogo />
      </div>
      <div className="mt-8 grid gap-4 md:grid-cols-2">
        <div className="rounded-[2rem] bg-white p-6">
          <h2 className="text-xl font-black">🏢 مالك المنصة التجارية</h2>
          <p className="mt-3 font-extrabold">{state.company.name}</p>
          <p className="text-sm text-ink/55">{state.company.nameEn}</p>
          <p className="mt-3 text-sm leading-7 text-ink/70">
            📍 جدة، المملكة العربية السعودية — {state.company.warehouse}
            <br />📞 {state.company.phone} · 💬 واتساب {state.company.whatsapp}
            <br />الرقم الضريبي: 310000000000003 · السجل التجاري: 4030000000
          </p>
        </div>
        <div className="rounded-[2rem] bg-ink p-6 text-white">
          <h2 className="text-xl font-black text-gold-2">💻 الجهة المطوّرة ومالك حقوق النظام</h2>
          <div className="mt-4 inline-block rounded-2xl bg-white px-3 py-2" dir="ltr">
            <HalaLogo />
          </div>
          <p className="mt-3 text-2xl font-black">{HALA_SOFT.name}</p>
          <p className="text-sm text-white/55">{HALA_SOFT.nameEn} · {HALA_SOFT.country}</p>
          <p className="mt-3 text-sm">رئيس المجموعة: <b>{HALA_SOFT.lead}</b></p>
          <a className="mt-2 inline-block text-gold-2" href={`https://wa.me/${HALA_SOFT.wa}`} target="_blank" rel="noreferrer">
            للتواصل وطلب الخدمة: {HALA_SOFT.phoneIntl}
          </a>
          <p className="mt-4 text-xs leading-6 text-white/55">
            جميع حقوق ملكية النظام محفوظة لمجموعة هلا سوفت. جميع الأكواد وتصميم الواجهات وبنية البيانات مملوكة للجهة المطوّرة. لا يجوز نسخ النظام أو إعادة بيعه أو اشتقاق أنظمة منه دون إذن خطي مسبق.
          </p>
        </div>
      </div>
      <h2 className="mt-10 text-xl font-black">⚡ وحدات النظام (12)</h2>
      <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {modules.map(([e, t, d]) => (
          <div key={t} className="rounded-3xl bg-white p-4">
            <div className="text-2xl">{e}</div>
            <div className="mt-1 font-extrabold">{t}</div>
            <p className="text-sm text-ink/55">{d}</p>
          </div>
        ))}
      </div>
      <p className="mt-6 text-sm text-ink/50">{products.length}+ معدة في المستودع · {state.company.warehouse}</p>
    </div>
  );
}

export function LegalPage() {
  const blocks = [
    ["📜 شروط استخدام المنصة والشراء", "المنصة تعرض معدات مملوكة لشركة النجيب المتطورة أو مصرحاً بعرضها. بيانات كل قطعة وسعرها وحالتها تُعتمد من الإدارة قبل النشر. الأسعار لا تشمل الشحن والتركيب والضريبة إلا إذا نُص على خلاف ذلك. لا يُعد الطلب ملزماً إلا بعد تأكيد الدفع أو تحقق التحويل."],
    ["⏳ الحجز المؤقت والعربون", "مدة الحجز المؤقت 24 ساعة بعد تأكيد العربون. لا تُحجب القطعة عند إنشاء تحويل لم يُتحقق منه بعد. العربون يُحتسب من قيمة الشراء وفق الأنظمة السعودية لحماية المستهلك."],
    ["🔐 سياسة الخصوصية", "نجمع الحد الأدنى: الاسم، الجوال، عنوان المنشأة، الطلبات. لا تُباع البيانات. يحق للعميل التصحيح والحذف وفق نظام حماية البيانات الشخصية السعودي PDPL. لا تُخزن أرقام البطاقات."],
    ["🔨 مزاد التمكين", "المزاد حملة تصفية لمعدات الشركة. العروض سرية أثناء المدة. يحق للشركة عدم الترسية إن لم يبلغ العرض الحد الأدنى. المزايدة لا تُعد دفعاً."],
    ["🛡️ الاسترجاع والضمان", "الجديد بضمان المصنع أو الشركة. المستعمل/المجدد بضمان بطاقة القطعة. الأعطال الناتجة عن توصيل غير مطابق أو صيانة غير معتمدة قد تخرج من الضمان بتقرير فني."],
    ["💻 ملكية النظام", `جميع حقوق ملكية النظام محفوظة لـ ${HALA_SOFT.name} — ${HALA_SOFT.country}. رئيس المجموعة ${HALA_SOFT.lead}. للتواصل وطلب الخدمة: ${HALA_SOFT.phoneIntl}.`],
  ];
  return (
    <div className="mx-auto max-w-3xl space-y-5 px-4 py-10">
      <h1 className="text-3xl font-black">الشروط والسياسات القانونية</h1>
      {blocks.map(([t, b]) => (
        <article key={t} className="rounded-[1.5rem] bg-white p-5">
          <h2 className="font-extrabold">{t}</h2>
          <p className="mt-2 text-sm leading-8 text-ink/70">{b}</p>
        </article>
      ))}
    </div>
  );
}

export function InstallPage() {
  return (
    <div className="mx-auto max-w-lg px-4 py-16 text-center">
      <p className="text-xs font-bold tracking-[0.25em] text-sea">UNIVERSAL INSTALL</p>
      <div className="mt-4 flex justify-center">
        <NajeebLogo />
      </div>
      <h1 className="mt-4 text-2xl font-black">📲 تثبيت المنصة كتطبيق</h1>
      <p className="mt-2 text-sm leading-7 text-ink/65">تعمل كتطبيق ومنصة ويب من نفس النظام على الجوال والكمبيوتر واللوحي.</p>
      <ol className="mt-6 space-y-2 rounded-[2rem] bg-white p-6 text-right text-sm text-ink/70">
        <li>1. استخدم رابط HTTPS دائم</li>
        <li>2. من قائمة المتصفح ⋮ اختر «تثبيت التطبيق» أو «إضافة إلى الشاشة الرئيسية»</li>
        <li>3. لوحة المدير تُثبّت من مسار الإدارة كتطبيق مصغّر منفصل</li>
        <li>4. كل الوظائف تعمل من المتصفح حتى بدون تثبيت</li>
      </ol>
      <p className="mt-4 text-xs text-ink/45">الأنظمة: Android · iOS · Windows · macOS · Linux · ChromeOS</p>
    </div>
  );
}
