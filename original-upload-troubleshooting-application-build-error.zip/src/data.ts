import type {
  AppState,
  Category,
  Product,
  Origin,
  Condition,
} from "./types";
import { OWNER_PERMISSIONS } from "./types";

const IMG = {
  washer: "/images/washer-industrial.jpg",
  dryer: "/images/dryer-industrial.jpg",
  press: "/images/press-steam.jpg",
  boiler: "/images/boiler.jpg",
  carpet: "/images/carpet-line.jpg",
  conveyor: "/images/conveyor.jpg",
  hero: "/images/hero-showroom.jpg",
  warehouse: "/images/warehouse.jpg",
  laundry1: "https://images.pexels.com/photos/8774443/pexels-photo-8774443.jpeg?auto=compress&cs=tinysrgb&w=1400",
  laundry2: "https://images.pexels.com/photos/7030070/pexels-photo-7030070.jpeg?auto=compress&cs=tinysrgb&w=1400",
  laundry3: "https://images.pexels.com/photos/8774395/pexels-photo-8774395.jpeg?auto=compress&cs=tinysrgb&w=1400",
  laundry4: "https://images.pexels.com/photos/8774451/pexels-photo-8774451.jpeg?auto=compress&cs=tinysrgb&w=1400",
  laundry5: "https://images.pexels.com/photos/8774400/pexels-photo-8774400.jpeg?auto=compress&cs=tinysrgb&w=1400",
  laundry6: "https://images.pexels.com/photos/36328526/pexels-photo-36328526.jpeg?auto=compress&cs=tinysrgb&w=1400",
  laundry7: "https://images.pexels.com/photos/27666740/pexels-photo-27666740.jpeg?auto=compress&cs=tinysrgb&w=1400",
  drum: "https://images.pexels.com/photos/34397245/pexels-photo-34397245.jpeg?auto=compress&cs=tinysrgb&w=1400",
  tanks: "https://images.pexels.com/photos/10040001/pexels-photo-10040001.jpeg?auto=compress&cs=tinysrgb&w=1400",
  steel: "https://images.pexels.com/photos/33514501/pexels-photo-33514501.jpeg?auto=compress&cs=tinysrgb&w=1400",
  belt: "https://images.pexels.com/photos/5532664/pexels-photo-5532664.jpeg?auto=compress&cs=tinysrgb&w=1400",
  belt2: "https://images.pexels.com/photos/5532660/pexels-photo-5532660.jpeg?auto=compress&cs=tinysrgb&w=1400",
};

export const SHOWCASE_VIDEO =
  "https://videos.pexels.com/video-files/8756706/8756706-hd_1920_1080_25fps.mp4";
export const SHOWCASE_POSTER =
  "https://images.pexels.com/videos/8756706/pexels-photo-8756706.jpeg?auto=compress&cs=tinysrgb&w=1400";

export const categories: Category[] = [
  { id: "washers", parentId: null, order: 1, name: "قسم الغسالات", nameEn: "Washers", emoji: "🫧", description: "غسالات كمبيوتر · غسالات فنادق · غسالات عادية · غسالات منزلية ضخمة", image: IMG.washer },
  { id: "computer", parentId: "washers", order: 1, name: "غسالات كمبيوتر", nameEn: "Computer Washers", emoji: "🫧", description: "غسالات صناعية ببرمجة كاملة", image: IMG.washer },
  { id: "hotel", parentId: "washers", order: 2, name: "غسالات فنادق", nameEn: "Hotel Washers", emoji: "🫧", description: "سعات كبيرة للفنادق والمستشفيات", image: IMG.laundry1 },
  { id: "ordinary", parentId: "washers", order: 3, name: "غسالات عادية", nameEn: "Ordinary Washers", emoji: "🫧", description: "غسالات تجارية اقتصادية", image: IMG.laundry2 },
  { id: "household", parentId: "washers", order: 4, name: "غسالات منزلية ضخمة", nameEn: "Heavy Household", emoji: "🫧", description: "للقصور والاستراحات", image: IMG.laundry7 },

  { id: "dryers", parentId: null, order: 2, name: "قسم النشافات", nameEn: "Dryers", emoji: "🔥", description: "نشافات غاز · نشافات كهرباء · نشافات بخار", image: IMG.dryer },
  { id: "gas", parentId: "dryers", order: 1, name: "نشافات غاز", nameEn: "Gas Dryers", emoji: "🔥", description: "كفاءة عالية واستهلاك أقل", image: IMG.dryer },
  { id: "electric", parentId: "dryers", order: 2, name: "نشافات كهرباء", nameEn: "Electric Dryers", emoji: "🔥", description: "تشغيل كهربائي مستقر", image: IMG.laundry6 },
  { id: "steam", parentId: "dryers", order: 3, name: "نشافات بخار", nameEn: "Steam Dryers", emoji: "🔥", description: "تجفيف بالبخار للفنادق", image: IMG.dryer },

  { id: "carpet", parentId: null, order: 3, name: "قسم خطوط السجاد", nameEn: "Carpet Line", emoji: "🧶", description: "خط غسيل أوتوماتيك · عصارات سجاد · نافضات غبار", image: IMG.carpet },
  { id: "auto-line", parentId: "carpet", order: 1, name: "خط غسيل أوتوماتيك", nameEn: "Auto Wash Line", emoji: "🧶", description: "خطوط كاملة لغسيل السجاد", image: IMG.carpet },
  { id: "centrifuge", parentId: "carpet", order: 2, name: "عصارات سجاد", nameEn: "Carpet Centrifuge", emoji: "🧶", description: "عصر عالي السرعة", image: IMG.drum },
  { id: "dust", parentId: "carpet", order: 3, name: "نافضات غبار", nameEn: "Dust Beaters", emoji: "🧶", description: "نافضات صناعية للسجاد", image: IMG.laundry5 },

  { id: "presses", parentId: null, order: 4, name: "قسم المكابس", nameEn: "Presses", emoji: "♨️", description: "مكابس بخار · قمصان · بناطيل · أسطوانية · تشطيب", image: IMG.press },
  { id: "press-steam", parentId: "presses", order: 1, name: "مكابس بخار", nameEn: "Steam Presses", emoji: "♨️", description: "مكابس بخار صناعية", image: IMG.press },
  { id: "press-shirt", parentId: "presses", order: 2, name: "مكابس قمصان", nameEn: "Shirt Presses", emoji: "♨️", description: "مكابس قميص احترافية", image: IMG.press },
  { id: "press-trouser", parentId: "presses", order: 3, name: "مكابس بناطيل", nameEn: "Trouser Presses", emoji: "♨️", description: "كبس بناطيل آلي", image: IMG.press },
  { id: "press-roller", parentId: "presses", order: 4, name: "مكابس أسطوانية", nameEn: "Roller Presses", emoji: "♨️", description: "أسطوانات كيّ كبيرة", image: IMG.steel },
  { id: "press-finishing", parentId: "presses", order: 5, name: "معدات تشطيب وتنفيخ", nameEn: "Finishing", emoji: "♨️", description: "تنفيخ وتشطيب الملابس", image: IMG.laundry4 },

  { id: "belts", parentId: null, order: 5, name: "قسم السيور المتحركة", nameEn: "Conveyor Belts", emoji: "⛓️", description: "سيور نقل · فرز · تغذية · محركات", image: IMG.conveyor },
  { id: "belt-conveyor", parentId: "belts", order: 1, name: "سيور نقل الغسيل", nameEn: "Laundry Conveyors", emoji: "⛓️", description: "سيور نقل داخل المغسلة", image: IMG.conveyor },
  { id: "belt-sort", parentId: "belts", order: 2, name: "سيور الفرز", nameEn: "Sorting Belts", emoji: "⛓️", description: "فرز أوتوماتيكي", image: IMG.belt },
  { id: "belt-feeding", parentId: "belts", order: 3, name: "سيور التغذية للمكواة", nameEn: "Feeding Belts", emoji: "⛓️", description: "تغذية المكابس", image: IMG.belt2 },
  { id: "belt-motor", parentId: "belts", order: 4, name: "محركات وطارات السيور", nameEn: "Motors & Pulleys", emoji: "⛓️", description: "قطع غيار السيور", image: IMG.steel },

  { id: "boilers", parentId: null, order: 6, name: "قسم المراجل والغلايات", nameEn: "Boilers", emoji: "🔧", description: "عمودية · أفقية · كهرباء · ديزل · غاز · مولدات بخار", image: IMG.boiler },
  { id: "boiler-vertical", parentId: "boilers", order: 1, name: "غلايات عمودية", nameEn: "Vertical Boilers", emoji: "🔧", description: "غلايات رأسية موفرة للمساحة", image: IMG.boiler },
  { id: "boiler-horizontal", parentId: "boilers", order: 2, name: "غلايات أفقية", nameEn: "Horizontal Boilers", emoji: "🔧", description: "غلايات أفقية عالية الإنتاج", image: IMG.tanks },
  { id: "boiler-electric", parentId: "boilers", order: 3, name: "غلايات كهربائية", nameEn: "Electric Boilers", emoji: "🔧", description: "بخار كهربائي نظيف", image: IMG.steel },
  { id: "boiler-diesel", parentId: "boilers", order: 4, name: "غلايات ديزل", nameEn: "Diesel Boilers", emoji: "🔧", description: "غلايات ديزل صناعية", image: IMG.boiler },
  { id: "boiler-gas", parentId: "boilers", order: 5, name: "غلايات غاز", nameEn: "Gas Boilers", emoji: "🔧", description: "غلايات غاز طبيعي/مسال", image: IMG.tanks },
  { id: "boiler-generator", parentId: "boilers", order: 6, name: "مولدات بخار فورية", nameEn: "Steam Generators", emoji: "🔧", description: "بخار فوري للمكابس", image: IMG.steel },
];

type Draft = {
  name: string;
  nameEn: string;
  brand: string;
  origin: Origin;
  condition: Condition;
  price: number;
  oldPrice?: number;
  stock: number;
  capacity: string;
  power: string;
  year: number;
  subcategoryId: string;
  images: string[];
  weeklyRank?: number;
  featured?: boolean;
  isNewArrival?: boolean;
  isOffer?: boolean;
  videos?: string[];
};

const drafts: Draft[] = [
  { name: "غسالة كمبيوتر 23 كجم دانوب", nameEn: "Danube 23kg Computer Washer", brand: "Danube", origin: "إيطالي", condition: "new", price: 48500, oldPrice: 54000, stock: 4, capacity: "23 كجم", power: "11 كيلو واط", year: 2026, subcategoryId: "computer", images: [IMG.washer, IMG.laundry3, IMG.drum], weeklyRank: 1, featured: true, isNewArrival: true, isOffer: true, videos: [SHOWCASE_VIDEO] },
  { name: "غسالة كمبيوتر 18 كجم إيميسا", nameEn: "Imesa 18kg Computer Washer", brand: "Imesa", origin: "إيطالي", condition: "used", price: 21900, stock: 2, capacity: "18 كجم", power: "9 كيلو واط", year: 2021, subcategoryId: "computer", images: [IMG.laundry2, IMG.washer] },
  { name: "غسالة فنادق 50 كجم جيرباو", nameEn: "Girbau 50kg Hotel Washer", brand: "Girbau", origin: "إيطالي", condition: "new", price: 128000, oldPrice: 139000, stock: 3, capacity: "50 كجم", power: "22 كيلو واط", year: 2026, subcategoryId: "hotel", images: [IMG.laundry1, IMG.washer, IMG.warehouse], weeklyRank: 2, featured: true, isNewArrival: true, isOffer: true },
  { name: "غسالة فنادق 35 كجم تولون", nameEn: "Tolon 35kg Hotel Washer", brand: "Tolon", origin: "تركي", condition: "used", price: 56000, stock: 1, capacity: "35 كجم", power: "16 كيلو واط", year: 2020, subcategoryId: "hotel", images: [IMG.laundry4, IMG.washer] },
  { name: "غسالة عادية 16 كجم يونيماك", nameEn: "Unimac 16kg Washer", brand: "Unimac", origin: "أمريكي", condition: "new", price: 27400, stock: 6, capacity: "16 كجم", power: "7.5 كيلو واط", year: 2025, subcategoryId: "ordinary", images: [IMG.laundry7, IMG.laundry2], weeklyRank: 6, featured: true },
  { name: "غسالة عادية 12 كجم أوزجان", nameEn: "Ozcan 12kg Washer", brand: "Özcan", origin: "تركي", condition: "used", price: 9800, stock: 5, capacity: "12 كجم", power: "5 كيلو واط", year: 2019, subcategoryId: "ordinary", images: [IMG.laundry5], isOffer: true, oldPrice: 12500 },
  { name: "غسالة منزلية ضخمة 21 كجم سبيد كوين", nameEn: "Speed Queen 21kg", brand: "Speed Queen", origin: "أمريكي", condition: "new", price: 31200, stock: 4, capacity: "21 كجم", power: "8 كيلو واط", year: 2026, subcategoryId: "household", images: [IMG.laundry7, IMG.drum], isNewArrival: true, weeklyRank: 8 },
  { name: "غسالة قصور 25 كجم بريمس", nameEn: "Primus 25kg Household", brand: "Primus", origin: "ألماني", condition: "used", price: 18700, stock: 2, capacity: "25 كجم", power: "10 كيلو واط", year: 2022, subcategoryId: "household", images: [IMG.washer] },

  { name: "نشافة غاز 34 كجم دانوب", nameEn: "Danube 34kg Gas Dryer", brand: "Danube", origin: "إيطالي", condition: "new", price: 42000, oldPrice: 46500, stock: 3, capacity: "34 كجم", power: "غاز + 1.5 كيلو", year: 2026, subcategoryId: "gas", images: [IMG.dryer, IMG.laundry6], weeklyRank: 3, featured: true, isNewArrival: true, isOffer: true },
  { name: "نشافة غاز 23 كجم تولون", nameEn: "Tolon 23kg Gas Dryer", brand: "Tolon", origin: "تركي", condition: "used", price: 16500, stock: 2, capacity: "23 كجم", power: "غاز", year: 2020, subcategoryId: "gas", images: [IMG.dryer] },
  { name: "نشافة كهرباء 16 كجم إيميسا", nameEn: "Imesa 16kg Electric Dryer", brand: "Imesa", origin: "إيطالي", condition: "new", price: 29800, stock: 5, capacity: "16 كجم", power: "18 كيلو واط", year: 2025, subcategoryId: "electric", images: [IMG.laundry6, IMG.dryer], weeklyRank: 7 },
  { name: "نشافة كهرباء 12 كجم أوزجان", nameEn: "Ozcan 12kg Electric Dryer", brand: "Özcan", origin: "تركي", condition: "used", price: 8900, oldPrice: 11000, stock: 4, capacity: "12 كجم", power: "12 كيلو واط", year: 2018, subcategoryId: "electric", images: [IMG.dryer], isOffer: true },
  { name: "نشافة بخار 50 كجم كانيجيسر", nameEn: "Kannegiesser Steam Dryer", brand: "Kannegiesser", origin: "ألماني", condition: "new", price: 155000, stock: 1, capacity: "50 كجم", power: "بخار 8 بار", year: 2026, subcategoryId: "steam", images: [IMG.dryer, IMG.warehouse], featured: true, isNewArrival: true, weeklyRank: 4 },
  { name: "نشافة بخار 30 كجم لافاتيك", nameEn: "Lavatec 30kg Steam Dryer", brand: "Lavatec", origin: "ألماني", condition: "used", price: 64000, stock: 1, capacity: "30 كجم", power: "بخار", year: 2019, subcategoryId: "steam", images: [IMG.laundry6] },

  { name: "خط غسيل سجاد أوتوماتيك 3 أمتار", nameEn: "3m Auto Carpet Line", brand: "Özcan", origin: "تركي", condition: "new", price: 186000, oldPrice: 210000, stock: 2, capacity: "عرض 3 م", power: "22 كيلو واط", year: 2026, subcategoryId: "auto-line", images: [IMG.carpet, IMG.warehouse], weeklyRank: 5, featured: true, isNewArrival: true, isOffer: true },
  { name: "خط غسيل سجاد 2.5 م مجدد", nameEn: "2.5m Refurbished Carpet Line", brand: "Özcan", origin: "تركي", condition: "used", price: 78000, stock: 1, capacity: "عرض 2.5 م", power: "15 كيلو واط", year: 2017, subcategoryId: "auto-line", images: [IMG.carpet] },
  { name: "عصارة سجاد 1200 دورة", nameEn: "Carpet Centrifuge 1200rpm", brand: "Tolon", origin: "تركي", condition: "new", price: 54000, stock: 3, capacity: "50 كجم سجاد", power: "7.5 كيلو واط", year: 2025, subcategoryId: "centrifuge", images: [IMG.drum, IMG.carpet], featured: true },
  { name: "عصارة سجاد 800 دورة", nameEn: "Carpet Centrifuge 800rpm", brand: "Özcan", origin: "تركي", condition: "used", price: 21000, stock: 2, capacity: "30 كجم", power: "5.5 كيلو واط", year: 2016, subcategoryId: "centrifuge", images: [IMG.drum], isOffer: true, oldPrice: 26500 },
  { name: "نافضة غبار سجاد عمودية", nameEn: "Vertical Dust Beater", brand: "Özcan", origin: "تركي", condition: "new", price: 33500, stock: 4, capacity: "سجاد حتى 4 م", power: "4 كيلو واط", year: 2026, subcategoryId: "dust", images: [IMG.laundry5, IMG.carpet], isNewArrival: true },
  { name: "نافضة غبار أفقية مستعملة", nameEn: "Horizontal Dust Beater", brand: "Tolon", origin: "تركي", condition: "used", price: 14200, stock: 1, capacity: "3 م", power: "3 كيلو واط", year: 2018, subcategoryId: "dust", images: [IMG.laundry5] },

  { name: "مكبس بخار صناعي رينزاتشي", nameEn: "Renzacci Steam Press", brand: "Renzacci", origin: "إيطالي", condition: "new", price: 27600, stock: 5, capacity: "طاولة 140 سم", power: "بخار 5 بار", year: 2026, subcategoryId: "press-steam", images: [IMG.press, IMG.laundry4], weeklyRank: 9, featured: true, isNewArrival: true },
  { name: "مكبس بخار جرانديمبيانتي", nameEn: "Grandimpianti Steam Press", brand: "Grandimpianti", origin: "إيطالي", condition: "used", price: 11800, stock: 2, capacity: "120 سم", power: "بخار", year: 2019, subcategoryId: "press-steam", images: [IMG.press], isOffer: true, oldPrice: 15000 },
  { name: "مكبس قمصان أوتوماتيك", nameEn: "Automatic Shirt Press", brand: "Renzacci", origin: "إيطالي", condition: "new", price: 41200, stock: 3, capacity: "قميص كامل", power: "بخار + هواء", year: 2025, subcategoryId: "press-shirt", images: [IMG.press], featured: true },
  { name: "مكبس قمصان نصف آلي", nameEn: "Semi-auto Shirt Press", brand: "Tolon", origin: "تركي", condition: "used", price: 16500, stock: 2, capacity: "قميص", power: "بخار", year: 2020, subcategoryId: "press-shirt", images: [IMG.press] },
  { name: "مكبس بناطيل توين", nameEn: "Twin Trouser Press", brand: "Imesa", origin: "إيطالي", condition: "new", price: 36800, stock: 2, capacity: "بنطلين مزدوج", power: "بخار", year: 2026, subcategoryId: "press-trouser", images: [IMG.press], isNewArrival: true },
  { name: "مكبس بناطيل مستعمل", nameEn: "Used Trouser Press", brand: "Özcan", origin: "تركي", condition: "used", price: 9200, stock: 3, capacity: "بنطلين", power: "بخار", year: 2017, subcategoryId: "press-trouser", images: [IMG.press] },
  { name: "مكبس أسطواني 3 أمتار", nameEn: "3m Roller Ironer", brand: "Girbau", origin: "إيطالي", condition: "new", price: 98000, stock: 2, capacity: "عرض 3 م", power: "غاز/بخار", year: 2026, subcategoryId: "press-roller", images: [IMG.steel, IMG.press], weeklyRank: 10, featured: true },
  { name: "مكبس أسطواني 2 م", nameEn: "2m Roller Ironer", brand: "Tolon", origin: "تركي", condition: "used", price: 34000, stock: 1, capacity: "عرض 2 م", power: "كهرباء", year: 2018, subcategoryId: "press-roller", images: [IMG.steel], isOffer: true, oldPrice: 41000 },
  { name: "منفاخ بدلة بخار", nameEn: "Steam Form Finisher", brand: "Renzacci", origin: "إيطالي", condition: "new", price: 22900, stock: 4, capacity: "بدلة / عباءة", power: "بخار + هواء", year: 2025, subcategoryId: "press-finishing", images: [IMG.laundry4, IMG.press], isNewArrival: true },
  { name: "طقم تشطيب فندقي", nameEn: "Hotel Finishing Set", brand: "Primus", origin: "ألماني", condition: "used", price: 17500, stock: 1, capacity: "محطة كاملة", power: "بخار", year: 2019, subcategoryId: "press-finishing", images: [IMG.laundry4] },

  { name: "سير نقل غسيل 8 أمتار", nameEn: "8m Laundry Conveyor", brand: "Danube", origin: "إيطالي", condition: "new", price: 24600, stock: 3, capacity: "8 م × 60 سم", power: "1.1 كيلو واط", year: 2026, subcategoryId: "belt-conveyor", images: [IMG.conveyor, IMG.belt], featured: true, isNewArrival: true },
  { name: "سير نقل 5 أمتار مستعمل", nameEn: "5m Used Conveyor", brand: "Tolon", origin: "تركي", condition: "used", price: 7800, stock: 2, capacity: "5 م", power: "0.75 كيلو", year: 2016, subcategoryId: "belt-conveyor", images: [IMG.conveyor] },
  { name: "سير فرز أوتوماتيك", nameEn: "Auto Sorting Belt", brand: "Girbau", origin: "إيطالي", condition: "new", price: 38900, stock: 2, capacity: "4 محطات", power: "2.2 كيلو واط", year: 2025, subcategoryId: "belt-sort", images: [IMG.belt, IMG.conveyor] },
  { name: "سير فرز يدوي", nameEn: "Manual Sorting Belt", brand: "Özcan", origin: "تركي", condition: "used", price: 11200, stock: 1, capacity: "3 محطات", power: "1.5 كيلو", year: 2018, subcategoryId: "belt-sort", images: [IMG.belt], isOffer: true, oldPrice: 14500 },
  { name: "سير تغذية مكواة 3 م", nameEn: "3m Ironer Feeding Belt", brand: "Imesa", origin: "إيطالي", condition: "new", price: 19800, stock: 3, capacity: "3 م", power: "0.55 كيلو", year: 2026, subcategoryId: "belt-feeding", images: [IMG.belt2, IMG.conveyor], isNewArrival: true },
  { name: "سير تغذية مستعمل", nameEn: "Used Feeding Belt", brand: "Tolon", origin: "تركي", condition: "used", price: 6400, stock: 2, capacity: "2.5 م", power: "0.37 كيلو", year: 2017, subcategoryId: "belt-feeding", images: [IMG.belt2] },
  { name: "محرك سير 2 حصان مع طارة", nameEn: "2HP Belt Motor", brand: "Siemens", origin: "ألماني", condition: "new", price: 3200, stock: 12, capacity: "2 حصان", power: "1.5 كيلو واط", year: 2026, subcategoryId: "belt-motor", images: [IMG.steel], featured: true },
  { name: "طقم طارات وسيور احتياطي", nameEn: "Pulleys Spare Kit", brand: "Özcan", origin: "تركي", condition: "new", price: 1450, stock: 20, capacity: "طقم كامل", power: "—", year: 2026, subcategoryId: "belt-motor", images: [IMG.steel], isNewArrival: true },

  { name: "غلاية عمودية 500 كجم/ساعة", nameEn: "500kg/h Vertical Boiler", brand: "Danube", origin: "إيطالي", condition: "new", price: 142000, oldPrice: 155000, stock: 2, capacity: "500 كجم/س", power: "ديزل/غاز", year: 2026, subcategoryId: "boiler-vertical", images: [IMG.boiler, IMG.tanks], weeklyRank: 11, featured: true, isNewArrival: true, isOffer: true },
  { name: "غلاية عمودية 250 كجم مستعملة", nameEn: "250kg/h Used Vertical", brand: "Tolon", origin: "تركي", condition: "used", price: 48000, stock: 1, capacity: "250 كجم/س", power: "ديزل", year: 2015, subcategoryId: "boiler-vertical", images: [IMG.boiler] },
  { name: "غلاية أفقية 1 طن", nameEn: "1 Ton Horizontal Boiler", brand: "Kannegiesser", origin: "ألماني", condition: "new", price: 265000, stock: 1, capacity: "1000 كجم/س", power: "غاز", year: 2026, subcategoryId: "boiler-horizontal", images: [IMG.tanks, IMG.boiler], featured: true },
  { name: "غلاية أفقية 600 كجم", nameEn: "600kg Horizontal Boiler", brand: "Özcan", origin: "تركي", condition: "used", price: 89000, stock: 1, capacity: "600 كجم/س", power: "ديزل", year: 2014, subcategoryId: "boiler-horizontal", images: [IMG.tanks] },
  { name: "غلاية كهربائية 80 كجم", nameEn: "80kg Electric Boiler", brand: "Imesa", origin: "إيطالي", condition: "new", price: 36500, stock: 4, capacity: "80 كجم/س", power: "54 كيلو واط", year: 2025, subcategoryId: "boiler-electric", images: [IMG.steel, IMG.boiler], isNewArrival: true },
  { name: "غلاية كهربائية 40 كجم", nameEn: "40kg Electric Boiler", brand: "Tolon", origin: "تركي", condition: "used", price: 12800, oldPrice: 16000, stock: 2, capacity: "40 كجم/س", power: "30 كيلو واط", year: 2019, subcategoryId: "boiler-electric", images: [IMG.steel], isOffer: true },
  { name: "غلاية ديزل 400 كجم", nameEn: "400kg Diesel Boiler", brand: "Özcan", origin: "تركي", condition: "new", price: 98000, stock: 2, capacity: "400 كجم/س", power: "ديزل", year: 2026, subcategoryId: "boiler-diesel", images: [IMG.boiler, IMG.warehouse] },
  { name: "غلاية ديزل 200 كجم مجددة", nameEn: "200kg Refurbished Diesel", brand: "Tolon", origin: "تركي", condition: "used", price: 35500, stock: 1, capacity: "200 كجم/س", power: "ديزل", year: 2016, subcategoryId: "boiler-diesel", images: [IMG.boiler] },
  { name: "غلاية غاز 350 كجم", nameEn: "350kg Gas Boiler", brand: "Danube", origin: "إيطالي", condition: "new", price: 118000, stock: 2, capacity: "350 كجم/س", power: "غاز طبيعي", year: 2026, subcategoryId: "boiler-gas", images: [IMG.tanks], featured: true, isNewArrival: true },
  { name: "غلاية غاز 180 كجم", nameEn: "180kg Gas Boiler", brand: "Özcan", origin: "تركي", condition: "used", price: 42000, stock: 1, capacity: "180 كجم/س", power: "غاز", year: 2018, subcategoryId: "boiler-gas", images: [IMG.tanks], isOffer: true, oldPrice: 51000 },
  { name: "مولد بخار فوري 40 كجم", nameEn: "40kg Instant Steam Generator", brand: "Renzacci", origin: "إيطالي", condition: "new", price: 18900, stock: 6, capacity: "40 كجم/س", power: "30 كيلو واط", year: 2026, subcategoryId: "boiler-generator", images: [IMG.steel, IMG.press], weeklyRank: 12, featured: true },
  { name: "مولد بخار فوري 20 كجم", nameEn: "20kg Steam Generator", brand: "Tolon", origin: "تركي", condition: "used", price: 6400, stock: 3, capacity: "20 كجم/س", power: "15 كيلو واط", year: 2020, subcategoryId: "boiler-generator", images: [IMG.steel] },
];

function featuresFor(d: Draft): string[] {
  return [
    `المنشأ: ${d.origin} — العلامة: ${d.brand}`,
    `السعة: ${d.capacity} · القدرة: ${d.power}`,
    d.condition === "new" ? "جديد كرت مع ضمان الوكيل وقطع الغيار" : "مستعمل مفحوص ومجدد مع تجربة تشغيل في المستودع",
    "تركيب وتشغيل في موقع العميل داخل المملكة",
    "دعم فني وصيانة وقطع غيار من مستودع جدة",
    "مناسب للمغاسل التجارية والفنادق والمستشفيات",
  ];
}

export const products: Product[] = drafts.map((d, i) => {
  const sub = categories.find((c) => c.id === d.subcategoryId)!;
  return {
    id: `p-${String(i + 1).padStart(3, "0")}`,
    sku: `NJ-${2000 + i}`,
    name: d.name,
    nameEn: d.nameEn,
    brand: d.brand,
    origin: d.origin,
    condition: d.condition,
    price: d.price,
    oldPrice: d.oldPrice,
    stock: d.stock,
    capacity: d.capacity,
    power: d.power,
    year: d.year,
    subcategoryId: d.subcategoryId,
    categoryId: sub.parentId || d.subcategoryId,
    images: d.images,
    videos: d.videos || [],
    featured: !!d.featured,
    isNewArrival: !!d.isNewArrival,
    isOffer: !!d.isOffer || !!d.oldPrice,
    weeklyRank: d.weeklyRank,
    createdAt: `2026-0${(i % 9) + 1}-${String((i % 27) + 1).padStart(2, "0")}T10:00:00.000Z`,
    features: featuresFor(d),
    description: `${d.name} (${d.nameEn}) من ${d.brand} ${d.origin}. ${d.condition === "new" ? "حالة جديد كرت، وصول مستودع جدة الرئيسي." : "حالة مستعمل مضمون بعد فحص فني كامل وتجربة تشغيل."} السعة ${d.capacity} والقدرة ${d.power}. مناسب للمغاسل والفنادق والمستشفيات، مع إمكانية التركيب والتشغيل وقطع الغيار من شركة النجيب المتطورة.`,
  };
});

export function createInitialState(): AppState {
  return {
    products: products.map((p) => ({ ...p, images: [...p.images], videos: [...p.videos], features: [...p.features] })),
    categories: categories.map((c) => ({ ...c })),
    cart: [],
    customerSessionId: null,
    staffSessionId: null,
    company: {
      name: "شركة النجيب المتطورة لجميع أنواع معدات المغاسل",
      nameEn: "Al-Najeeb Advanced Laundry & Hotel Equipment Co.",
      phone: "0126000000",
      whatsapp: "0555000000",
      email: "info@alnajeeb.sa",
      warehouse: "المنطقة الصناعية الثالثة، جدة",
      city: "جدة",
    },
    staff: [
      {
        id: "staff-owner",
        role: "owner",
        name: "مدير النظام — النجيب",
        username: "najeeb",
        password: "admin123",
        phone: "0555000000",
        email: "admin@alnajeeb.sa",
        active: true,
        permissions: [...OWNER_PERMISSIONS],
        createdAt: "2025-01-01T00:00:00.000Z",
      },
      {
        id: "staff-saleh",
        role: "assistant",
        name: "صالح العتيبي",
        username: "saleh",
        password: "saleh123",
        phone: "0555123456",
        email: "saleh@alnajeeb.sa",
        active: true,
        permissions: ["dashboard", "products", "prices", "media", "categories"],
        createdAt: "2026-02-01T00:00:00.000Z",
      },
    ],
    customers: [
      { id: "c-1", name: "مغسلة الياسمين", phone: "0561112233", email: "yasmin@laundry.sa", password: "123456", city: "جدة", address: "حي الصفا", createdAt: "2026-01-12T00:00:00.000Z" },
      { id: "c-2", name: "فندق النخيل", phone: "0542223344", email: "nakheel@hotel.sa", password: "123456", city: "مكة", address: "العزيزية", createdAt: "2026-02-03T00:00:00.000Z" },
      { id: "c-3", name: "مغاسل الصفوة", phone: "0553334455", email: "safwa@laundry.sa", password: "123456", city: "الرياض", address: "العليا", createdAt: "2026-03-18T00:00:00.000Z" },
    ],
    orders: [
      {
        id: "ord-10021",
        customerId: "c-1",
        customerName: "مغسلة الياسمين",
        phone: "0561112233",
        email: "yasmin@laundry.sa",
        city: "جدة",
        address: "حي الصفا — مستودع 4",
        notes: "التركيب صباح الأحد",
        items: [{ productId: "p-001", name: "غسالة كمبيوتر 23 كجم دانوب", qty: 1, price: 48500, image: IMG.washer }],
        total: 48500,
        status: "confirmed",
        paymentStatus: "paid",
        createdAt: "2026-09-14T08:30:00.000Z",
      },
      {
        id: "ord-10022",
        customerId: "c-2",
        customerName: "فندق النخيل",
        phone: "0542223344",
        email: "nakheel@hotel.sa",
        city: "مكة",
        address: "العزيزية",
        notes: "",
        items: [
          { productId: "p-003", name: "غسالة فنادق 50 كجم جيرباو", qty: 2, price: 128000, image: IMG.laundry1 },
          { productId: "p-009", name: "نشافة غاز 34 كجم دانوب", qty: 2, price: 42000, image: IMG.dryer },
        ],
        total: 340000,
        status: "processing",
        paymentStatus: "unpaid",
        createdAt: "2026-09-28T11:00:00.000Z",
      },
      {
        id: "ord-10023",
        customerId: "c-3",
        customerName: "مغاسل الصفوة",
        phone: "0553334455",
        email: "safwa@laundry.sa",
        city: "الرياض",
        address: "العليا",
        notes: "شحن براً",
        items: [{ productId: "p-015", name: "خط غسيل سجاد أوتوماتيك 3 أمتار", qty: 1, price: 186000, image: IMG.carpet }],
        total: 186000,
        status: "pending",
        paymentStatus: "unpaid",
        createdAt: "2026-10-02T16:20:00.000Z",
      },
    ],
    bookings: [
      { id: "bk-1", customerName: "مغسلة الياسمين", phone: "0561112233", email: "yasmin@laundry.sa", city: "جدة", equipment: "غسالة كمبيوتر 23 كجم", issue: "صوت غير طبيعي في العصارة", preferredDate: "2026-10-10", technicianId: "tech-1", status: "scheduled", createdAt: "2026-10-01T09:00:00.000Z" },
      { id: "bk-2", customerName: "مغسلتي المنزلية", phone: "0538887766", email: "home@mail.sa", city: "جدة", equipment: "نشافة غاز", issue: "ضعف تجفيف", preferredDate: "2026-10-12", status: "new", createdAt: "2026-10-03T14:00:00.000Z" },
      { id: "bk-3", customerName: "فندق النخيل", phone: "0542223344", email: "nakheel@hotel.sa", city: "مكة", equipment: "غلاية غاز", issue: "صيانة دورية ربع سنوية", preferredDate: "2026-10-15", technicianId: "tech-2", status: "in_progress", createdAt: "2026-09-30T10:00:00.000Z" },
    ],
    technicians: [
      { id: "tech-1", name: "فهد الغامدي", phone: "0557001001", specialty: "غسالات ونشافات", city: "جدة", active: true },
      { id: "tech-2", name: "ماجد الحربي", phone: "0557001002", specialty: "غلايات وبخار", city: "مكة", active: true },
      { id: "tech-3", name: "يوسف الزهراني", phone: "0557001003", specialty: "مكابس وخطوط سجاد", city: "جدة", active: true },
    ],
    payments: [
      { id: "pay-1", orderId: "ord-10021", amount: 48500, method: "تحويل بنكي", status: "paid", createdAt: "2026-09-14T12:00:00.000Z", note: "حوالة الأهلي" },
      { id: "pay-2", orderId: "ord-10022", amount: 340000, method: "آجل 30 يوماً", status: "unpaid", createdAt: "2026-09-28T11:10:00.000Z", note: "فاتورة فندق" },
      { id: "pay-3", orderId: "ord-10023", amount: 186000, method: "شبكة", status: "unpaid", createdAt: "2026-10-02T16:25:00.000Z", note: "" },
    ],
    activity: [
      { id: "a-1", at: "2026-10-03T14:00:00.000Z", actor: "النظام", action: "حجز صيانة جديد من مغسلتي المنزلية" },
      { id: "a-2", at: "2026-10-02T16:20:00.000Z", actor: "مغاسل الصفوة", action: "طلب شراء خط سجاد أوتوماتيك" },
      { id: "a-3", at: "2026-09-28T11:00:00.000Z", actor: "فندق النخيل", action: "طلب غسالات ونشافات فندقية" },
    ],
  };
}
