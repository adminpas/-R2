import type { Condition, OrderStatus, BookingStatus, PaymentStatus } from "./types";

export const HALA_SOFT = {
  name: "مجموعة هلا سوفت",
  nameEn: "Hala Soft Group",
  country: "الجمهورية اليمنية — صنعاء",
  lead: "أبو كمال المرهبي",
  phoneIntl: "00967778044803",
  phoneDisplay: "778044803",
  wa: "967778044803",
};

export function formatSar(n: number) {
  return new Intl.NumberFormat("ar-SA").format(Math.round(n)) + " ر.س";
}

export function formatDate(iso: string) {
  try {
    return new Intl.DateTimeFormat("ar-SA", {
      year: "numeric",
      month: "short",
      day: "numeric",
    }).format(new Date(iso));
  } catch {
    return iso;
  }
}

export function nowIso() {
  return new Date().toISOString();
}

export function uid(prefix = "id") {
  return `${prefix}-${Math.random().toString(36).slice(2, 8)}${Date.now().toString(36).slice(-4)}`;
}

export function normalizePhone(p: string) {
  return (p || "").replace(/[\s\-()]/g, "").replace(/^00966/, "0").replace(/^966/, "0");
}

export function conditionLabel(c: Condition) {
  return c === "new" ? "جديد كرت" : "مستعمل مضمون";
}

export function orderStatusLabel(s: OrderStatus) {
  const map: Record<OrderStatus, string> = {
    pending: "قيد المراجعة",
    confirmed: "مؤكد",
    processing: "تجهيز",
    shipped: "شحن",
    delivered: "تم التسليم",
    cancelled: "ملغي",
  };
  return map[s];
}

export function bookingStatusLabel(s: BookingStatus) {
  const map: Record<BookingStatus, string> = {
    new: "جديد",
    scheduled: "مجدول",
    in_progress: "قيد التنفيذ",
    done: "مكتمل",
    cancelled: "ملغي",
  };
  return map[s];
}

export function paymentStatusLabel(s: PaymentStatus) {
  const map: Record<PaymentStatus, string> = {
    unpaid: "غير مدفوع",
    paid: "مدفوع",
    refunded: "مسترجع",
  };
  return map[s];
}

export function whatsappLink(phone: string, text?: string) {
  const n = normalizePhone(phone).replace(/^0/, "966");
  const q = text ? `?text=${encodeURIComponent(text)}` : "";
  return `https://wa.me/${n}${q}`;
}

export function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    if (file.size > 2_400_000) {
      reject(new Error("حجم الملف أكبر من 2.4 ميجا. اختر ملفاً أصغر."));
      return;
    }
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("تعذر قراءة الملف"));
    reader.readAsDataURL(file);
  });
}
