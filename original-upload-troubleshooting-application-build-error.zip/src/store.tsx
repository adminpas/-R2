import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import type {
  AppState,
  Booking,
  Category,
  Customer,
  Order,
  PermissionKey,
  Product,
  Staff,
  Technician,
} from "./types";
import { OWNER_PERMISSIONS } from "./types";
import { createInitialState } from "./data";
import { normalizePhone, nowIso, uid } from "./lib";

const STORAGE_KEY = "alnajeeb-platform-v1";

function loadState(): AppState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return createInitialState();
    const parsed = JSON.parse(raw) as AppState;
    if (!parsed?.products || !parsed?.staff) return createInitialState();
    return {
      ...createInitialState(),
      ...parsed,
      company: { ...createInitialState().company, ...parsed.company },
    };
  } catch {
    return createInitialState();
  }
}

interface StoreApi {
  state: AppState;
  products: Product[];
  categories: Category[];
  parentCategories: Category[];
  subcategories: (parentId: string) => Category[];
  productById: (id: string) => Product | undefined;
  categoryById: (id: string) => Category | undefined;
  cartCount: number;
  cartTotal: number;
  cartLines: { product: Product; qty: number }[];
  customer: Customer | null;
  staffUser: Staff | null;
  can: (key: PermissionKey) => boolean;
  addToCart: (productId: string, qty?: number) => void;
  setCartQty: (productId: string, qty: number) => void;
  clearCart: () => void;
  registerCustomer: (data: Omit<Customer, "id" | "createdAt">) => string | null;
  loginCustomer: (emailOrPhone: string, password: string) => string | null;
  logoutCustomer: () => void;
  updateCustomer: (id: string, patch: Partial<Customer>) => void;
  placeOrder: (info: {
    customerName: string;
    phone: string;
    email: string;
    city: string;
    address: string;
    notes: string;
  }) => Order | string;
  addBooking: (b: Omit<Booking, "id" | "createdAt" | "status">) => void;
  adminLogin: (username: string, password: string, phone: string, email: string) => string | null;
  logoutStaff: () => void;
  updateOwnProfile: (patch: Partial<Pick<Staff, "name" | "username" | "password" | "phone" | "email">>) => string | null;
  saveProduct: (p: Product) => void;
  deleteProduct: (id: string) => void;
  saveCategory: (c: Category) => void;
  deleteCategory: (id: string) => void;
  setOrderStatus: (id: string, status: Order["status"]) => void;
  setPaymentStatus: (id: string, status: Order["paymentStatus"]) => void;
  setBookingStatus: (id: string, status: Booking["status"], technicianId?: string) => void;
  saveTechnician: (t: Technician) => void;
  deleteTechnician: (id: string) => void;
  saveStaff: (s: Staff) => string | null;
  deleteStaff: (id: string) => string | null;
  updateCompany: (patch: Partial<AppState["company"]>) => void;
  resetDemo: () => void;
  log: (action: string) => void;
}

const StoreContext = createContext<StoreApi | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AppState>(() => loadState());

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [state]);

  const api = useMemo<StoreApi>(() => {
    const products = state.products;
    const categories = [...state.categories].sort((a, b) => a.order - b.order);
    const parentCategories = categories.filter((c) => !c.parentId);
    const subcategories = (parentId: string) => categories.filter((c) => c.parentId === parentId);
    const productById = (id: string) => products.find((p) => p.id === id);
    const categoryById = (id: string) => categories.find((c) => c.id === id);
    const cartLines = state.cart
      .map((l) => {
        const product = productById(l.productId);
        return product ? { product, qty: l.qty } : null;
      })
      .filter((x): x is { product: Product; qty: number } => !!x);
    const cartCount = cartLines.reduce((s, l) => s + l.qty, 0);
    const cartTotal = cartLines.reduce((s, l) => s + l.qty * l.product.price, 0);
    const customer = state.customers.find((c) => c.id === state.customerSessionId) || null;
    const staffUser = state.staff.find((s) => s.id === state.staffSessionId) || null;
    const can = (key: PermissionKey) => {
      if (!staffUser || !staffUser.active) return false;
      if (staffUser.role === "owner") return true;
      return staffUser.permissions.includes(key);
    };

    const log = (action: string) => {
      setState((s) => ({
        ...s,
        activity: [
          {
            id: uid("act"),
            at: nowIso(),
            actor: staffUser?.name || customer?.name || "زائر",
            action,
          },
          ...s.activity,
        ].slice(0, 80),
      }));
    };

    const addToCart = (productId: string, qty = 1) => {
      setState((s) => {
        const found = s.cart.find((c) => c.productId === productId);
        const cart = found
          ? s.cart.map((c) => (c.productId === productId ? { ...c, qty: c.qty + qty } : c))
          : [...s.cart, { productId, qty }];
        return { ...s, cart };
      });
    };

    const setCartQty = (productId: string, qty: number) => {
      setState((s) => ({
        ...s,
        cart: qty <= 0 ? s.cart.filter((c) => c.productId !== productId) : s.cart.map((c) => (c.productId === productId ? { ...c, qty } : c)),
      }));
    };

    const clearCart = () => setState((s) => ({ ...s, cart: [] }));

    const registerCustomer = (data: Omit<Customer, "id" | "createdAt">) => {
      if (state.customers.some((c) => c.email.toLowerCase() === data.email.toLowerCase() || normalizePhone(c.phone) === normalizePhone(data.phone))) {
        return "البريد أو الجوال مسجّل مسبقاً";
      }
      const id = uid("c");
      setState((s) => ({
        ...s,
        customers: [{ ...data, id, createdAt: nowIso() }, ...s.customers],
        customerSessionId: id,
      }));
      return null;
    };

    const loginCustomer = (emailOrPhone: string, password: string) => {
      const q = emailOrPhone.trim().toLowerCase();
      const found = state.customers.find(
        (c) =>
          c.password === password &&
          (c.email.toLowerCase() === q || normalizePhone(c.phone) === normalizePhone(emailOrPhone)),
      );
      if (!found) return "بيانات الدخول غير صحيحة";
      setState((s) => ({ ...s, customerSessionId: found.id }));
      return null;
    };

    const logoutCustomer = () => setState((s) => ({ ...s, customerSessionId: null }));

    const updateCustomer = (id: string, patch: Partial<Customer>) => {
      setState((s) => ({
        ...s,
        customers: s.customers.map((c) => (c.id === id ? { ...c, ...patch } : c)),
      }));
    };

    const placeOrder = (info: {
      customerName: string;
      phone: string;
      email: string;
      city: string;
      address: string;
      notes: string;
    }) => {
      if (!cartLines.length) return "السلة فارغة";
      const order: Order = {
        id: `ord-${Math.floor(10000 + Math.random() * 89999)}`,
        customerId: customer?.id,
        customerName: info.customerName,
        phone: info.phone,
        email: info.email,
        city: info.city,
        address: info.address,
        notes: info.notes,
        items: cartLines.map((l) => ({
          productId: l.product.id,
          name: l.product.name,
          qty: l.qty,
          price: l.product.price,
          image: l.product.images[0] || "",
        })),
        total: cartTotal,
        status: "pending",
        paymentStatus: "unpaid",
        createdAt: nowIso(),
      };
      setState((s) => ({
        ...s,
        orders: [order, ...s.orders],
        payments: [
          {
            id: uid("pay"),
            orderId: order.id,
            amount: order.total,
            method: "عند الاستلام / تحويل",
            status: "unpaid",
            createdAt: nowIso(),
            note: "",
          },
          ...s.payments,
        ],
        products: s.products.map((p) => {
          const line = cartLines.find((l) => l.product.id === p.id);
          return line ? { ...p, stock: Math.max(0, p.stock - line.qty) } : p;
        }),
        cart: [],
        activity: [
          { id: uid("act"), at: nowIso(), actor: info.customerName, action: `طلب جديد ${order.id} بقيمة ${order.total}` },
          ...s.activity,
        ],
      }));
      return order;
    };

    const addBooking = (b: Omit<Booking, "id" | "createdAt" | "status">) => {
      setState((s) => ({
        ...s,
        bookings: [
          { ...b, id: uid("bk"), createdAt: nowIso(), status: "new" },
          ...s.bookings,
        ],
        activity: [
          { id: uid("act"), at: nowIso(), actor: b.customerName, action: `طلب صيانة: ${b.equipment}` },
          ...s.activity,
        ],
      }));
    };

    const adminLogin = (username: string, password: string, phone: string, email: string) => {
      const u = username.trim();
      const e = email.trim().toLowerCase();
      const found = state.staff.find(
        (st) =>
          st.active &&
          st.username === u &&
          st.password === password &&
          normalizePhone(st.phone) === normalizePhone(phone) &&
          st.email.toLowerCase() === e,
      );
      if (!found) return "بيانات الدخول غير مكتملة أو غير مطابقة. يلزم اسم المستخدم وكلمة المرور والجوال والبريد معاً.";
      setState((s) => ({
        ...s,
        staffSessionId: found.id,
        staff: s.staff.map((st) => (st.id === found.id ? { ...st, lastLogin: nowIso() } : st)),
        activity: [
          { id: uid("act"), at: nowIso(), actor: found.name, action: "دخول لوحة التحكم" },
          ...s.activity,
        ],
      }));
      return null;
    };

    const logoutStaff = () => setState((s) => ({ ...s, staffSessionId: null }));

    const updateOwnProfile = (patch: Partial<Pick<Staff, "name" | "username" | "password" | "phone" | "email">>) => {
      if (!staffUser) return "يلزم تسجيل الدخول";
      if (patch.username) {
        const nextUser = patch.username.trim();
        const clash = state.staff.some((st) => st.id !== staffUser.id && st.username === nextUser);
        if (clash) return "اسم المستخدم مستخدم لحساب آخر";
      }
      if (patch.email) {
        const clash = state.staff.some((st) => st.id !== staffUser.id && st.email.toLowerCase() === patch.email!.trim().toLowerCase());
        if (clash) return "البريد مستخدم لحساب آخر";
      }
      setState((s) => ({
        ...s,
        staff: s.staff.map((st) =>
          st.id === staffUser.id
            ? {
                ...st,
                name: patch.name ?? st.name,
                username: patch.username?.trim() || st.username,
                password: patch.password && patch.password.length > 0 ? patch.password : st.password,
                phone: patch.phone ?? st.phone,
                email: patch.email?.trim() || st.email,
              }
            : st,
        ),
        activity: [
          { id: uid("act"), at: nowIso(), actor: staffUser.name, action: "تحديث بيانات حساب المدير/المساعد" },
          ...s.activity,
        ],
      }));
      return null;
    };

    const saveProduct = (p: Product) => {
      setState((s) => {
        const exists = s.products.some((x) => x.id === p.id);
        return {
          ...s,
          products: exists ? s.products.map((x) => (x.id === p.id ? p : x)) : [p, ...s.products],
        };
      });
    };

    const deleteProduct = (id: string) => {
      setState((s) => ({ ...s, products: s.products.filter((p) => p.id !== id) }));
    };

    const saveCategory = (c: Category) => {
      setState((s) => {
        const exists = s.categories.some((x) => x.id === c.id);
        return {
          ...s,
          categories: exists ? s.categories.map((x) => (x.id === c.id ? c : x)) : [...s.categories, c],
        };
      });
    };

    const deleteCategory = (id: string) => {
      setState((s) => ({
        ...s,
        categories: s.categories.filter((c) => c.id !== id && c.parentId !== id),
      }));
    };

    const setOrderStatus = (id: string, status: Order["status"]) => {
      setState((s) => ({
        ...s,
        orders: s.orders.map((o) => (o.id === id ? { ...o, status } : o)),
      }));
    };

    const setPaymentStatus = (id: string, status: Order["paymentStatus"]) => {
      setState((s) => ({
        ...s,
        orders: s.orders.map((o) => (o.id === id ? { ...o, paymentStatus: status } : o)),
        payments: s.payments.map((p) => (p.orderId === id ? { ...p, status } : p)),
      }));
    };

    const setBookingStatus = (id: string, status: Booking["status"], technicianId?: string) => {
      setState((s) => ({
        ...s,
        bookings: s.bookings.map((b) =>
          b.id === id ? { ...b, status, technicianId: technicianId ?? b.technicianId } : b,
        ),
      }));
    };

    const saveTechnician = (t: Technician) => {
      setState((s) => {
        const exists = s.technicians.some((x) => x.id === t.id);
        return {
          ...s,
          technicians: exists ? s.technicians.map((x) => (x.id === t.id ? t : x)) : [t, ...s.technicians],
        };
      });
    };

    const deleteTechnician = (id: string) => {
      setState((s) => ({ ...s, technicians: s.technicians.filter((t) => t.id !== id) }));
    };

    const saveStaff = (stf: Staff) => {
      if (!can("staff") && staffUser?.role !== "owner") return "ليست لديك صلاحية إدارة المساعدين";
      const clashUser = state.staff.some((x) => x.id !== stf.id && x.username === stf.username.trim());
      if (clashUser) return "اسم المستخدم مستخدم";
      const clashMail = state.staff.some((x) => x.id !== stf.id && x.email.toLowerCase() === stf.email.trim().toLowerCase());
      if (clashMail) return "البريد مستخدم";
      const clean: Staff = {
        ...stf,
        username: stf.username.trim(),
        email: stf.email.trim().toLowerCase(),
        permissions: stf.role === "owner" ? [...OWNER_PERMISSIONS] : stf.permissions,
      };
      setState((s) => {
        const exists = s.staff.some((x) => x.id === clean.id);
        return {
          ...s,
          staff: exists ? s.staff.map((x) => (x.id === clean.id ? clean : x)) : [clean, ...s.staff],
        };
      });
      return null;
    };

    const deleteStaff = (id: string) => {
      const target = state.staff.find((x) => x.id === id);
      if (!target) return "الحساب غير موجود";
      if (target.role === "owner") return "لا يمكن حذف حساب المالك";
      if (!can("staff")) return "ليست لديك صلاحية";
      setState((s) => ({
        ...s,
        staff: s.staff.filter((x) => x.id !== id),
        staffSessionId: s.staffSessionId === id ? null : s.staffSessionId,
      }));
      return null;
    };

    const updateCompany = (patch: Partial<AppState["company"]>) => {
      setState((s) => ({ ...s, company: { ...s.company, ...patch } }));
    };

    const resetDemo = () => {
      const fresh = createInitialState();
      setState(fresh);
    };

    return {
      state,
      products,
      categories,
      parentCategories,
      subcategories,
      productById,
      categoryById,
      cartCount,
      cartTotal,
      cartLines,
      customer,
      staffUser,
      can,
      addToCart,
      setCartQty,
      clearCart,
      registerCustomer,
      loginCustomer,
      logoutCustomer,
      updateCustomer,
      placeOrder,
      addBooking,
      adminLogin,
      logoutStaff,
      updateOwnProfile,
      saveProduct,
      deleteProduct,
      saveCategory,
      deleteCategory,
      setOrderStatus,
      setPaymentStatus,
      setBookingStatus,
      saveTechnician,
      deleteTechnician,
      saveStaff,
      deleteStaff,
      updateCompany,
      resetDemo,
      log,
    };
  }, [state]);

  return <StoreContext.Provider value={api}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error("useStore outside provider");
  return ctx;
}
