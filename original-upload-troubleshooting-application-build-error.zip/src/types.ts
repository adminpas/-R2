export type Origin = "إيطالي" | "تركي" | "ألماني" | "أمريكي" | "صيني";
export type Condition = "new" | "used";
export type OrderStatus = "pending" | "confirmed" | "processing" | "shipped" | "delivered" | "cancelled";
export type BookingStatus = "new" | "scheduled" | "in_progress" | "done" | "cancelled";
export type PaymentStatus = "unpaid" | "paid" | "refunded";
export type StaffRole = "owner" | "assistant";

export type PermissionKey =
  | "dashboard"
  | "products"
  | "prices"
  | "media"
  | "categories"
  | "orders"
  | "maintenance"
  | "customers"
  | "payments"
  | "staff"
  | "settings"
  | "reports";

export interface Category {
  id: string;
  name: string;
  nameEn: string;
  emoji: string;
  description: string;
  image: string;
  parentId: string | null;
  order: number;
}

export interface Product {
  id: string;
  name: string;
  nameEn: string;
  sku: string;
  categoryId: string;
  subcategoryId: string;
  brand: string;
  origin: Origin;
  condition: Condition;
  price: number;
  oldPrice?: number;
  stock: number;
  capacity: string;
  power: string;
  year: number;
  description: string;
  features: string[];
  images: string[];
  videos: string[];
  featured: boolean;
  isNewArrival: boolean;
  isOffer: boolean;
  weeklyRank?: number;
  createdAt: string;
}

export interface CartItem {
  productId: string;
  qty: number;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  email: string;
  password: string;
  city: string;
  address: string;
  createdAt: string;
}

export interface OrderItem {
  productId: string;
  name: string;
  qty: number;
  price: number;
  image: string;
}

export interface Order {
  id: string;
  customerId?: string;
  customerName: string;
  phone: string;
  email: string;
  city: string;
  address: string;
  notes: string;
  items: OrderItem[];
  total: number;
  status: OrderStatus;
  paymentStatus: PaymentStatus;
  createdAt: string;
}

export interface Booking {
  id: string;
  customerName: string;
  phone: string;
  email: string;
  city: string;
  equipment: string;
  issue: string;
  preferredDate: string;
  technicianId?: string;
  status: BookingStatus;
  createdAt: string;
}

export interface Technician {
  id: string;
  name: string;
  phone: string;
  specialty: string;
  city: string;
  active: boolean;
}

export interface Payment {
  id: string;
  orderId: string;
  amount: number;
  method: string;
  status: PaymentStatus;
  createdAt: string;
  note: string;
}

export interface Staff {
  id: string;
  role: StaffRole;
  name: string;
  username: string;
  password: string;
  phone: string;
  email: string;
  active: boolean;
  permissions: PermissionKey[];
  createdAt: string;
  lastLogin?: string;
}

export interface Activity {
  id: string;
  at: string;
  actor: string;
  action: string;
}

export interface CompanyProfile {
  name: string;
  nameEn: string;
  phone: string;
  whatsapp: string;
  email: string;
  warehouse: string;
  city: string;
}

export interface AppState {
  products: Product[];
  categories: Category[];
  customers: Customer[];
  orders: Order[];
  bookings: Booking[];
  technicians: Technician[];
  payments: Payment[];
  staff: Staff[];
  activity: Activity[];
  cart: CartItem[];
  company: CompanyProfile;
  customerSessionId: string | null;
  staffSessionId: string | null;
}

export const ALL_PERMISSIONS: { key: PermissionKey; label: string; hint: string }[] = [
  { key: "dashboard", label: "لوحة الإحصاءات", hint: "عرض الملخص والأرقام" },
  { key: "products", label: "إدارة المنتجات", hint: "إضافة وتعديل وحذف المعدات" },
  { key: "prices", label: "تعديل الأسعار", hint: "تغيير الأسعار والعروض" },
  { key: "media", label: "رفع الصور والفيديو", hint: "مكتبة الوسائط للمنتجات" },
  { key: "categories", label: "الأقسام والأقسام الفرعية", hint: "إنشاء وتنظيم الأقسام" },
  { key: "orders", label: "الطلبات", hint: "متابعة طلبات العملاء" },
  { key: "maintenance", label: "الصيانة والفنيين", hint: "الحجوزات وطاقم الصيانة" },
  { key: "customers", label: "حسابات العملاء", hint: "عرض بيانات العملاء" },
  { key: "payments", label: "المدفوعات والمالية", hint: "حالة التحصيل" },
  { key: "staff", label: "المساعدين والصلاحيات", hint: "إنشاء حسابات محدودة" },
  { key: "settings", label: "إعدادات النظام", hint: "بيانات الشركة والنظام" },
  { key: "reports", label: "التقارير", hint: "تقارير المبيعات والمخزون" },
];

export const OWNER_PERMISSIONS = ALL_PERMISSIONS.map((p) => p.key);
