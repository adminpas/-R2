import { useEffect, type ReactNode } from "react";
import { Link } from "react-router-dom";
import { ShoppingBag, X } from "lucide-react";
import type { Product } from "./types";
import { conditionLabel, formatSar } from "./lib";
import { useStore } from "./store";
import { cn } from "./utils/cn";

export function ConditionBadge({ condition }: { condition: Product["condition"] }) {
  const isNew = condition === "new";
  return (
    <span
      className={cn(
        "rounded-full px-2.5 py-0.5 text-[11px] font-bold tracking-wide",
        isNew ? "bg-emerald-600 text-white" : "bg-amber-700 text-amber-50",
      )}
    >
      {conditionLabel(condition)}
    </span>
  );
}

export function Price({ value, old }: { value: number; old?: number }) {
  return (
    <div className="flex flex-wrap items-baseline gap-2">
      <span className="text-lg font-extrabold text-ink">{formatSar(value)}</span>
      {old && old > value ? (
        <span className="text-sm text-ink/40 line-through">{formatSar(old)}</span>
      ) : null}
    </div>
  );
}

export function ProductCard({ product }: { product: Product }) {
  const { addToCart } = useStore();
  const img = product.images[0] || "/images/washer-industrial.jpg";
  return (
    <article className="group relative flex h-full flex-col overflow-hidden rounded-3xl border border-ink/8 bg-white shadow-[0_10px_30px_rgba(16,36,44,0.06)] transition hover:-translate-y-1 hover:shadow-[0_18px_40px_rgba(16,36,44,0.12)]">
      <Link to={`/product/${product.id}`} className="relative block aspect-[4/3] overflow-hidden bg-sand-2">
        <img src={img} alt={product.name} className="h-full w-full object-cover transition duration-700 group-hover:scale-105" />
        <div className="absolute inset-x-3 top-3 flex items-start justify-between">
          <ConditionBadge condition={product.condition} />
          {product.isOffer ? (
            <span className="rounded-full bg-rose-600 px-2.5 py-0.5 text-[11px] font-bold text-white">عرض</span>
          ) : null}
        </div>
        {product.weeklyRank ? (
          <span className="absolute bottom-3 right-3 flex h-8 w-8 items-center justify-center rounded-full bg-ink text-xs font-black text-gold-2">
            {product.weeklyRank}
          </span>
        ) : null}
      </Link>
      <div className="flex flex-1 flex-col gap-2 p-4">
        <p className="text-[11px] font-semibold text-sea">
          {product.brand} · {product.origin}
        </p>
        <Link to={`/product/${product.id}`} className="line-clamp-2 text-[15px] font-bold leading-6 text-ink">
          {product.name}
        </Link>
        <p className="text-xs text-ink/50">
          {product.capacity} · المتاح {product.stock}
        </p>
        <div className="mt-auto flex items-end justify-between gap-2 pt-2">
          <Price value={product.price} old={product.oldPrice} />
          <button
            type="button"
            onClick={() => addToCart(product.id)}
            className="flex h-10 w-10 items-center justify-center rounded-2xl bg-ink text-gold-2 transition hover:bg-sea"
            aria-label="أضف للسلة"
          >
            <ShoppingBag size={16} />
          </button>
        </div>
      </div>
    </article>
  );
}

export function SectionHead({
  emoji,
  title,
  en,
  to,
  hint,
}: {
  emoji: string;
  title: string;
  en?: string;
  to?: string;
  hint?: string;
}) {
  return (
    <div className="mb-5 flex items-end justify-between gap-3">
      <div>
        <h2 className="flex flex-wrap items-center gap-2 text-2xl font-extrabold text-ink md:text-3xl">
          <span>{emoji}</span>
          <span>{title}</span>
          {en ? <span className="text-base font-semibold text-ink/35">{en}</span> : null}
        </h2>
        {hint ? <p className="mt-1 text-sm text-ink/55">{hint}</p> : null}
      </div>
      {to ? (
        <Link to={to} className="shrink-0 text-sm font-bold text-sea hover:text-ink">
          عرض الكل ‹
        </Link>
      ) : null}
    </div>
  );
}

export function Modal({
  open,
  onClose,
  title,
  children,
  wide,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  wide?: boolean;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[80] flex items-end justify-center bg-black/50 p-0 sm:items-center sm:p-6" onClick={onClose}>
      <div
        className={cn(
          "max-h-[92vh] w-full overflow-auto rounded-t-3xl bg-white p-5 text-ink shadow-2xl sm:rounded-3xl",
          wide ? "max-w-4xl" : "max-w-lg",
        )}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-center justify-between gap-3">
          <h3 className="text-lg font-extrabold text-ink">{title}</h3>
          <button type="button" onClick={onClose} className="rounded-full p-2 hover:bg-sand">
            <X size={18} />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

export function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-bold opacity-70">{label}</span>
      {children}
    </label>
  );
}

export const inputClass =
  "w-full rounded-2xl border border-ink/10 bg-white px-4 py-3 text-sm outline-none transition focus:border-gold focus:ring-2 focus:ring-gold/30";

export const adminInputClass =
  "w-full rounded-xl border border-white/10 bg-night px-3 py-2.5 text-sm text-white outline-none transition placeholder:text-white/30 focus:border-gold";
